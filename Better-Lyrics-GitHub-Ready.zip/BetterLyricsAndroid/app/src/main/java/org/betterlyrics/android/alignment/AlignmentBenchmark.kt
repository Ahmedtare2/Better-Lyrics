package org.betterlyrics.android.alignment

import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import kotlin.math.abs
import kotlin.math.ceil

/**
 * Word annotation format for repeatable evaluation against manually verified timings.
 *
 * `id` identifies an occurrence, not a spelling: repeated chorus words need distinct IDs.
 * `tags` can include `arabic`, `english`, `mixed`, `egyptian`, `rap`, `sustained`,
 * `repeated-chorus`, `multiple-singers`, and `backing-vocals`.
 */
@Serializable
data class AlignmentBenchmarkWord(
    val id: String,
    val text: String,
    val begin: Double,
    val end: Double,
    val singerId: String = "v1",
    val tags: Set<String> = emptySet(),
    val confidence: Float? = null
)

@Serializable
data class AlignmentBenchmarkCase(
    val caseId: String,
    val tags: Set<String> = emptySet(),
    val reference: List<AlignmentBenchmarkWord>,
    val prediction: List<AlignmentBenchmarkWord>
)

@Serializable
data class AlignmentBenchmarkDataset(
    val schemaVersion: Int = 1,
    val description: String = "",
    val cases: List<AlignmentBenchmarkCase>
)

data class AlignmentBenchmarkMetrics(
    val referenceWords: Int,
    val matchedWords: Int,
    val missedWords: Int,
    val extraWords: Int,
    val duplicateWords: Int,
    val invalidTimings: Int,
    val overlapErrors: Int,
    val wordCoverage: Double?,
    val meanAbsoluteTimingErrorSeconds: Double?,
    val medianAbsoluteTimingErrorSeconds: Double?,
    val p90AbsoluteTimingErrorSeconds: Double?,
    val meanStartBoundaryErrorSeconds: Double?,
    val meanEndBoundaryErrorSeconds: Double?,
    val confidenceExpectedCalibrationError: Double?
)

data class AlignmentBenchmarkReport(
    val overall: AlignmentBenchmarkMetrics,
    val byTag: Map<String, AlignmentBenchmarkMetrics>
)

object AlignmentBenchmark {
    private val json = Json {
        ignoreUnknownKeys = false
        prettyPrint = true
        explicitNulls = false
    }

    fun parseDataset(jsonText: String): AlignmentBenchmarkDataset =
        json.decodeFromString(AlignmentBenchmarkDataset.serializer(), jsonText)

    fun encodeDataset(dataset: AlignmentBenchmarkDataset): String =
        json.encodeToString(AlignmentBenchmarkDataset.serializer(), dataset)

    fun evaluate(dataset: AlignmentBenchmarkDataset): AlignmentBenchmarkReport {
        val overall = evaluateCases(dataset.cases)
        val tags = dataset.cases.flatMap { case ->
            case.tags + case.reference.flatMap { it.tags } + case.prediction.flatMap { it.tags }
        }.toSortedSet()
        return AlignmentBenchmarkReport(
            overall = overall,
            byTag = tags.associateWith { tag ->
                evaluateCases(dataset.cases.filter { case ->
                    tag in case.tags ||
                        case.reference.any { tag in it.tags } ||
                        case.prediction.any { tag in it.tags }
                }, onlyTag = tag)
            }
        )
    }

    private fun evaluateCases(
        cases: List<AlignmentBenchmarkCase>,
        onlyTag: String? = null
    ): AlignmentBenchmarkMetrics {
        var totalReferenceWords = 0
        var totalMatchedWords = 0
        var totalMissedWords = 0
        var totalExtraWords = 0
        var totalDuplicateWords = 0
        var totalInvalidTimings = 0
        var totalOverlapErrors = 0
        val allStartErrors = mutableListOf<Double>()
        val allEndErrors = mutableListOf<Double>()
        val allConfidenceSamples = mutableListOf<Pair<Float, Boolean>>()

        for (case in cases) {
            // Filter words by tag if onlyTag is specified
            val filteredReference = case.reference.filter { onlyTag == null || onlyTag in case.tags || onlyTag in it.tags }
            val filteredPrediction = case.prediction.filter { onlyTag == null || onlyTag in case.tags || onlyTag in it.tags }

            // Per-case ID grouping (IDs scoped to case)
            val refsById = filteredReference.groupBy { it.id }
            val predsById = filteredPrediction.groupBy { it.id }

            val duplicateWords = predsById.values.sumOf { (it.size - 1).coerceAtLeast(0) }
            val extraWords = predsById.keys.count { it !in refsById }
            val uniqueRefs = refsById.filterValues { it.size == 1 }
            val uniquePreds = predsById.filterValues { it.size == 1 }
            val matched = uniqueRefs.keys.intersect(uniquePreds.keys)
            val missedWords = (uniqueRefs.keys - uniquePreds.keys).size
            val invalidTimings = filteredPrediction.count { !isValid(it) }

            totalReferenceWords += uniqueRefs.size
            totalMatchedWords += matched.size
            totalMissedWords += missedWords
            totalExtraWords += extraWords
            totalDuplicateWords += duplicateWords
            totalInvalidTimings += invalidTimings

            // Timing errors for matched words in this case
            val referenceById = uniqueRefs
            val predictedById = uniquePreds
            for (id in matched) {
                val reference = referenceById[id]!!.single()
                val prediction = predictedById[id]!!.single()
                // Already filtered by tag above, but double-check word-level tags
                if (onlyTag != null && onlyTag !in reference.tags && onlyTag !in prediction.tags) continue
                val startError = abs(reference.begin - prediction.begin)
                val endError = abs(reference.end - prediction.end)
                allStartErrors += startError
                allEndErrors += endError
                prediction.confidence?.takeIf { it.isFinite() }?.let { confidence ->
                    // Word-level accuracy: both boundaries within 80ms (0.080s)
                    val wordAccurate = (startError <= 0.080 && endError <= 0.080)
                    allConfidenceSamples += confidence.coerceIn(0f, 1f) to wordAccurate
                }
            }

            // Overlap errors for this case (respect onlyTag filter)
            val refWords = filteredReference.filter(::isValid)
            val predWords = filteredPrediction.filter(::isValid)
            val refBySinger = refWords.groupBy { it.singerId }
            val predById = predWords.associateBy { it.id }
            for ((singer, words) in refBySinger) {
                val ordered = words.sortedBy { it.begin }
                for (index in 1 until ordered.size) {
                    val previous = ordered[index - 1]
                    val current = ordered[index]
                    if (current.begin < previous.end) continue // reference overlap is intentional
                    val predictedPrevious = predById[previous.id] ?: continue
                    val predictedCurrent = predById[current.id] ?: continue
                    if (predictedPrevious.singerId == singer && predictedCurrent.singerId == singer &&
                        predictedCurrent.begin < predictedPrevious.end
                    ) totalOverlapErrors++
                }
            }
        }

        val allBoundaryErrors = (allStartErrors + allEndErrors).sorted()
        val meanStart = allStartErrors.averageOrNull()
        val meanEnd = allEndErrors.averageOrNull()
        return AlignmentBenchmarkMetrics(
            referenceWords = totalReferenceWords,
            matchedWords = totalMatchedWords,
            missedWords = totalMissedWords,
            extraWords = totalExtraWords,
            duplicateWords = totalDuplicateWords,
            invalidTimings = totalInvalidTimings,
            overlapErrors = totalOverlapErrors,
            wordCoverage = if (totalReferenceWords == 0) null else totalMatchedWords.toDouble() / totalReferenceWords,
            meanAbsoluteTimingErrorSeconds = allBoundaryErrors.averageOrNull(),
            medianAbsoluteTimingErrorSeconds = percentile(allBoundaryErrors, 0.50),
            p90AbsoluteTimingErrorSeconds = percentile(allBoundaryErrors, 0.90),
            meanStartBoundaryErrorSeconds = meanStart,
            meanEndBoundaryErrorSeconds = meanEnd,
            confidenceExpectedCalibrationError = expectedCalibrationError(allConfidenceSamples)
        )
    }

    private fun expectedCalibrationError(samples: List<Pair<Float, Boolean>>): Double? {
        if (samples.size < 50) return null  // Raise threshold for statistical validity
        val bins = Array(10) { mutableListOf<Pair<Float, Boolean>>() }
        for ((conf, accurate) in samples) {
            val index = (conf * bins.size).toInt().coerceIn(0, bins.lastIndex)
            bins[index] += Pair(conf, accurate)
        }
        return bins.sumOf { bin ->
            if (bin.isEmpty()) 0.0 else {
                val avgConf = bin.map { it.first.toDouble() }.average()
                val obsAcc = bin.count { it.second }.toDouble() / bin.size
                (bin.size.toDouble() / samples.size) * abs(avgConf - obsAcc)
            }
        }
    }

    private fun percentile(sorted: List<Double>, p: Double): Double? {
        if (sorted.isEmpty()) return null
        val index = (ceil(p * sorted.size).toInt() - 1).coerceIn(0, sorted.lastIndex)
        return sorted[index]
    }

    private fun isValid(word: AlignmentBenchmarkWord): Boolean =
        word.begin.isFinite() && word.end.isFinite() && word.begin >= 0.0 && word.end > word.begin

    private fun List<Double>.averageOrNull(): Double? =
        if (isEmpty()) null else average()
}
