package org.betterlyrics.android.alignment

import ai.onnxruntime.OrtSession
import ai.onnxruntime.OrtEnvironment
import android.os.Build

/**
 * ONNX Runtime execution provider configuration for hardware acceleration.
 * Enables NNAPI (Android 9+) and GPU delegates when available, with CPU fallback.
 */
object OnnxProviders {

    /**
     * Creates optimized session options with hardware acceleration enabled.
     * Prefers NNAPI on Android 9+, then GPU, then CPU.
     */
    fun createSessionOptions(): OrtSession.SessionOptions {
        val opts = OrtSession.SessionOptions().apply {
            // Enable all graph optimizations
            setGraphOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT)
            
            // Thread configuration: balance between throughput and memory
            val cpuCount = Runtime.getRuntime().availableProcessors().coerceIn(2, 4)
            setIntraOpNumThreads(cpuCount)
            setInterOpNumThreads(1)
            
            // Memory optimization
            setMemoryPatternOptimization(true)
            setCPUArenaAllocator(true)
        }
        
        // Try NNAPI delegate (Android 9+ / API 28+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            try {
                opts.addConfigEntry("session.use_nnapi", "1")
                // Allow FP16 for NNAPI (faster on supported hardware)
                opts.addConfigEntry("nnapi.allow_fp16", "1")
                // Set NNAPI priority (0=low, 1=normal, 2=high)
                opts.addConfigEntry("nnapi.execution_priority", "1")
            } catch (e: Exception) {
                // NNAPI not available or failed to initialize - will fall back to CPU
            }
        }
        
        // Try GPU delegate (requires onnxruntime-android with GPU package bundled)
        // Note: This requires the GPU delegate to be included in the app's dependencies
        try {
            opts.addConfigEntry("session.use_gpu", "1")
            opts.addConfigEntry("gpu.device_id", "0")
            // GPU memory arena config
            opts.addConfigEntry("gpu.arena_extend_strategy", "kNextPowerOfTwo")
        } catch (e: Exception) {
            // GPU delegate not bundled or failed - will fall back to CPU/NNAPI
        }
        
        return opts
    }
    
    /**
     * Gets available execution providers for debugging/telemetry.
     */
    fun getExecutionProviders(ortEnv: OrtEnvironment): List<String> {
        return try {
            ortEnv.getAvailableProviders()
        } catch (e: Exception) {
            listOf("CPUExecutionProvider")
        }
    }
    
    /**
     * Logs which provider is being used for the current session.
     */
    fun logProviderInfo(ortEnv: OrtEnvironment, modelName: String) {
        val providers = getExecutionProviders(ortEnv)
        val activeProvider = providers.firstOrNull { it != "CPUExecutionProvider" } ?: "CPUExecutionProvider"
        android.util.Log.i("OnnxProviders", "$modelName using provider: $activeProvider (available: ${providers.joinToString(", ")})")
    }

    /**
     * Creates session options with NO_OPT optimization level.
     * Required for FP16-weight models (HTDemucs, UVR MDX-Net) to prevent
     * constant-folding of Cast(FP16->FP32) nodes which would double memory usage.
     */
    fun createSessionOptionsNoOpt(): OrtSession.SessionOptions {
        val opts = OrtSession.SessionOptions().apply {
            // NO_OPT prevents constant-folding of FP16 casts (critical for HTDemucs/UVR)
            setGraphOptimizationLevel(OrtSession.SessionOptions.OptLevel.NO_OPT)
            val cpuCount = Runtime.getRuntime().availableProcessors().coerceIn(2, 4)
            setIntraOpNumThreads(cpuCount)
            setInterOpNumThreads(1)
            setMemoryPatternOptimization(false)
            setCPUArenaAllocator(false)
        }
        return opts
    }
}
