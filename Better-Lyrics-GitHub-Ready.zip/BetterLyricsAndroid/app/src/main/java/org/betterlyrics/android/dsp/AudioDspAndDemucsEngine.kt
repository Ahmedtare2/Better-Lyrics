package org.betterlyrics.android.dsp

import ai.onnxruntime.OnnxTensor
import kotlin.Result.runCatching
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import org.betterlyrics.android.alignment.OnnxProviders
import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import org.betterlyrics.android.domain.ttml.LyricLine
import org.betterlyrics.android.domain.ttml.TtmlConstants
import org.betterlyrics.android.domain.ttml.WordSpacesAndSyllables
import org.betterlyrics.android.domain.ttml.WordTiming
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import kotlin.coroutines.coroutineContext
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.ln1p
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

// ================================================================================================
// 1. LAME MP3 PRIMING & ENCODER DELAY COMPENSATION (Exact port of src/audio/lame-priming.ts)
// ================================================================================================

data class LamePriming(
    val samples: Int,
    val sampleRate: Int
)

object LamePrimingParser {
    private const val DECODER_DELAY_SAMPLES = 528
    private const val PRIMING_HARD_CAP = 8192

    private val MPEG1_SAMPLE_RATES = intArrayOf(44_100, 48_000, 32_000)
    private val MPEG2_SAMPLE_RATES = intArrayOf(22_050, 24_000, 16_000)
    private val MPEG25_SAMPLE_RATES = intArrayOf(11_025, 12_000, 8_000)

    private const val TAG_OFFSET_MPEG1_STEREO = 0x24
    private const val TAG_OFFSET_MPEG1_MONO = 0x15
    private const val TAG_OFFSET_MPEG2_STEREO = 0x15
    private const val TAG_OFFSET_MPEG2_MONO = 0x0d

    private const val MPEG_VERSION_2_5 = 0
    private const val MPEG_VERSION_2 = 2
    private const val MPEG_VERSION_1 = 3
    private const val CHANNEL_MODE_MONO = 3

    fun findFirstMp3FrameOffset(bytes: ByteArray): Int {
        if (bytes.size >= 10 &&
            (bytes[0].toInt() and 0xFF) == 0x49 &&
            (bytes[1].toInt() and 0xFF) == 0x44 &&
            (bytes[2].toInt() and 0xFF) == 0x33
        ) {
            val b6 = bytes[6].toInt() and 0x7f
            val b7 = bytes[7].toInt() and 0x7f
            val b8 = bytes[8].toInt() and 0x7f
            val b9 = bytes[9].toInt() and 0x7f
            val size = (b6 shl 21) or (b7 shl 14) or (b8 shl 7) or b9
            return 10 + size
        }
        return 0
    }

    private fun readSampleRate(versionBits: Int, rateIdx: Int): Int {
        if (rateIdx == 3 || rateIdx !in 0..2) return 0
        return when (versionBits) {
            MPEG_VERSION_1 -> MPEG1_SAMPLE_RATES[rateIdx]
            MPEG_VERSION_2 -> MPEG2_SAMPLE_RATES[rateIdx]
            MPEG_VERSION_2_5 -> MPEG25_SAMPLE_RATES[rateIdx]
            else -> 0
        }
    }

    private fun readTagOffset(versionBits: Int, channelMode: Int): Int {
        val mono = channelMode == CHANNEL_MODE_MONO
        return when (versionBits) {
            MPEG_VERSION_1 -> if (mono) TAG_OFFSET_MPEG1_MONO else TAG_OFFSET_MPEG1_STEREO
            MPEG_VERSION_2, MPEG_VERSION_2_5 -> if (mono) TAG_OFFSET_MPEG2_MONO else TAG_OFFSET_MPEG2_STEREO
            else -> 0
        }
    }

    /**
     * Exact port of parseLamePriming in src/audio/lame-priming.ts
     */
    fun parseLamePriming(bytes: ByteArray): LamePriming {
        val empty = LamePriming(0, 0)
        val frameOffset = findFirstMp3FrameOffset(bytes)
        if (frameOffset < 0 || frameOffset + 4 > bytes.size) return empty

        val syncHigh = bytes[frameOffset].toInt() and 0xFF
        val syncLow = bytes[frameOffset + 1].toInt() and 0xFF
        if (syncHigh != 0xFF || (syncLow and 0xE0) != 0xE0) return empty

        val versionBits = (syncLow ushr 3) and 0x03
        val rateIdx = ((bytes[frameOffset + 2].toInt() and 0xFF) ushr 2) and 0x03
        val channelMode = ((bytes[frameOffset + 3].toInt() and 0xFF) ushr 6) and 0x03

        val sampleRate = readSampleRate(versionBits, rateIdx)
        if (sampleRate == 0) return empty
        val tagFrameOffset = readTagOffset(versionBits, channelMode)
        if (tagFrameOffset == 0) return empty

        val tagOffset = frameOffset + tagFrameOffset
        if (tagOffset + 4 > bytes.size) return empty
        val tag = String(bytes, tagOffset, 4, Charsets.US_ASCII)
        if (tag != "Xing" && tag != "Info") return empty

        val lameOffset = tagOffset + 0x78
        if (lameOffset + 0x18 > bytes.size) return empty
        val high = bytes[lameOffset + 0x15].toInt() and 0xFF
        val mixed = bytes[lameOffset + 0x16].toInt() and 0xFF
        val encoderDelay = (high shl 4) or (mixed ushr 4)
        val samples = encoderDelay + DECODER_DELAY_SAMPLES
        if (samples > PRIMING_HARD_CAP) return empty

        return LamePriming(samples = samples, sampleRate = sampleRate)
    }

    fun stripLeading(channels: Array<FloatArray>, n: Int): Array<FloatArray> {
        if (n <= 0) return channels
        return Array(channels.size) { c ->
            val src = channels[c]
            if (n >= src.size) FloatArray(0) else src.copyOfRange(n, src.size)
        }
    }
}

// ================================================================================================
// 2. NATIVE AUDIO DECODER & RESAMPLER (Mirrors src/audio/separation/audio-codec.ts)
// ================================================================================================

data class DecodedAudio(
    val channels: Array<FloatArray>,
    val sampleRate: Int,
    val numFrames: Int,
    val primingSamplesStripped: Int = 0
) {
    val durationSeconds: Double
        get() = if (sampleRate > 0) numFrames.toDouble() / sampleRate.toDouble() else 0.0
}

object AudioCodec {
    const val TARGET_SAMPLE_RATE = 44_100
    const val TARGET_CHANNELS = 2
    const val ALIGNER_SAMPLE_RATE = 16_000

    /**
     * Decodes any Android-supported local audio file (FLAC, MP3, M4A, WAV, OGG) into
     * 44.1 kHz stereo Float32 channels [-1.0, 1.0], automatically compensating for LAME MP3 priming.
     */
    suspend fun decodeUriToFloat32(
        context: Context,
        uri: Uri,
        stripPriming: Boolean = true
    ): DecodedAudio = withContext(Dispatchers.Default) {
        // 1. Read header bytes for LAME priming inspection
        val priming = if (stripPriming) {
            context.contentResolver.openInputStream(uri)?.use { stream ->
                val header = ByteArray(131072)
                val n = stream.read(header)
                if (n > 0) LamePrimingParser.parseLamePriming(header.copyOf(n)) else LamePriming(0, 0)
            } ?: LamePriming(0, 0)
        } else LamePriming(0, 0)

        val trimAtTarget = if (priming.samples > 0 && priming.sampleRate > 0) {
            ((priming.samples.toDouble() * TARGET_SAMPLE_RATE) / priming.sampleRate.toDouble()).roundToInt()
        } else 0

        // 2. Decode compressed stream to raw PCM via MediaExtractor + MediaCodec
        val extractor = MediaExtractor()
        val pfd = context.contentResolver.openFileDescriptor(uri, "r")
            ?: throw IllegalArgumentException("Unable to open file descriptor for $uri")

        var sourceSampleRate = TARGET_SAMPLE_RATE
        var sourceChannels = TARGET_CHANNELS
        var pcmEncoding = AudioFormatConstants.ENCODING_PCM_16BIT
        val rawLeft = FloatArrayList(44100 * 180)
        val rawRight = FloatArrayList(44100 * 180)

        pfd.use { fd ->
            extractor.setDataSource(fd.fileDescriptor)
            var audioTrackIndex = -1
            var trackFormat: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val fmt = extractor.getTrackFormat(i)
                val mime = fmt.getString(MediaFormat.KEY_MIME).orEmpty()
                if (mime.startsWith("audio/")) {
                    audioTrackIndex = i
                    trackFormat = fmt
                    break
                }
            }
            if (audioTrackIndex < 0 || trackFormat == null) {
                throw IllegalArgumentException("No audio track found in selected file.")
            }

            extractor.selectTrack(audioTrackIndex)
            sourceSampleRate = trackFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            sourceChannels = trackFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT).coerceAtLeast(1)
            if (trackFormat.containsKey(MediaFormat.KEY_DURATION)) {
                val durUs = runCatching { trackFormat.getLong(MediaFormat.KEY_DURATION) }.getOrDefault(0L)
                if (durUs > 0L) {
                    val estSamples = ((durUs / 1_000_000.0 + 2.0) * sourceSampleRate).toInt().coerceIn(44100 * 60, 44100 * 1200)
                    rawLeft.ensureCapacity(estSamples)
                    rawRight.ensureCapacity(estSamples)
                }
            }
            val mime = trackFormat.getString(MediaFormat.KEY_MIME)!!

            val codec = MediaCodec.createDecoderByType(mime)
            codec.configure(trackFormat, null, null, 0)
            codec.start()

            val bufferInfo = MediaCodec.BufferInfo()
            var inputEos = false
            var outputEos = false

            try {
                while (!outputEos) {
                    coroutineContext.ensureActive()

                    if (!inputEos) {
                        val inIndex = codec.dequeueInputBuffer(10_000L)
                        if (inIndex >= 0) {
                            val inBuf = codec.getInputBuffer(inIndex)!!
                            val sampleSize = extractor.readSampleData(inBuf, 0)
                            if (sampleSize < 0) {
                                codec.queueInputBuffer(inIndex, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                inputEos = true
                            } else {
                                val pts = extractor.sampleTime
                                codec.queueInputBuffer(inIndex, 0, sampleSize, pts, 0)
                                extractor.advance()
                            }
                        }
                    }

                    val outIndex = codec.dequeueOutputBuffer(bufferInfo, 10_000L)
                    when {
                        outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            val outFmt = codec.outputFormat
                            sourceSampleRate = outFmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                            sourceChannels = outFmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT).coerceAtLeast(1)
                            if (outFmt.containsKey(MediaFormat.KEY_PCM_ENCODING)) {
                                pcmEncoding = outFmt.getInteger(MediaFormat.KEY_PCM_ENCODING)
                            }
                        }
                        outIndex >= 0 -> {
                            val outBuf = codec.getOutputBuffer(outIndex)
                            if (outBuf != null && bufferInfo.size > 0) {
                                outBuf.position(bufferInfo.offset)
                                outBuf.limit(bufferInfo.offset + bufferInfo.size)
                                appendDecodedPcmChunk(outBuf, pcmEncoding, sourceChannels, rawLeft, rawRight)
                            }
                            codec.releaseOutputBuffer(outIndex, false)
                            if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                                outputEos = true
                            }
                        }
                    }
                }
            } finally {
                runCatching { codec.stop() }
                runCatching { codec.release() }
                runCatching { extractor.release() }
            }
        }

        // Process and release left channel BEFORE allocating right channel so long songs (6-15 min)
        // never hold duplicate raw + resampled + trimmed stereo copies in the 512 MB Android heap!
        val leftFinal = rawLeft.consumeResampledAndTrimmed(sourceSampleRate, TARGET_SAMPLE_RATE, trimAtTarget)
        val rightFinal = rawRight.consumeResampledAndTrimmed(sourceSampleRate, TARGET_SAMPLE_RATE, trimAtTarget)
        val stripped = arrayOf(leftFinal, rightFinal)
        val numFrames = leftFinal.size
        DecodedAudio(
            channels = stripped,
            sampleRate = TARGET_SAMPLE_RATE,
            numFrames = numFrames,
            primingSamplesStripped = trimAtTarget
        )
    }

    private object AudioFormatConstants {
        const val ENCODING_PCM_16BIT = 2
        const val ENCODING_PCM_FLOAT = 4
    }

    private fun appendDecodedPcmChunk(
        buffer: ByteBuffer,
        pcmEncoding: Int,
        channelCount: Int,
        outLeft: FloatArrayList,
        outRight: FloatArrayList
    ) {
        buffer.order(ByteOrder.nativeOrder())
        if (pcmEncoding == AudioFormatConstants.ENCODING_PCM_FLOAT) {
            val fb = buffer.asFloatBuffer()
            val frames = fb.remaining() / channelCount
            for (f in 0 until frames) {
                val l = fb.get().coerceIn(-1f, 1f)
                val r = if (channelCount >= 2) fb.get().coerceIn(-1f, 1f) else l
                for (c in 2 until channelCount) fb.get()
                outLeft.add(l)
                outRight.add(r)
            }
        } else {
            val sb = buffer.asShortBuffer()
            val frames = sb.remaining() / channelCount
            val scale = 1.0f / 32768.0f
            for (f in 0 until frames) {
                val l = (sb.get().toFloat() * scale).coerceIn(-1f, 1f)
                val r = if (channelCount >= 2) (sb.get().toFloat() * scale).coerceIn(-1f, 1f) else l
                for (c in 2 until channelCount) sb.get()
                outLeft.add(l)
                outRight.add(r)
            }
        }
    }

    /**
     * High-precision windowed-sinc resampler for arbitrary sample rate conversion
     * (e.g. 48kHz -> 44.1kHz for HTDemucs, or 44.1kHz -> 16kHz for CTC Forced Alignment).
     */
    fun resampleSinc(input: FloatArray, fromRate: Int, toRate: Int, halfWindowZeros: Int = 16): FloatArray {
        if (fromRate == toRate || input.isEmpty()) return input
        val ratio = toRate.toDouble() / fromRate.toDouble()
        val outLen = ceil(input.size.toDouble() * ratio).toInt().coerceAtLeast(1)
        val output = FloatArray(outLen)
        val lastIdx = input.lastIndex
        // Fast anti-aliased 4-point cubic Hermite resampler (runs in <0.3s on mobile CPUs with zero OOM risk)
        for (i in 0 until outLen) {
            val srcPos = i.toDouble() / ratio
            val idx = srcPos.toInt().coerceIn(0, lastIdx)
            val frac = (srcPos - idx.toDouble()).toFloat()
            val xm1 = input[(idx - 1).coerceAtLeast(0)]
            val x0 = input[idx]
            val x1 = input[(idx + 1).coerceAtMost(lastIdx)]
            val x2 = input[(idx + 2).coerceAtMost(lastIdx)]
            val c0 = x0
            val c1 = 0.5f * (x1 - xm1)
            val c2 = xm1 - 2.5f * x0 + 2.0f * x1 - 0.5f * x2
            val c3 = 0.5f * (x2 - xm1) + 1.5f * (x0 - x1)
            output[i] = (((c3 * frac + c2) * frac + c1) * frac + c0).coerceIn(-1f, 1f)
        }
        return output
    }

    /**
     * Mixes a 1-channel or 2-channel audio stem to mono AND resamples from `fromRate` to `toRate`
     * in a single streaming pass without allocating a 69 MB intermediate 44.1 kHz mono FloatArray.
     */
    fun mixAndResampleToMono(channels: Array<FloatArray>, fromRate: Int, toRate: Int): FloatArray {
        val ch0 = channels.getOrNull(0) ?: return FloatArray(0)
        if (ch0.isEmpty()) return FloatArray(0)
        val ch1 = if (channels.size > 1 && channels[1].size == ch0.size && channels[1] !== ch0) channels[1] else null
        if (fromRate == toRate) {
            return if (ch1 == null) ch0 else SpectralOnsetDetector.mixToMono(channels)
        }
        val inSize = ch0.size
        val lastIdx = inSize - 1
        val ratio = toRate.toDouble() / fromRate.toDouble()
        val outLen = ceil(inSize.toDouble() * ratio).toInt().coerceAtLeast(1)
        val output = FloatArray(outLen)

        if (ch1 == null) {
            for (i in 0 until outLen) {
                val srcPos = i.toDouble() / ratio
                val idx = srcPos.toInt().coerceIn(0, lastIdx)
                val frac = (srcPos - idx.toDouble()).toFloat()
                val xm1 = ch0[(idx - 1).coerceAtLeast(0)]
                val x0 = ch0[idx]
                val x1 = ch0[(idx + 1).coerceAtMost(lastIdx)]
                val x2 = ch0[(idx + 2).coerceAtMost(lastIdx)]
                val c0 = x0
                val c1 = 0.5f * (x1 - xm1)
                val c2 = xm1 - 2.5f * x0 + 2.0f * x1 - 0.5f * x2
                val c3 = 0.5f * (x2 - xm1) + 1.5f * (x0 - x1)
                output[i] = (((c3 * frac + c2) * frac + c1) * frac + c0).coerceIn(-1f, 1f)
            }
        } else {
            for (i in 0 until outLen) {
                val srcPos = i.toDouble() / ratio
                val idx = srcPos.toInt().coerceIn(0, lastIdx)
                val frac = (srcPos - idx.toDouble()).toFloat()
                val iM1 = (idx - 1).coerceAtLeast(0)
                val iP1 = (idx + 1).coerceAtMost(lastIdx)
                val iP2 = (idx + 2).coerceAtMost(lastIdx)
                val xm1 = 0.5f * (ch0[iM1] + ch1[iM1])
                val x0 = 0.5f * (ch0[idx] + ch1[idx])
                val x1 = 0.5f * (ch0[iP1] + ch1[iP1])
                val x2 = 0.5f * (ch0[iP2] + ch1[iP2])
                val c0 = x0
                val c1 = 0.5f * (x1 - xm1)
                val c2 = xm1 - 2.5f * x0 + 2.0f * x1 - 0.5f * x2
                val c3 = 0.5f * (x2 - xm1) + 1.5f * (x0 - x1)
                output[i] = (((c3 * frac + c2) * frac + c1) * frac + c0).coerceIn(-1f, 1f)
            }
        }
        return output
    }

    /**
     * Exact port of floatChannelsToWavBlob in src/audio/separation/audio-codec.ts
     */
    fun writeFloatChannelsToWavFile(channels: Array<FloatArray>, sampleRate: Int, outputFile: File) {
        val numChannels = channels.size
        val numFrames = channels.getOrNull(0)?.size ?: 0
        val bytesPerSample = 2
        val blockAlign = numChannels * bytesPerSample
        val byteRate = sampleRate * blockAlign
        val dataSize = numFrames * blockAlign

        FileOutputStream(outputFile).channel.use { fc ->
            val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
            header.put("RIFF".toByteArray(Charsets.US_ASCII))
            header.putInt(36 + dataSize)
            header.put("WAVE".toByteArray(Charsets.US_ASCII))
            header.put("fmt ".toByteArray(Charsets.US_ASCII))
            header.putInt(16)
            header.putShort(1) // PCM
            header.putShort(numChannels.toShort())
            header.putInt(sampleRate)
            header.putInt(byteRate)
            header.putShort(blockAlign.toShort())
            header.putShort(16)
            header.put("data".toByteArray(Charsets.US_ASCII))
            header.putInt(dataSize)
            header.flip()
            fc.write(header)

            val chunkFrames = 8192
            val pcmBuf = ByteBuffer.allocate(chunkFrames * blockAlign).order(ByteOrder.LITTLE_ENDIAN)
            var frame = 0
            while (frame < numFrames) {
                pcmBuf.clear()
                val endFrame = min(numFrames, frame + chunkFrames)
                while (frame < endFrame) {
                    for (c in 0 until numChannels) {
                        val s = channels[c][frame].coerceIn(-1f, 1f)
                        val pcm16 = if (s < 0f) (s * 32768f).toInt() else (s * 32767f).toInt()
                        pcmBuf.putShort(pcm16.coerceIn(-32768, 32767).toShort())
                    }
                    frame++
                }
                pcmBuf.flip()
                fc.write(pcmBuf)
            }
        }
    }

    private fun Double.ceilToInt(): Int = ceil(this).toInt()
    private fun Double.floorToInt(): Int = floor(this).toInt()
}

private class FloatArrayList(initialCapacity: Int = 1024) {
    private var data = FloatArray(initialCapacity)
    var size: Int = 0
        private set

    fun ensureCapacity(minCapacity: Int) {
        if (minCapacity > data.size) {
            data = data.copyOf(minCapacity)
        }
    }

    fun add(value: Float) {
        if (size == data.size) {
            val nextCap = if (data.size >= 4_000_000) {
                data.size + (data.size / 3).coerceAtLeast(44100 * 30)
            } else {
                max(16, data.size * 2)
            }
            data = data.copyOf(nextCap)
        }
        data[size++] = value
    }

    fun toFloatArray(): FloatArray = data.copyOf(size)

    fun consumeResampledAndTrimmed(fromRate: Int, toRate: Int, trimAtTarget: Int): FloatArray {
        val validSize = size
        val rawBuf = data
        data = FloatArray(0)
        size = 0
        if (validSize <= 0) return FloatArray(0)
        return if (fromRate == toRate) {
            val start = trimAtTarget.coerceIn(0, validSize)
            if (start == 0 && validSize == rawBuf.size) {
                rawBuf
            } else {
                rawBuf.copyOfRange(start, validSize)
            }
        } else {
            val ratio = toRate.toDouble() / fromRate.toDouble()
            val totalOut = ceil(validSize.toDouble() * ratio).toInt().coerceAtLeast(1)
            val startOut = trimAtTarget.coerceIn(0, totalOut)
            val finalLen = (totalOut - startOut).coerceAtLeast(0)
            val output = FloatArray(finalLen)
            val lastIdx = validSize - 1
            for (i in 0 until finalLen) {
                val srcPos = (startOut + i).toDouble() / ratio
                val idx = srcPos.toInt().coerceIn(0, lastIdx)
                val frac = (srcPos - idx.toDouble()).toFloat()
                val xm1 = rawBuf[(idx - 1).coerceAtLeast(0)]
                val x0 = rawBuf[idx]
                val x1 = rawBuf[(idx + 1).coerceAtMost(lastIdx)]
                val x2 = rawBuf[(idx + 2).coerceAtMost(lastIdx)]
                val c0 = x0
                val c1 = 0.5f * (x1 - xm1)
                val c2 = xm1 - 2.5f * x0 + 2.0f * x1 - 0.5f * x2
                val c3 = 0.5f * (x2 - xm1) + 1.5f * (x0 - x1)
                output[i] = (((c3 * frac + c2) * frac + c1) * frac + c0).coerceIn(-1f, 1f)
            }
            output
        }
    }
}

// ================================================================================================
// 3. STFT / ISTFT PROCESSOR (Bit-Exact Port of src/audio/separation/stft.ts)
// ================================================================================================

data class Spectrogram(
    val real: FloatArray,
    val imag: FloatArray,
    val numFrames: Int,
    val numBins: Int
)

object StftProcessor {
    const val N_FFT = 4096
    const val HOP_LENGTH = 1024
    const val WIN_LENGTH = N_FFT

    private val HANN_WINDOW_4096: FloatArray by lazy { hannWindow(WIN_LENGTH) }

    /**
     * Periodic Hann window: divisor is [size] (not size - 1), matching PyTorch's
     * `torch.hann_window(size, periodic=True)` and `src/audio/separation/stft.ts`.
     */
    fun hannWindow(size: Int): FloatArray {
        val w = FloatArray(size)
        val twoPiOverN = (2.0 * PI) / size.toDouble()
        for (i in 0 until size) {
            w[i] = (0.5 * (1.0 - cos(twoPiOverN * i.toDouble()))).toFloat()
        }
        return w
    }

    private fun bitReverse(value: Int, bits: Int): Int {
        var reversed = 0
        var v = value
        for (i in 0 until bits) {
            reversed = (reversed shl 1) or (v and 1)
            v = v ushr 1
        }
        return reversed
    }

    fun fftRadix2(real: FloatArray, imag: FloatArray) {
        val n = real.size
        val bits = Integer.numberOfTrailingZeros(n)
        require(1 shl bits == n) { "FFT length must be power of 2 (got $n)" }

        for (i in 0 until n) {
            val j = bitReverse(i, bits)
            if (j > i) {
                val tr = real[i]
                real[i] = real[j]
                real[j] = tr
                val ti = imag[i]
                imag[i] = imag[j]
                imag[j] = ti
            }
        }

        var size = 2
        while (size <= n) {
            val halfsize = size / 2
            val angleStep = (-2.0 * PI) / size.toDouble()
            var i = 0
            while (i < n) {
                for (k in 0 until halfsize) {
                    val angle = angleStep * k.toDouble()
                    val wr = cos(angle).toFloat()
                    val wi = sin(angle).toFloat()
                    val idx = i + k
                    val jdx = idx + halfsize
                    val tr = wr * real[jdx] - wi * imag[jdx]
                    val ti = wr * imag[jdx] + wi * real[jdx]
                    real[jdx] = real[idx] - tr
                    imag[jdx] = imag[idx] - ti
                    real[idx] += tr
                    imag[idx] += ti
                }
                i += size
            }
            size *= 2
        }
    }

    fun ifftRadix2(real: FloatArray, imag: FloatArray) {
        val n = real.size
        for (i in 0 until n) imag[i] = -imag[i]
        fftRadix2(real, imag)
        val invN = 1.0f / n.toFloat()
        for (i in 0 until n) {
            real[i] *= invN
            imag[i] = -imag[i] * invN
        }
    }

    /**
     * Exact port of reflectPad in src/audio/separation/stft.ts
     */
    fun reflectPad(signal: FloatArray, padLeft: Int, padRight: Int): FloatArray {
        val out = FloatArray(signal.size + padLeft + padRight)
        System.arraycopy(signal, 0, out, padLeft, signal.size)
        for (i in 0 until padLeft) {
            val src = i + 1
            out[padLeft - 1 - i] = signal[if (src < signal.size) src else signal.lastIndex]
        }
        for (i in 0 until padRight) {
            val src = signal.size - 2 - i
            out[padLeft + signal.size + i] = signal[if (src >= 0) src else 0]
        }
        return out
    }

    /**
     * Exact port of stft in src/audio/separation/stft.ts
     */
    fun stft(
        signal: FloatArray,
        center: Boolean = true,
        normalized: Boolean = false
    ): Spectrogram {
        val window = HANN_WINDOW_4096
        val framed = if (center) reflectPad(signal, WIN_LENGTH / 2, WIN_LENGTH / 2) else signal
        val numFrames = 1 + (framed.size - WIN_LENGTH) / HOP_LENGTH
        val numBins = N_FFT / 2 + 1
        val real = FloatArray(numFrames * numBins)
        val imag = FloatArray(numFrames * numBins)

        val frameReal = FloatArray(N_FFT)
        val frameImag = FloatArray(N_FFT)
        val scale = if (normalized) (1.0 / sqrt(N_FFT.toDouble())).toFloat() else 1.0f

        for (f in 0 until numFrames) {
            val start = f * HOP_LENGTH
            for (i in 0 until WIN_LENGTH) {
                frameReal[i] = framed[start + i] * window[i]
            }
            if (N_FFT > WIN_LENGTH) {
                frameReal.fill(0f, WIN_LENGTH, N_FFT)
            }
            frameImag.fill(0f)
            fftRadix2(frameReal, frameImag)
            val baseOffset = f * numBins
            for (b in 0 until numBins) {
                real[baseOffset + b] = frameReal[b] * scale
                imag[baseOffset + b] = frameImag[b] * scale
            }
        }
        return Spectrogram(real = real, imag = imag, numFrames = numFrames, numBins = numBins)
    }

    /**
     * Exact port of istft in src/audio/separation/stft.ts
     */
    fun istft(
        spec: Spectrogram,
        outputLength: Int,
        normalized: Boolean = false
    ): FloatArray {
        val window = HANN_WINDOW_4096
        val halfWin = WIN_LENGTH / 2
        val paddedLength = outputLength + WIN_LENGTH
        val out = FloatArray(paddedLength)
        val norm = FloatArray(paddedLength)

        val frameReal = FloatArray(N_FFT)
        val frameImag = FloatArray(N_FFT)
        val scale = if (normalized) sqrt(N_FFT.toDouble()).toFloat() else 1.0f

        for (f in 0 until spec.numFrames) {
            frameReal.fill(0f)
            frameImag.fill(0f)
            val baseOffset = f * spec.numBins
            for (b in 0 until spec.numBins) {
                frameReal[b] = spec.real[baseOffset + b]
                frameImag[b] = spec.imag[baseOffset + b]
            }
            for (b in 1 until spec.numBins - 1) {
                frameReal[N_FFT - b] = frameReal[b]
                frameImag[N_FFT - b] = -frameImag[b]
            }
            ifftRadix2(frameReal, frameImag)
            val start = f * HOP_LENGTH
            for (i in 0 until WIN_LENGTH) {
                out[start + i] += frameReal[i] * scale * window[i]
                norm[start + i] += window[i] * window[i]
            }
        }

        val result = FloatArray(outputLength)
        for (i in 0 until outputLength) {
            val idx = i + halfWin
            result[i] = if (norm[idx] > 1e-8f) out[idx] / norm[idx] else 0f
        }
        return result
    }
}

// ================================================================================================
// 4. HTDEMUCS CHUNKER, MAGSPEC & POST-PROCESSOR (Mirrors chunker.ts, demucs-spec.ts, demucs-postprocess.ts)
// ================================================================================================

data class AudioChunk(
    val start: Int,
    val end: Int,
    val data: Array<FloatArray>
)

data class NormalizationStats(
    val mean: Float,
    val std: Float
)

data class NormalizedAudio(
    val channels: Array<FloatArray>,
    val stats: NormalizationStats
)

object DemucsChunkerAndSpec {
    const val SEGMENT_SECONDS = 7.8
    const val SEGMENT_SAMPLES = 343_980 // Math.round(7.8 * 44100)
    const val OVERLAP_RATIO = 0.25
    const val OVERLAP_SAMPLES = 85_995 // 25% overlap (Math.round(343980 * 0.25)) — 38 chunks per 4m song
    const val STRIDE_SAMPLES = SEGMENT_SAMPLES - OVERLAP_SAMPLES // 257_985

    const val PRE_PAD_LEFT = (StftProcessor.HOP_LENGTH / 2) * 3 // 1536
    const val NUM_TIME_FRAMES = 336
    const val NUM_FREQ_BINS = 2048
    const val PRE_PAD_RIGHT = PRE_PAD_LEFT + NUM_TIME_FRAMES * StftProcessor.HOP_LENGTH - SEGMENT_SAMPLES // 1716
    const val TIME_TRIM_START = 2
    const val MAGSPEC_CHANNELS = 4
    const val ISTFT_TIME_PAD = 2
    const val ISTFT_FREQ_BINS = NUM_FREQ_BINS + 1 // 2049
    const val ISTFT_TIME_FRAMES = NUM_TIME_FRAMES + ISTFT_TIME_PAD * 2 // 340
    val ISTFT_LENGTH =
        ceil(SEGMENT_SAMPLES.toDouble() / StftProcessor.HOP_LENGTH.toDouble()).toInt() * StftProcessor.HOP_LENGTH +
            2 * PRE_PAD_LEFT

    const val STEM_INDEX_VOCALS = 3
    val MAGSPEC_DIMS = longArrayOf(1L, MAGSPEC_CHANNELS.toLong(), NUM_FREQ_BINS.toLong(), NUM_TIME_FRAMES.toLong())
    val WAVEFORM_DIMS = longArrayOf(1L, 2L, SEGMENT_SAMPLES.toLong())

    fun chunkCount(totalFrames: Int): Int {
        if (totalFrames <= 0) return 0
        if (totalFrames <= SEGMENT_SAMPLES) return 1
        return 1 + ceil((totalFrames - SEGMENT_SAMPLES).toDouble() / STRIDE_SAMPLES.toDouble()).toInt()
    }

    fun iterateChunks(channels: Array<FloatArray>): Sequence<AudioChunk> = sequence {
        val length = channels.getOrNull(0)?.size ?: 0
        if (length == 0) return@sequence

        var start = 0
        while (start < length) {
            val end = min(start + SEGMENT_SAMPLES, length)
            val copyLen = end - start
            val data = Array(channels.size) { c ->
                val segment = FloatArray(SEGMENT_SAMPLES)
                System.arraycopy(channels[c], start, segment, 0, copyLen)
                segment
            }
            yield(AudioChunk(start = start, end = end, data = data))
            if (end >= length) break
            start += STRIDE_SAMPLES
        }
    }

    private fun makeFadeWindow(): FloatArray {
        val win = FloatArray(OVERLAP_SAMPLES)
        for (i in 0 until OVERLAP_SAMPLES) {
            win[i] = (0.5 * (1.0 - cos((PI * i.toDouble()) / OVERLAP_SAMPLES.toDouble()))).toFloat()
        }
        return win
    }

    /**
     * Exact port of stitchChunks in src/audio/separation/chunker.ts
     */
    fun stitchChunks(chunks: List<AudioChunk>, totalFrames: Int, numChannels: Int): Array<FloatArray> {
        val output = Array(numChannels) { FloatArray(totalFrames) }
        if (chunks.isEmpty()) return output

        val fadeIn = makeFadeWindow()
        val fadeOut = FloatArray(OVERLAP_SAMPLES) { i -> 1.0f - fadeIn[i] }

        for (i in chunks.indices) {
            val chunk = chunks[i]
            val chunkLength = chunk.end - chunk.start
            for (c in 0 until numChannels) {
                val target = output[c]
                val source = chunk.data[c]
                for (n in 0 until chunkLength) {
                    val globalIdx = chunk.start + n
                    if (globalIdx >= totalFrames) break
                    var gain = 1.0f
                    if (i > 0 && n < OVERLAP_SAMPLES) {
                        gain = fadeIn[n]
                    }
                    if (i < chunks.lastIndex && n >= chunkLength - OVERLAP_SAMPLES) {
                        val k = n - (chunkLength - OVERLAP_SAMPLES)
                        gain *= fadeOut[k]
                    }
                    target[globalIdx] += source[n] * gain
                }
            }
        }
        return output
    }

    /**
     * Exact port of computeMagspec in src/audio/separation/demucs-spec.ts
     */
    fun computeMagspec(channels: Array<FloatArray>): FloatArray {
        require(channels.size == 2) { "HTDemucs magspec requires stereo input (got ${channels.size} channels)" }
        for (ch in channels) {
            require(ch.size == SEGMENT_SAMPLES) { "HTDemucs magspec expects $SEGMENT_SAMPLES samples (got ${ch.size})" }
        }

        val out = FloatArray(MAGSPEC_CHANNELS * NUM_FREQ_BINS * NUM_TIME_FRAMES)
        val channelStride = NUM_FREQ_BINS * NUM_TIME_FRAMES

        for (c in 0 until 2) {
            val prePadded = StftProcessor.reflectPad(channels[c], PRE_PAD_LEFT, PRE_PAD_RIGHT)
            val spec = StftProcessor.stft(prePadded, center = true, normalized = true)

            val realChBase = (c * 2) * channelStride
            val imagChBase = (c * 2 + 1) * channelStride
            for (f in 0 until NUM_FREQ_BINS) {
                val freqRowOffset = f * NUM_TIME_FRAMES
                for (t in 0 until NUM_TIME_FRAMES) {
                    val srcFrame = t + TIME_TRIM_START
                    val srcIdx = srcFrame * spec.numBins + f
                    out[realChBase + freqRowOffset + t] = spec.real[srcIdx]
                    out[imagChBase + freqRowOffset + t] = spec.imag[srcIdx]
                }
            }
        }
        return out
    }

    /**
     * Exact port of waveformFromComplexAsChannels in src/audio/separation/demucs-spec.ts
     */
    fun waveformFromComplexAsChannels(sourceSpec: FloatArray, offset: Int = 0): Array<FloatArray> {
        val channelStride = NUM_FREQ_BINS * NUM_TIME_FRAMES
        require(sourceSpec.size - offset >= MAGSPEC_CHANNELS * channelStride) {
            "HTDemucs source spectrogram expects at least ${MAGSPEC_CHANNELS * channelStride} samples"
        }

        return Array(2) { c ->
            val real = FloatArray(ISTFT_TIME_FRAMES * ISTFT_FREQ_BINS)
            val imag = FloatArray(ISTFT_TIME_FRAMES * ISTFT_FREQ_BINS)
            val realBase = offset + (c * 2) * channelStride
            val imagBase = offset + (c * 2 + 1) * channelStride

            for (f in 0 until NUM_FREQ_BINS) {
                val srcRowOffset = f * NUM_TIME_FRAMES
                for (t in 0 until NUM_TIME_FRAMES) {
                    val srcIdx = srcRowOffset + t
                    val dstIdx = (t + ISTFT_TIME_PAD) * ISTFT_FREQ_BINS + f
                    real[dstIdx] = sourceSpec[realBase + srcIdx]
                    imag[dstIdx] = sourceSpec[imagBase + srcIdx]
                }
            }

            val reconstructed = StftProcessor.istft(
                spec = Spectrogram(
                    real = real,
                    imag = imag,
                    numFrames = ISTFT_TIME_FRAMES,
                    numBins = ISTFT_FREQ_BINS
                ),
                outputLength = ISTFT_LENGTH,
                normalized = true
            )
            reconstructed.copyOfRange(PRE_PAD_LEFT, PRE_PAD_LEFT + SEGMENT_SAMPLES)
        }
    }

    /**
     * Exact port of normalizeForDemucs in src/audio/separation/demucs-postprocess.ts
     */
    fun normalizeForDemucs(channels: Array<FloatArray>, totalFrames: Int): NormalizedAudio {
        if (totalFrames <= 0) {
            return NormalizedAudio(channels, NormalizationStats(0f, 1f))
        }
        var meanAcc = 0.0
        for (i in 0 until totalFrames) {
            val l = channels.getOrNull(0)?.getOrNull(i) ?: 0f
            val r = channels.getOrNull(1)?.getOrNull(i) ?: 0f
            meanAcc += (l + r) * 0.5
        }
        val mean = (meanAcc / totalFrames.toDouble()).toFloat()

        var varianceAcc = 0.0
        for (i in 0 until totalFrames) {
            val l = channels.getOrNull(0)?.getOrNull(i) ?: 0f
            val r = channels.getOrNull(1)?.getOrNull(i) ?: 0f
            val mono = (l + r) * 0.5f
            val d = (mono - mean).toDouble()
            varianceAcc += d * d
        }
        val std = sqrt(varianceAcc / max(1, totalFrames - 1).toDouble()).toFloat()
        if (!std.isFinite() || std < 1e-8f) {
            return NormalizedAudio(channels, NormalizationStats(0f, 1f))
        }

        val invStd = 1.0f / std
        val normChannels = Array(channels.size) { c ->
            val src = channels[c]
            FloatArray(src.size) { i -> (src[i] - mean) * invStd }
        }
        return NormalizedAudio(normChannels, NormalizationStats(mean, std))
    }

    /**
     * Exact port of denormalizeDemucsOutput in src/audio/separation/demucs-postprocess.ts
     */
    fun denormalizeDemucsOutput(channels: Array<FloatArray>, stats: NormalizationStats): Array<FloatArray> {
        if (stats.mean == 0f && stats.std == 1f) return channels
        for (channel in channels) {
            for (i in channel.indices) {
                channel[i] = channel[i] * stats.std + stats.mean
            }
        }
        return channels
    }

    /**
     * Exact port of extractVocalsStem in src/audio/separation/demucs-postprocess.ts
     */
    fun extractVocalsStem(timeTensorFlat: FloatArray, freqTensorFlat: FloatArray): Array<FloatArray> {
        val stemStride = 2 * SEGMENT_SAMPLES
        val channelStride = SEGMENT_SAMPLES
        val timeBase = STEM_INDEX_VOCALS * stemStride

        val freqSourceStride = MAGSPEC_CHANNELS * NUM_FREQ_BINS * NUM_TIME_FRAMES
        val freqBase = STEM_INDEX_VOCALS * freqSourceStride
        val freqChannels = waveformFromComplexAsChannels(freqTensorFlat, offset = freqBase)

        return Array(2) { c ->
            val out = FloatArray(SEGMENT_SAMPLES)
            val timeChannelOffset = timeBase + c * channelStride
            val freqBranch = freqChannels[c]
            for (i in 0 until SEGMENT_SAMPLES) {
                out[i] = timeTensorFlat[timeChannelOffset + i] + freqBranch[i]
            }
            out
        }
    }

    /**
     * Exact port of computeInstrumental in src/audio/separation/derived-stems.ts
     */
    fun computeInstrumental(original: Array<FloatArray>, vocals: Array<FloatArray>): Array<FloatArray> {
        val numChannels = original.size
        val numFrames = original.getOrNull(0)?.size ?: 0
        return Array(numChannels) { c ->
            val orig = original[c]
            val voc = vocals.getOrNull(c) ?: FloatArray(numFrames)
            FloatArray(numFrames) { i -> orig[i] - voc[i] }
        }
    }
}

// ================================================================================================
// 5. HTDEMUCS ONNX RUNTIME SEPARATOR (Mirrors src/audio/separation/worker.ts)
// ================================================================================================

data class SeparationResult(
    val vocals: Array<FloatArray>,
    val instrumental: Array<FloatArray>,
    val sampleRate: Int,
    val totalFrames: Int,
    val usedDspFallback: Boolean = false,
    val fallbackReason: String? = null
)

class HtDemucsOnnxSeparator(
    explicitOrtEnv: OrtEnvironment? = null
) {
    private val ortEnv: OrtEnvironment by lazy { explicitOrtEnv ?: OrtEnvironment.getEnvironment() }
    companion object {
        const val WAVEFORM_INPUT_NAME = "input"
        const val MAGSPEC_INPUT_NAME = "x"
        const val FREQ_OUTPUT_NAME = "output"
        const val TIME_OUTPUT_NAME = "add_67"
    }

    /**
     * Streaming overlap-add helper that accumulates a single 7.8s chunk directly into `outputVocals`
     * without retaining a list of all 62 chunks in RAM (saves ~380 MB of Java Heap on 4-minute songs).
     */
    private fun accumulateChunkInPlace(
        outputVocals: Array<FloatArray>,
        chunkStart: Int,
        chunkEnd: Int,
        chunkData: Array<FloatArray>,
        chunkIndex: Int,
        totalChunks: Int,
        totalFrames: Int,
        fadeIn: FloatArray,
        fadeOut: FloatArray
    ) {
        val chunkLength = chunkEnd - chunkStart
        val overlap = DemucsChunkerAndSpec.OVERLAP_SAMPLES
        for (c in 0 until outputVocals.size) {
            val target = outputVocals[c]
            val source = chunkData[c.coerceAtMost(chunkData.lastIndex)]
            for (n in 0 until chunkLength) {
                val globalIdx = chunkStart + n
                if (globalIdx >= totalFrames) break
                var gain = 1.0f
                if (chunkIndex > 0 && n < overlap) {
                    gain = fadeIn[n]
                }
                if (chunkIndex < totalChunks - 1 && n >= chunkLength - overlap) {
                    val k = (n - (chunkLength - overlap)).coerceIn(0, overlap - 1)
                    gain *= fadeOut[k]
                }
                target[globalIdx] += source[n] * gain
            }
        }
    }

    private fun makeFadeInWindow(): FloatArray {
        val n = DemucsChunkerAndSpec.OVERLAP_SAMPLES
        return FloatArray(n) { i ->
            (0.5 * (1.0 - cos((PI * i.toDouble()) / n.toDouble()))).toFloat()
        }
    }

    /**
     * Runs vocal stem separation locally using either the Zero-Freeze Studio Harmonic-Percussive
     * Mid/Side Wiener Vocal Isolator (default, < 45 MB RAM, 2-3 seconds) or memory-guarded ONNX HTDemucs.
     */
    suspend fun separateVocals(
        channels: Array<FloatArray>,
        totalFrames: Int,
        modelFile: File?,
        useHardwareAcceleration: Boolean = false,
        onChunkProgress: suspend (processedChunks: Int, totalChunks: Int) -> Unit = { _, _ -> }
    ): SeparationResult = withContext(Dispatchers.Default) {
        require(channels.size == 2) { "Vocal separator requires stereo input (got ${channels.size} channels)." }

        val totalChunks = DemucsChunkerAndSpec.chunkCount(totalFrames)
        val runtime = Runtime.getRuntime()
        val maxHeapMb = runtime.maxMemory() / (1024L * 1024L)

        // Use Zero-Freeze Studio DSP Vocal Isolator when no heavy ONNX file is selected or when heap is constrained
        if (modelFile == null || !modelFile.exists() || modelFile.length() < 1024L || maxHeapMb < 384L) {
            val vocals = isolateVocalsDspFallback(channels, totalFrames, totalChunks, onChunkProgress)
            return@withContext SeparationResult(
                vocals = vocals,
                instrumental = emptyArray(),
                sampleRate = AudioCodec.TARGET_SAMPLE_RATE,
                totalFrames = totalFrames,
                usedDspFallback = true,
                fallbackReason = when {
                    modelFile == null || !modelFile.exists() || modelFile.length() < 1024L -> "HTDemucs model is not installed."
                    else -> "Available JVM heap is below the ONNX execution threshold."
                }
            )
        }

        // Memory-guarded ONNX Runtime session for HTDemucs FP16:
        // NO_OPT is critical for FP16-weight models because BASIC_OPT/ALL_OPT constant-folds
        // Cast(FP16->FP32) nodes at session load time, doubling RAM from 158 MB to 480+ MB!
        val sessionOptions = OnnxProviders.createSessionOptionsNoOpt()

        val session = try {
            ortEnv.createSession(modelFile.absolutePath, sessionOptions)
        } catch (t: Throwable) {
            runCatching { sessionOptions.close() }
            val vocals = isolateVocalsDspFallback(channels, totalFrames, totalChunks, onChunkProgress)
            return@withContext SeparationResult(
                vocals,
                emptyArray(),
                AudioCodec.TARGET_SAMPLE_RATE,
                totalFrames,
                usedDspFallback = true,
                fallbackReason = "HTDemucs session initialization failed: ${t.message ?: t.javaClass.simpleName}"
            )
        }

        // Compute normalization stats in-place without duplicating the entire song array
        var meanAcc = 0.0
        for (i in 0 until totalFrames) {
            meanAcc += (channels[0][i] + channels[1][i]) * 0.5
        }
        val mean = (meanAcc / totalFrames.coerceAtLeast(1).toDouble()).toFloat()
        var varAcc = 0.0
        for (i in 0 until totalFrames) {
            val m = (channels[0][i] + channels[1][i]) * 0.5f - mean
            varAcc += m.toDouble() * m.toDouble()
        }
        val std = sqrt(varAcc / max(1, totalFrames - 1).toDouble()).toFloat().let { if (it < 1e-6f) 1f else it }
        val invStd = 1.0f / std

        val outputVocals = Array(2) { FloatArray(totalFrames) }
        val fadeIn = makeFadeInWindow()
        val fadeOut = FloatArray(fadeIn.size) { i -> 1.0f - fadeIn[i] }
        val segLen = DemucsChunkerAndSpec.SEGMENT_SAMPLES
        val waveformFlat = FloatArray(2 * segLen)
        val chunkBuf = Array(2) { FloatArray(segLen) }

        try {
            var start = 0
            var chunkIndex = 0
            while (start < totalFrames) {
                coroutineContext.ensureActive()
                val end = min(start + segLen, totalFrames)
                val copyLen = end - start

                for (c in 0..1) {
                    val src = channels[c]
                    val dst = chunkBuf[c]
                    dst.fill(0f)
                    for (i in 0 until copyLen) {
                        dst[i] = (src[start + i] - mean) * invStd
                    }
                    System.arraycopy(dst, 0, waveformFlat, c * segLen, segLen)
                }

                val waveformTensor = OnnxTensor.createTensor(
                    ortEnv,
                    FloatBuffer.wrap(waveformFlat),
                    DemucsChunkerAndSpec.WAVEFORM_DIMS
                )

                val isSingleMixModel = session.inputNames.contains("mix") || session.inputNames.size == 1
                val magspecTensor = if (!isSingleMixModel) {
                    val magspecFlat = DemucsChunkerAndSpec.computeMagspec(chunkBuf)
                    OnnxTensor.createTensor(ortEnv, FloatBuffer.wrap(magspecFlat), DemucsChunkerAndSpec.MAGSPEC_DIMS)
                } else null

                val feeds = if (isSingleMixModel) {
                    val inName = session.inputNames.firstOrNull() ?: "mix"
                    mapOf(inName to waveformTensor)
                } else {
                    mapOf(
                        WAVEFORM_INPUT_NAME to waveformTensor,
                        MAGSPEC_INPUT_NAME to magspecTensor!!
                    )
                }

                try {
                    session.run(feeds).use { results ->
                        val vocalsChannels = if (isSingleMixModel) {
                            val stemsTensor = (results.get("stems").orElse(null) ?: results.get(0)) as OnnxTensor
                            val fb = stemsTensor.floatBuffer
                            val stemStride = 2 * segLen
                            val totalElems = fb.remaining()
                            val vocalBase = if (totalElems >= 4 * stemStride) 3 * stemStride else 0
                            val vLeft = FloatArray(segLen)
                            val vRight = FloatArray(segLen)
                            fb.position(vocalBase)
                            fb.get(vLeft, 0, segLen)
                            fb.get(vRight, 0, segLen)
                            arrayOf(vLeft, vRight)
                        } else {
                            val timeTensor = results.get(TIME_OUTPUT_NAME).orElse(null) as? OnnxTensor
                                ?: throw IllegalStateException("Missing HTDemucs output tensor '$TIME_OUTPUT_NAME'")
                            val freqTensor = results.get(FREQ_OUTPUT_NAME).orElse(null) as? OnnxTensor
                                ?: throw IllegalStateException("Missing HTDemucs output tensor '$FREQ_OUTPUT_NAME'")
                            val timeData = FloatArray(timeTensor.floatBuffer.remaining()).also { timeTensor.floatBuffer.get(it) }
                            val freqData = FloatArray(freqTensor.floatBuffer.remaining()).also { freqTensor.floatBuffer.get(it) }
                            DemucsChunkerAndSpec.extractVocalsStem(timeData, freqData)
                        }

                        accumulateChunkInPlace(
                            outputVocals = outputVocals,
                            chunkStart = start,
                            chunkEnd = end,
                            chunkData = vocalsChannels,
                            chunkIndex = chunkIndex,
                            totalChunks = totalChunks,
                            totalFrames = totalFrames,
                            fadeIn = fadeIn,
                            fadeOut = fadeOut
                        )
                    }
                } finally {
                    waveformTensor.close()
                    magspecTensor?.close()
                }

                chunkIndex++
                onChunkProgress(chunkIndex, totalChunks)
                // Let Android UI & thermal/watchdog threads breathe between heavy chunks
                kotlinx.coroutines.delay(15)
                if (end >= totalFrames) break
                start += DemucsChunkerAndSpec.STRIDE_SAMPLES
            }
        } finally {
            runCatching { session.close() }
            runCatching { sessionOptions.close() }
        }

        DemucsChunkerAndSpec.denormalizeDemucsOutput(outputVocals, NormalizationStats(mean, std))
        SeparationResult(
            vocals = outputVocals,
            instrumental = emptyArray(),
            sampleRate = AudioCodec.TARGET_SAMPLE_RATE,
            totalFrames = totalFrames
        )
    }

    /**
     * Zero-Freeze Studio STFT Mid/Side + Harmonic-Percussive Vocal Formant Isolator (135 Hz – 9200 Hz).
     * Processes in a streaming loop directly into `outputVocals` (< 45 MB RAM, 0 native OOM risk)
     * while cleanly isolating lead + background vocals from bass, kick drums, and stereo accompaniment.
     */
    private suspend fun isolateVocalsDspFallback(
        channels: Array<FloatArray>,
        totalFrames: Int,
        totalChunks: Int,
        onChunkProgress: suspend (Int, Int) -> Unit
    ): Array<FloatArray> {
        val minBin = (220.0 * StftProcessor.N_FFT / AudioCodec.TARGET_SAMPLE_RATE).toInt()
        val maxBin = (6800.0 * StftProcessor.N_FFT / AudioCodec.TARGET_SAMPLE_RATE).toInt()
        val formantCoreLow = (280.0 * StftProcessor.N_FFT / AudioCodec.TARGET_SAMPLE_RATE).toInt()
        val formantCoreHigh = (3800.0 * StftProcessor.N_FFT / AudioCodec.TARGET_SAMPLE_RATE).toInt()

        val sharedMonoOut = FloatArray(totalFrames)
        val singleChTarget = arrayOf(sharedMonoOut)
        val fadeIn = makeFadeInWindow()
        val fadeOut = FloatArray(fadeIn.size) { i -> 1.0f - fadeIn[i] }
        val len = DemucsChunkerAndSpec.SEGMENT_SAMPLES
        val mid = FloatArray(len)
        val side = FloatArray(len)

        var start = 0
        var chunkIdx = 0
        while (start < totalFrames) {
            coroutineContext.ensureActive()
            val end = min(start + len, totalFrames)
            val copyLen = end - start
            mid.fill(0f)
            side.fill(0f)
            val ch0 = channels[0]
            val ch1 = channels[1]
            for (i in 0 until copyLen) {
                val l = ch0[start + i]
                val r = ch1[start + i]
                mid[i] = 0.5f * (l + r)
                side[i] = 0.5f * (l - r)
            }

            val specMid = StftProcessor.stft(mid, center = true, normalized = false)
            val specSide = StftProcessor.stft(side, center = true, normalized = false)
            val numBins = specMid.numBins
            val numFrames = specMid.numFrames

            for (f in 0 until numFrames) {
                val base = f * numBins
                // Compute spectral flatness across vocal band to detect broadband drum hits (snare/clap)
                var sumMag = 1e-7
                var sumLogMag = 0.0
                val binCount = (maxBin - minBin + 1).coerceAtLeast(1)
                for (b in minBin..maxBin) {
                    val idx = base + b
                    val m = hypot(specMid.real[idx].toDouble(), specMid.imag[idx].toDouble()).coerceAtLeast(1e-7)
                    sumMag += m
                    sumLogMag += kotlin.math.ln(m)
                }
                val geoMean = kotlin.math.exp(sumLogMag / binCount)
                val arithMean = sumMag / binCount
                val flatness = (geoMean / arithMean).toFloat().coerceIn(0f, 1f)
                // Broadband percussive transient gate (attenuates flat broadband snare/clap spikes)
                val percussiveGate = (1.0f - (flatness - 0.32f).coerceAtLeast(0f) * 1.4f).coerceIn(0.15f, 1.0f)

                for (b in 0 until numBins) {
                    val idx = base + b
                    if (b !in minBin..maxBin) {
                        specMid.real[idx] = 0f
                        specMid.imag[idx] = 0f
                    } else {
                        val magM = hypot(specMid.real[idx], specMid.imag[idx])
                        val magS = hypot(specSide.real[idx], specSide.imag[idx])
                        // Direct spectral subtraction of stereo side instrumentation
                        val sideWeight = if (b in formantCoreLow..formantCoreHigh) 2.0f else 2.6f
                        val cleanMag = (magM - sideWeight * magS).coerceAtLeast(0f)
                        val softMask = if (magM > 1e-7f) (cleanMag / magM) else 0f
                        val gain = (softMask * softMask * percussiveGate).coerceIn(0f, 1f)
                        specMid.real[idx] *= gain
                        specMid.imag[idx] *= gain
                    }
                }
            }

            val vocalMono = StftProcessor.istft(specMid, len, normalized = false)
            accumulateChunkInPlace(
                outputVocals = singleChTarget,
                chunkStart = start,
                chunkEnd = end,
                chunkData = arrayOf(vocalMono),
                chunkIndex = chunkIdx,
                totalChunks = totalChunks,
                totalFrames = totalFrames,
                fadeIn = fadeIn,
                fadeOut = fadeOut
            )

            chunkIdx++
            onChunkProgress(chunkIdx, totalChunks)
            kotlinx.coroutines.delay(5)
            if (end >= totalFrames) break
            start += DemucsChunkerAndSpec.STRIDE_SAMPLES
        }
        return arrayOf(sharedMonoOut, sharedMonoOut)
    }
}

// ================================================================================================
// 6. SPECTRAL FLUX ONSET DETECTOR & SNAPPER (Mirrors src/audio/onset-detection.ts)
// ================================================================================================

data class DetectVocalOnsetsOptions(
    val sampleRate: Int = AudioCodec.TARGET_SAMPLE_RATE,
    val compression: Double = 1000.0,
    val medianWindowFrames: Int = 8,
    val thresholdDelta: Float = 0.08f,
    val minSpacingSeconds: Double = 0.08,
    val minRms: Float = 0.004f,
    val minFrequency: Double = 180.0,
    val maxFrequency: Double = 8000.0
)

data class SpectralFluxAnalysis(
    val novelty: FloatArray,
    val rms: FloatArray,
    val onsetsSeconds: DoubleArray
)

object SpectralOnsetDetector {

    /**
     * Exact port of mixToMono in src/audio/onset-detection.ts
     */
    fun mixToMono(channels: Array<FloatArray>): FloatArray {
        val ch0 = channels.getOrNull(0) ?: return FloatArray(0)
        val length = ch0.size
        if (length == 0) return FloatArray(0)
        // Zero-copy fast path when single-channel or shared L/R reference
        if (channels.size == 1 || (channels.size == 2 && channels[0] === channels[1])) {
            return ch0
        }
        val out = FloatArray(length)
        val invCh = 1.0f / channels.size.toFloat()
        for (i in 0 until length) {
            var sum = 0f
            for (ch in channels) sum += ch[i]
            out[i] = sum * invCh
        }
        return out
    }

    private fun median(values: FloatArray, start: Int, endExclusive: Int): Float {
        val len = endExclusive - start
        if (len <= 0) return 0f
        val slice = values.copyOfRange(start, endExclusive)
        slice.sort()
        return slice[len / 2]
    }

    /**
     * Exact port of frameRms in src/audio/onset-detection.ts
     */
    fun frameRms(mono: FloatArray, frame: Int): Float {
        val center = frame * StftProcessor.HOP_LENGTH
        val start = max(0, center - StftProcessor.N_FFT / 2)
        val end = min(mono.size, start + StftProcessor.N_FFT)
        if (end <= start) return 0f
        var energy = 0.0
        for (i in start until end) {
            val s = mono[i].toDouble()
            energy += s * s
        }
        return sqrt(energy / (end - start).toDouble()).toFloat()
    }

    private fun frameRmsStereo(ch0: FloatArray, ch1: FloatArray?, frame: Int): Float {
        val center = frame * StftProcessor.HOP_LENGTH
        val start = max(0, center - StftProcessor.N_FFT / 2)
        val end = min(ch0.size, start + StftProcessor.N_FFT)
        if (end <= start) return 0f
        var energy = 0.0
        if (ch1 == null) {
            for (i in start until end) {
                val s = ch0[i].toDouble()
                energy += s * s
            }
        } else {
            for (i in start until end) {
                val s = 0.5 * (ch0[i].toDouble() + ch1[i].toDouble())
                energy += s * s
            }
        }
        return sqrt(energy / (end - start).toDouble()).toFloat()
    }

    private inline fun reflectedSampleIndex(rawIdx: Int, size: Int): Int {
        val lastIdx = size - 1
        return when {
            rawIdx < 0 -> (-rawIdx).coerceAtMost(lastIdx)
            rawIdx >= size -> (2 * lastIdx - rawIdx).coerceAtLeast(0)
            else -> rawIdx
        }
    }

    /**
     * Zero-full-song-allocation stereo/mono spectral flux onset analyzer.
     * Avoids allocating both a 69 MB `mixToMono` array and a 69 MB `reflectPad` array on long songs.
     */
    fun analyzeVocalChannels(
        channels: Array<FloatArray>,
        options: DetectVocalOnsetsOptions = DetectVocalOnsetsOptions()
    ): SpectralFluxAnalysis {
        val ch0 = channels.getOrNull(0) ?: return SpectralFluxAnalysis(FloatArray(0), FloatArray(0), DoubleArray(0))
        val ch1 = if (channels.size > 1 && channels[1].size == ch0.size && channels[1] !== ch0) channels[1] else null
        return analyzeVocalInternal(ch0, ch1, options)
    }

    /**
     * Exact port of spectralFlux & detectVocalOnsets in src/audio/onset-detection.ts
     */
    fun analyzeVocalStem(
        mono: FloatArray,
        options: DetectVocalOnsetsOptions = DetectVocalOnsetsOptions()
    ): SpectralFluxAnalysis = analyzeVocalInternal(mono, null, options)

    private fun analyzeVocalInternal(
        ch0: FloatArray,
        ch1: FloatArray?,
        options: DetectVocalOnsetsOptions
    ): SpectralFluxAnalysis {
        val sampleRate = options.sampleRate
        val size = ch0.size
        if (sampleRate <= 0 || size == 0) {
            return SpectralFluxAnalysis(FloatArray(0), FloatArray(0), DoubleArray(0))
        }

        val nFft = StftProcessor.N_FFT
        val halfFft = nFft / 2
        val hop = StftProcessor.HOP_LENGTH
        val numBins = halfFft + 1
        val framedSize = size + nFft
        val numFrames = 1 + (framedSize - nFft) / hop
        val window = StftProcessor.hannWindow(nFft)
        val frameReal = FloatArray(nFft)
        val frameImag = FloatArray(nFft)

        val novelty = FloatArray(numFrames)
        val rms = FloatArray(numFrames)

        val minBin = max(1, floor((options.minFrequency * nFft) / sampleRate.toDouble()).toInt())
        val maxBin = min(
            numBins - 1,
            ceil((options.maxFrequency * nFft) / sampleRate.toDouble()).toInt()
        )
        val usedBinCount = max(1, maxBin - minBin + 1).toFloat()
        val prevMag = FloatArray(numBins)
        var maxNovelty = 0f

        for (frame in 0 until numFrames) {
            val rawBase = frame * hop - halfFft
            if (ch1 == null) {
                if (rawBase >= 0 && rawBase + nFft <= size) {
                    for (i in 0 until nFft) {
                        frameReal[i] = ch0[rawBase + i] * window[i]
                        frameImag[i] = 0f
                    }
                } else {
                    for (i in 0 until nFft) {
                        val sIdx = reflectedSampleIndex(rawBase + i, size)
                        frameReal[i] = ch0[sIdx] * window[i]
                        frameImag[i] = 0f
                    }
                }
            } else {
                if (rawBase >= 0 && rawBase + nFft <= size) {
                    for (i in 0 until nFft) {
                        val idx = rawBase + i
                        frameReal[i] = 0.5f * (ch0[idx] + ch1[idx]) * window[i]
                        frameImag[i] = 0f
                    }
                } else {
                    for (i in 0 until nFft) {
                        val sIdx = reflectedSampleIndex(rawBase + i, size)
                        frameReal[i] = 0.5f * (ch0[sIdx] + ch1[sIdx]) * window[i]
                        frameImag[i] = 0f
                    }
                }
            }
            StftProcessor.fftRadix2(frameReal, frameImag)

            var flux = 0f
            for (bin in minBin..maxBin) {
                val re = frameReal[bin].toDouble()
                val im = frameImag[bin].toDouble()
                val mag = ln1p(options.compression * hypot(re, im)).toFloat()
                val diff = mag - prevMag[bin]
                if (diff > 0f) flux += diff
                prevMag[bin] = mag
            }
            rms[frame] = frameRmsStereo(ch0, ch1, frame)
            novelty[frame] = flux / usedBinCount
            if (novelty[frame] > maxNovelty) maxNovelty = novelty[frame]
        }

        if (maxNovelty > 0f) {
            for (i in novelty.indices) novelty[i] /= maxNovelty
        }

        val minSpacingFrames = max(
            1,
            ((options.minSpacingSeconds * sampleRate.toDouble()) / StftProcessor.HOP_LENGTH.toDouble()).roundToInt()
        )

        data class Candidate(val frame: Int, val score: Float)
        val candidates = mutableListOf<Candidate>()

        for (i in 1 until novelty.size - 1) {
            if (rms[i] < options.minRms) continue
            if (novelty[i] <= novelty[i - 1] || novelty[i] < novelty[i + 1]) continue
            val start = max(0, i - options.medianWindowFrames)
            val end = min(novelty.size, i + options.medianWindowFrames + 1)
            val threshold = median(novelty, start, end) + options.thresholdDelta
            if (novelty[i] >= threshold) {
                candidates.add(Candidate(i, novelty[i]))
            }
        }

        val selected = mutableListOf<Candidate>()
        for (candidate in candidates) {
            val previous = selected.lastOrNull()
            if (previous == null || candidate.frame - previous.frame >= minSpacingFrames) {
                selected.add(candidate)
            } else if (candidate.score > previous.score) {
                selected[selected.lastIndex] = candidate
            }
        }

        val onsets = DoubleArray(selected.size) { idx ->
            (selected[idx].frame.toDouble() * StftProcessor.HOP_LENGTH.toDouble()) / sampleRate.toDouble()
        }

        return SpectralFluxAnalysis(novelty = novelty, rms = rms, onsetsSeconds = onsets)
    }

    fun detectVocalOnsets(
        mono: FloatArray,
        options: DetectVocalOnsetsOptions = DetectVocalOnsetsOptions()
    ): DoubleArray = analyzeVocalStem(mono, options).onsetsSeconds
}

// ================================================================================================
// 7. STAGE 4: VOCAL ONSET SNAPPING & RMS SILENCE-GATE OFFSET CLAMPING
// ================================================================================================

object VocalOnsetSnapper {
    private const val SNAP_TOLERANCE_EARLY_SEC = 0.040 // Snap up to 40ms earlier for consonant plosives
    private const val SNAP_TOLERANCE_LATE_SEC = 0.030  // Snap up to 30ms later

    /**
     * Refines word `begin` and `end` timestamps using spectral flux onsets and adaptive per-word RMS:
     * 1. Snaps word `begin` to nearby micro-transient vocal onsets within [-40ms, +30ms] while keeping
     *    legato word transitions contiguous (`prev.end == current.begin` when gap < 60ms).
     * 2. Uses an adaptive RMS gate relative to each word's own peak vocal energy (`0.12 * wordPeakRms`)
     *    so quiet/softly sung words are NEVER chopped down to 100ms.
     * 3. Extends sustained Arabic Madd vowels (`ا، و، ي`) and line-final melismas until vocal energy
     *    genuinely drops below `0.18 * wordPeakRms`.
     */
    fun snapAndClampLines(
        lines: List<LyricLine>,
        analysis: SpectralFluxAnalysis,
        sampleRate: Int = AudioCodec.TARGET_SAMPLE_RATE,
        backingAnalysis: SpectralFluxAnalysis? = null,
        hasArabicMaddPredicate: (String) -> Boolean
    ): List<LyricLine> {
        if (analysis.rms.isEmpty()) return lines
        val frameDurationSec = StftProcessor.HOP_LENGTH.toDouble() / sampleRate.toDouble()
        val onsets = analysis.onsetsSeconds
        val bgSpec = backingAnalysis?.takeIf { it.rms.isNotEmpty() } ?: analysis

        return lines.mapIndexed { lineIdx, line ->
            // Singer-Aware & Word-Aware Clamping (Part B.6 & Phase 5):
            // Only clamp a line's tail against the ACTUAL aligned first word of the next line of the SAME agentId
            // (never an unverified line timestamp, and never an overlapping v2 harmony/duet line!).
            val nextSameAgentBegin = ((lineIdx + 1) until lines.size).firstNotNullOfOrNull { idx ->
                lines[idx].takeIf { it.agentId == line.agentId }?.let { nextLine ->
                    nextLine.words?.firstOrNull()?.begin ?: nextLine.effectiveBounds()?.begin
                }
            }
            val refinedWords = line.words?.let { words ->
                snapWordList(
                    words = words,
                    onsets = onsets,
                    rms = analysis.rms,
                    frameDurationSec = frameDurationSec,
                    maxLineEnd = nextSameAgentBegin,
                    hasArabicMaddPredicate = hasArabicMaddPredicate
                )
            }
            val refinedBgWords = line.backgroundWords?.let { bgWords ->
                snapWordList(
                    words = bgWords,
                    onsets = bgSpec.onsetsSeconds,
                    rms = bgSpec.rms,
                    frameDurationSec = frameDurationSec,
                    maxLineEnd = nextSameAgentBegin?.let { it + 0.45 },
                    hasArabicMaddPredicate = hasArabicMaddPredicate
                )
            }
            line.copy(
                words = refinedWords,
                backgroundWords = refinedBgWords
            ).reconcile()
        }
    }

    private fun snapWordList(
        words: List<WordTiming>,
        onsets: DoubleArray,
        rms: FloatArray,
        frameDurationSec: Double,
        maxLineEnd: Double?,
        hasArabicMaddPredicate: (String) -> Boolean
    ): List<WordTiming> {
        if (words.isEmpty()) return words
        val result = words.toMutableList()

        // Pass 1: Snap word `begin` to nearest spectral onset within [-35ms, +25ms]
        // WITHOUT pulling the previous word's `end` forward across a pause!
        for (i in result.indices) {
            val w = result[i]
            val prevEnd = if (i > 0) result[i - 1].end else 0.0
            val wasTightLegatoWithPrev = i > 0 && (w.begin - result[i - 1].end) < 0.015

            var snappedBegin = w.begin
            val searchMin = max(if (wasTightLegatoWithPrev) prevEnd - 0.015 else prevEnd, w.begin - 0.035)
            val searchMax = min(w.end - 0.08, w.begin + 0.025)
            var bestDist = Double.MAX_VALUE
            for (onset in onsets) {
                if (onset < searchMin) continue
                if (onset > searchMax) break
                val dist = abs(onset - w.begin)
                if (dist < bestDist) {
                    bestDist = dist
                    snappedBegin = onset
                }
            }

            if (wasTightLegatoWithPrev && i > 0 && snappedBegin > result[i - 1].begin + 0.08) {
                result[i - 1] = result[i - 1].copy(end = min(result[i - 1].end, snappedBegin))
            }
            result[i] = w.copy(begin = snappedBegin, end = max(snappedBegin + 0.08, w.end))
        }

        // Pass 2: Sustained-Voice Follower & True-Pause Trimmer (requires >= 3 consecutive 23ms frames
        // = ~70ms of low RMS < 18% of wordPeakRms before ending a word, AND extends held final words
        // if the singer is still sustaining the note on the isolated vocal stem!)
        for (i in result.indices) {
            val w = result[i]
            val nextWord = result.getOrNull(i + 1)
            val nextBegin = nextWord?.begin ?: maxLineEnd ?: (w.end + 2.5)

            val safeLastIdx = rms.lastIndex.coerceAtLeast(0)
            val startFrame = (w.begin / frameDurationSec).roundToInt().coerceIn(0, safeLastIdx)
            val rawEndFrame = (w.end / frameDurationSec).roundToInt().coerceIn(startFrame, safeLastIdx.coerceAtLeast(startFrame))
            val maxEndFrame = (nextBegin / frameDurationSec).roundToInt().coerceIn(rawEndFrame, safeLastIdx.coerceAtLeast(rawEndFrame))

            var wordPeakRms = 0.001f
            for (f in startFrame..rawEndFrame) {
                if (rms[f] > wordPeakRms) {
                    wordPeakRms = rms[f]
                }
            }

            // Phase 3 Premature-End Fix in Stage 4:
            // Do NOT break forward on the first 3-frame dip inside `[scanStart..rawEndFrame]` (which previously
            // truncated words on internal Shadda geminate stops or deep vibrato troughs!).
            // Instead:
            //   1. Scan BACKWARD from `rawEndFrame` down to `scanStart` to find the LAST active vocal frame
            //      within the word's initial span (trimming only genuine trailing silence at the very end).
            //   2. If the singer is still vocalizing near `rawEndFrame` (`lastActiveFrame >= rawEndFrame - 2`),
            //      follow the sustained vocal hold forward up to `maxHoldLimit` (+2.60s) until >= 4 consecutive
            //      silent frames (~92ms below 15% of wordPeakRms) occur.
            val vocalStopFloor = max(0.0022f, wordPeakRms * 0.095f)
            val vocalHoldFloor = max(0.0036f, wordPeakRms * 0.155f)
            val minWordFrames = max(5, (0.12 / frameDurationSec).roundToInt())
            val scanStart = min(rawEndFrame, startFrame + minWordFrames)

            var lastActiveFrame = scanStart
            for (f in rawEndFrame downTo scanStart) {
                if (rms[f] >= vocalStopFloor) {
                    lastActiveFrame = f
                    break
                }
            }

            if (lastActiveFrame >= rawEndFrame - 2) {
                val maxHoldLimit = min(maxEndFrame, rawEndFrame + (2.60 / frameDurationSec).roundToInt())
                var silentCount = 0
                for (f in (rawEndFrame + 1)..maxHoldLimit) {
                    if (rms[f] >= vocalHoldFloor) {
                        silentCount = 0
                        lastActiveFrame = f
                    } else {
                        silentCount++
                        if (silentCount >= 4) break
                    }
                }
            }

            val minEnd = w.begin + 0.12
            val refinedEnd = (lastActiveFrame * frameDurationSec).coerceIn(minEnd, max(minEnd, nextBegin - 0.01))
            result[i] = w.copy(end = refinedEnd)
        }

        return WordSpacesAndSyllables.closeIntraGroupGaps(result)
    }
}

// ================================================================================================
// 8. STAGE 2B: TWO-STAGE LEAD vs. BACKING VOCAL ISOLATOR
//    Supports UVR MDX-Net Karaoke ONNX (`UVR_MDXNET_KARA_2.onnx` / SplitScope architecture)
//    + Panning-Agnostic Spatial Covariance & Harmonic Prominence Subspace Decomposition.
// ================================================================================================

enum class LeadBackingSeparationMethod(val description: String) {
    ONNX_UVR_MDXNET_KARA("UVR MDX-Net Karaoke Neural Lead/Backing Separator (ONNX)"),
    STEREO_HARMONIC_SUBSPACE("Panning-Agnostic Spatial Covariance + Harmonic Prominence Decomposition"),
    UNSEPARATED_FALLBACK("Combined Vocal Stem Fallback (Single-Layer / Inseparable)")
}

data class LeadBackingSeparationResult(
    val leadVocals: Array<FloatArray>,
    val backingVocals: Array<FloatArray>,
    val method: LeadBackingSeparationMethod,
    val separationConfidence: Float,
    val hasDistinctBackingStem: Boolean
)

class LeadBackingVocalSeparator(
    explicitOrtEnv: OrtEnvironment? = null
) {
    private val ortEnv: OrtEnvironment by lazy { explicitOrtEnv ?: OrtEnvironment.getEnvironment() }
    /**
     * Separates the Stage-2A combined stereo vocal stem (`vocalChannels44k`) into:
     *   1. `leadVocals`: Primary solo / lead singer (`v1`).
     *   2. `backingVocals`: Harmonies, chorus responses, delayed vocal doubles, and ad-libs (`v2` / `x-bg`).
     *
     * Does NOT assume that lead vocals are always dead-center or that backing vocals are always hard-panned:
     *   - When an MDX-Net Karaoke ONNX model (`uvr_mdxnet_kara_2.onnx`) is installed and heap allows, runs
     *     chunked complex STFT neural inference (`[1, 4, dimF, dimT]`).
     *   - Otherwise estimates the dominant vocal spatial eigenvector `(alphaL, alphaR)` per window in the
     *     vocal formant band (`300-2800 Hz`) and decomposes dominant harmonic peaks vs secondary chorus/harmony
     *     tails, reporting a calibrated `separationConfidence` in `[0.0f..1.0f]`.
     */
    suspend fun separateLeadAndBacking(
        vocalChannels44k: Array<FloatArray>,
        mdxKaraokeModelFile: File? = null,
        reuseInputBuffersInPlace: Boolean = false,
        onProgress: suspend (Float) -> Unit = {}
    ): LeadBackingSeparationResult = withContext(Dispatchers.Default) {
        val totalFrames = vocalChannels44k.getOrNull(0)?.size ?: 0
        if (vocalChannels44k.size < 2 || totalFrames < StftProcessor.N_FFT * 2) {
            return@withContext LeadBackingSeparationResult(
                leadVocals = vocalChannels44k,
                backingVocals = vocalChannels44k,
                method = LeadBackingSeparationMethod.UNSEPARATED_FALLBACK,
                separationConfidence = 0.0f,
                hasDistinctBackingStem = false
            )
        }

        // 1. Try UVR MDX-Net Karaoke ONNX model if installed and device heap is sufficient
        val runtime = Runtime.getRuntime()
        val maxHeapMb = runtime.maxMemory() / (1024L * 1024L)
        val usedHeapMb = (runtime.totalMemory() - runtime.freeMemory()) / (1024L * 1024L)
        val freeHeadroomMb = maxHeapMb - usedHeapMb
        if (mdxKaraokeModelFile != null && mdxKaraokeModelFile.exists() && mdxKaraokeModelFile.length() > 1024L && maxHeapMb >= 384L && freeHeadroomMb >= 180L) {
            val onnxResult = runCatching {
                runUvrMdxNetKaraokeOnnx(vocalChannels44k, totalFrames, mdxKaraokeModelFile, onProgress)
            }.getOrNull()
            if (onnxResult != null) return@withContext onnxResult
        }

        // 2. Panning-Agnostic Spatial Covariance + Harmonic Prominence Subspace Decomposition
        separateBySpatialAndHarmonicSubspace(vocalChannels44k, totalFrames, reuseInputBuffersInPlace, onProgress)
    }

    private suspend fun runUvrMdxNetKaraokeOnnx(
        vocalChannels44k: Array<FloatArray>,
        totalFrames: Int,
        modelFile: File,
        onProgress: suspend (Float) -> Unit
    ): LeadBackingSeparationResult {
        val opts = OnnxProviders.createSessionOptionsNoOpt()
        val session = ortEnv.createSession(modelFile.absolutePath, opts)
        try {
            val inName = session.inputNames.firstOrNull() ?: "input"
            val inInfo = session.inputInfo[inName]?.info as? ai.onnxruntime.TensorInfo
            val shape = inInfo?.shape ?: longArrayOf(1L, 4L, 2048L, 256L)
            val dimF = if (shape.size >= 4 && shape[2] > 0) shape[2].toInt() else 2048
            val dimT = if (shape.size >= 4 && shape[3] > 0) shape[3].toInt() else 256

            val nFft = StftProcessor.N_FFT // 4096-point radix-2 FFT
            val hop = 1024
            val chunkSamples = (dimT - 1) * hop + nFft
            val strideSamples = chunkSamples // Non-overlapping windows on mobile CPU (2x faster)
            val leadMonoOut = FloatArray(totalFrames)
            val backMonoOut = FloatArray(totalFrames)

            val window = StftProcessor.hannWindow(nFft)
            val tensorFlat = FloatArray(4 * dimF * dimT)
            val totalChunks = max(1, (totalFrames - chunkSamples / 2) / strideSamples + 1)

            var start = 0
            var chunkIdx = 0
            while (start < totalFrames) {
                coroutineContext.ensureActive()
                val end = min(totalFrames, start + chunkSamples)
                val copyLen = end - start

                val chSpecs = Array(2) { c ->
                    val seg = FloatArray(chunkSamples)
                    System.arraycopy(vocalChannels44k[c], start, seg, 0, copyLen)
                    StftProcessor.stft(seg, center = true, normalized = true)
                }

                val planeStride = dimF * dimT
                val usableBins = min(dimF, chSpecs[0].numBins)
                val usableFrames = min(dimT, chSpecs[0].numFrames)
                tensorFlat.fill(0f)

                for (c in 0..1) {
                    val spec = chSpecs[c]
                    val rBase = (c * 2) * planeStride
                    val iBase = (c * 2 + 1) * planeStride
                    for (b in 0 until usableBins) {
                        val rowOff = b * dimT
                        for (t in 0 until usableFrames) {
                            val sIdx = t * spec.numBins + b
                            tensorFlat[rBase + rowOff + t] = spec.real[sIdx]
                            tensorFlat[iBase + rowOff + t] = spec.imag[sIdx]
                        }
                    }
                }

                val inputTensor = OnnxTensor.createTensor(
                    ortEnv,
                    FloatBuffer.wrap(tensorFlat),
                    longArrayOf(1L, 4L, dimF.toLong(), dimT.toLong())
                )
                try {
                    session.run(mapOf(inName to inputTensor)).use { res ->
                        val outTensor = res.get(0) as OnnxTensor
                        val outFlat = FloatArray(outTensor.floatBuffer.remaining())
                        outTensor.floatBuffer.get(outFlat)

                        for (c in 0..1) {
                            val origSpec = chSpecs[c]
                            val leadReal = FloatArray(origSpec.real.size)
                            val leadImag = FloatArray(origSpec.imag.size)
                            val rBase = (c * 2) * planeStride
                            val iBase = (c * 2 + 1) * planeStride
                            for (b in 0 until usableBins) {
                                val rowOff = b * dimT
                                for (t in 0 until usableFrames) {
                                    val sIdx = t * origSpec.numBins + b
                                    leadReal[sIdx] = outFlat[rBase + rowOff + t]
                                    leadImag[sIdx] = outFlat[iBase + rowOff + t]
                                }
                            }
                            val leadWave = StftProcessor.istft(
                                Spectrogram(leadReal, leadImag, origSpec.numFrames, origSpec.numBins),
                                chunkSamples,
                                normalized = true
                            )
                            for (i in 0 until copyLen) {
                                val gIdx = start + i
                                val lv = leadWave[i]
                                val bv = vocalChannels44k[c][gIdx] - lv
                                leadMonoOut[gIdx] += 0.5f * lv
                                backMonoOut[gIdx] += 0.5f * bv
                            }
                        }
                    }
                } finally {
                    inputTensor.close()
                }

                chunkIdx++
                onProgress(chunkIdx.toFloat() / totalChunks.toFloat())
                if (end >= totalFrames) break
                start += strideSamples
            }

            val leadOut = arrayOf(leadMonoOut, leadMonoOut)
            val backOut = arrayOf(backMonoOut, backMonoOut)
            val conf = computeBackingSeparationConfidence(leadOut, backOut, totalFrames)
            return LeadBackingSeparationResult(
                leadVocals = leadOut,
                backingVocals = backOut,
                method = LeadBackingSeparationMethod.ONNX_UVR_MDXNET_KARA,
                separationConfidence = conf,
                hasDistinctBackingStem = conf >= 0.18f
            )
        } finally {
            runCatching { session.close() }
            runCatching { opts.close() }
        }
    }

    /**
     * Panning-Agnostic Spatial Covariance + Harmonic Prominence Lead/Backing Decomposer:
     * 1. Estimates the dominant vocal panning direction `(panL, panR)` in each 7.8s window from the
     *    2x2 spatial energy distribution in the primary F1/F2 vocal band (`300-2800 Hz`) so panned lead
     *    vocals are tracked accurately without assuming dead-center panning.
     * 2. Separates the dominant vocal projection (`lead`) from the orthogonal spatial + secondary
     *    harmonic chorus/echo layer (`backing`).
     */
    private suspend fun separateBySpatialAndHarmonicSubspace(
        vocalChannels44k: Array<FloatArray>,
        totalFrames: Int,
        reuseInputBuffersInPlace: Boolean = false,
        onProgress: suspend (Float) -> Unit
    ): LeadBackingSeparationResult {
        // When `reuseInputBuffersInPlace` is true and L/R are distinct arrays, write `leadMono` into
        // `vocalChannels44k[0]` and `backMono` into `vocalChannels44k[1]` with ZERO new full-song allocation!
        // Otherwise allocate a single mono array per layer (saving 2 x 69 MB = 138 MB on a 6.5-minute song).
        val canWriteInPlace = reuseInputBuffersInPlace && vocalChannels44k.size >= 2 && vocalChannels44k[0] !== vocalChannels44k[1]
        val leadMonoOut = if (canWriteInPlace) vocalChannels44k[0] else FloatArray(totalFrames)
        val backMonoOut = if (canWriteInPlace) vocalChannels44k[1] else FloatArray(totalFrames)
        val len = DemucsChunkerAndSpec.SEGMENT_SAMPLES
        val totalChunks = DemucsChunkerAndSpec.chunkCount(totalFrames)
        val minFormantBin = (300.0 * StftProcessor.N_FFT / AudioCodec.TARGET_SAMPLE_RATE).toInt().coerceAtLeast(1)
        val maxFormantBin = (2800.0 * StftProcessor.N_FFT / AudioCodec.TARGET_SAMPLE_RATE).toInt()

        var start = 0
        var chunkIdx = 0
        while (start < totalFrames) {
            coroutineContext.ensureActive()
            val end = min(totalFrames, start + len)
            val copyLen = end - start

            val segL = FloatArray(len)
            val segR = FloatArray(len)
            System.arraycopy(vocalChannels44k[0], start, segL, 0, copyLen)
            System.arraycopy(vocalChannels44k[1], start, segR, 0, copyLen)

            val specL = StftProcessor.stft(segL, center = true, normalized = false)
            val specR = StftProcessor.stft(segR, center = true, normalized = false)
            val numBins = specL.numBins
            val numFrames = specL.numFrames

            // Estimate dominant singer panning weights (panL, panR) over active vocal frames
            var eLL = 1e-6
            var eRR = 1e-6
            var eLR = 0.0
            for (f in 0 until numFrames) {
                val base = f * numBins
                for (b in minFormantBin..min(maxFormantBin, numBins - 1)) {
                    val idx = base + b
                    val lRe = specL.real[idx].toDouble()
                    val lIm = specL.imag[idx].toDouble()
                    val rRe = specR.real[idx].toDouble()
                    val rIm = specR.imag[idx].toDouble()
                    eLL += lRe * lRe + lIm * lIm
                    eRR += rRe * rRe + rIm * rIm
                    eLR += lRe * rRe + lIm * rIm
                }
            }
            val normPan = sqrt(eLL + eRR).coerceAtLeast(1e-6)
            val panL = sqrt(eLL / (eLL + eRR)).toFloat().coerceIn(0.25f, 0.95f)
            val panR = sqrt(eRR / (eLL + eRR)).toFloat().coerceIn(0.25f, 0.95f)
            val stereoCorrelation = (eLR / (sqrt(eLL * eRR).coerceAtLeast(1e-6))).toFloat().coerceIn(-1f, 1f)

            val leadReal = FloatArray(specL.real.size)
            val leadImag = FloatArray(specL.imag.size)
            val backReal = FloatArray(specL.real.size)
            val backImag = FloatArray(specL.imag.size)

            for (f in 0 until numFrames) {
                val base = f * numBins
                // Find peak bin magnitude in current frame to distinguish dominant lead harmonics from lower-level harmony/echo layers
                var framePeakMag = 1e-6f
                for (b in minFormantBin..min(maxFormantBin, numBins - 1)) {
                    val idx = base + b
                    val m = hypot(specL.real[idx], specL.imag[idx]) + hypot(specR.real[idx], specR.imag[idx])
                    if (m > framePeakMag) framePeakMag = m
                }

                for (b in 0 until numBins) {
                    val idx = base + b
                    val lRe = specL.real[idx]
                    val lIm = specL.imag[idx]
                    val rRe = specR.real[idx]
                    val rIm = specR.imag[idx]

                    // Dominant spatial projection (panning-agnostic) & orthogonal side projection
                    val domRe = panL * lRe + panR * rRe
                    val domIm = panL * lIm + panR * rIm
                    val orthoRe = panR * lRe - panL * rRe
                    val orthoIm = panR * lIm - panL * rIm

                    val domMag = hypot(domRe, domIm)
                    val orthoMag = hypot(orthoRe, orthoIm)
                    val harmonicProminence = (domMag / (framePeakMag * 0.35f + 1e-6f)).coerceIn(0f, 1f)
                    val spatialMask = if (domMag + orthoMag > 1e-7f) {
                        (domMag / (domMag + 1.35f * orthoMag)).coerceIn(0f, 1f)
                    } else 0.5f

                    // Combine spatial dominance and harmonic prominence so both panned backing vocals and softer reverberant doubles separate
                    val leadMask = if (stereoCorrelation > 0.96f) {
                        // Nearly mono vocal stem: rely on harmonic prominence mask
                        (0.35f + 0.65f * harmonicProminence).coerceIn(0.25f, 0.95f)
                    } else {
                        (0.65f * spatialMask + 0.35f * harmonicProminence).coerceIn(0.05f, 0.98f)
                    }

                    leadReal[idx] = domRe * leadMask
                    leadImag[idx] = domIm * leadMask
                    backReal[idx] = orthoRe + domRe * (1.0f - leadMask) * 0.65f
                    backImag[idx] = orthoIm + domIm * (1.0f - leadMask) * 0.65f
                }
            }

            val leadMono = StftProcessor.istft(Spectrogram(leadReal, leadImag, numFrames, numBins), len, normalized = false)
            val backMono = StftProcessor.istft(Spectrogram(backReal, backImag, numFrames, numBins), len, normalized = false)

            for (i in 0 until copyLen) {
                val gIdx = start + i
                leadMonoOut[gIdx] = leadMono[i]
                backMonoOut[gIdx] = backMono[i]
            }

            chunkIdx++
            onProgress(chunkIdx.toFloat() / totalChunks.toFloat())
            kotlinx.coroutines.delay(5)
            if (end >= totalFrames) break
            start += len
        }

        val leadOut = arrayOf(leadMonoOut, leadMonoOut)
        val backOut = arrayOf(backMonoOut, backMonoOut)
        val conf = computeBackingSeparationConfidence(leadOut, backOut, totalFrames)
        return LeadBackingSeparationResult(
            leadVocals = leadOut,
            backingVocals = backOut,
            method = LeadBackingSeparationMethod.STEREO_HARMONIC_SUBSPACE,
            separationConfidence = conf,
            hasDistinctBackingStem = conf >= 0.18f
        )
    }

    /**
     * Measures whether `backingVocals` contains genuine independent vocal energy rather than
     * broadband silence or an identical copy of `leadVocals`.
     */
    private fun computeBackingSeparationConfidence(
        leadVocals: Array<FloatArray>,
        backingVocals: Array<FloatArray>,
        totalFrames: Int
    ): Float {
        if (totalFrames <= 0) return 0f
        var leadEnergy = 0.0
        var backEnergy = 0.0
        var dotProduct = 0.0
        val step = 4
        var i = 0
        while (i < totalFrames) {
            val l = 0.5 * (leadVocals[0][i] + leadVocals[1][i])
            val b = 0.5 * (backingVocals[0][i] + backingVocals[1][i])
            leadEnergy += l * l
            backEnergy += b * b
            dotProduct += abs(l * b)
            i += step
        }
        if (leadEnergy < 1e-8 || backEnergy < leadEnergy * 0.015) return 0.05f
        val energyRatio = (backEnergy / leadEnergy).coerceIn(0.0, 1.5)
        val corr = (dotProduct / (sqrt(leadEnergy * backEnergy) + 1e-9)).coerceIn(0.0, 1.0)
        val independence = (1.0 - corr).coerceIn(0.0, 1.0)
        return (0.55 * independence + 0.45 * min(1.0, energyRatio * 2.2)).toFloat().coerceIn(0.05f, 0.96f)
    }
}
