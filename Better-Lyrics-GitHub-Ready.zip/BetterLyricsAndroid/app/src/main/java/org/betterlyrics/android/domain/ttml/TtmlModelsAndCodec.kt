package org.betterlyrics.android.domain.ttml

import org.w3c.dom.Document
import org.w3c.dom.Element
import org.w3c.dom.Node
import org.xml.sax.InputSource
import org.xml.sax.SAXException
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.StringReader
import java.security.SecureRandom
import java.util.Locale
import javax.xml.parsers.DocumentBuilderFactory
import javax.xml.XMLConstants
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.roundToLong

// ================================================================================================
// 1. CONSTANTS & NAMESPACES (Mirrors composer-namespace.ts & ttml.ts)
// ================================================================================================

object TtmlConstants {
    const val TTML_NS = "http://www.w3.org/ns/ttml"
    const val TTM_NS = "http://www.w3.org/ns/ttml#metadata"
    const val TTP_NS = "http://www.w3.org/ns/ttml#parameter"
    const val AMLL_NS = "http://www.example.com/ns/amll"
    const val APPLE_LYRIC_NS = "http://music.apple.com/lyric-ttml-internal"
    const val XML_NS = "http://www.w3.org/XML/1998/namespace"
    const val COMPOSER_NS = "https://composer.betterlyrics.org/ttml"
    val LEGACY_COMPOSER_NAMESPACES = listOf("https://composer.boidu.dev/ttml")
    val COMPOSER_NAMESPACES = listOf(COMPOSER_NS) + LEGACY_COMPOSER_NAMESPACES

    const val DEFAULT_SPLIT_CHARACTER = "-"
    const val DEFAULT_MIN_WORD_DURATION = 0.05
    const val DEFAULT_BG_WORD_DURATION = 0.30

    val RESERVED_META_KEYS = setOf(
        "artists",
        "album",
        "isrc",
        "musicName",
        "songwriter",
        "songwriters"
    )
}

// ================================================================================================
// 2. DOMAIN MODELS (Mirrors src/domain/agent, group, word, line, project)
// ================================================================================================

enum class AgentType(val xmlValue: String) {
    PERSON("person"),
    CHARACTER("character"),
    GROUP("group"),
    ORGANIZATION("organization"),
    OTHER("other");

    companion object {
        fun fromXml(raw: String?): AgentType =
            entries.firstOrNull { it.xmlValue.equals(raw?.trim(), ignoreCase = true) } ?: PERSON
    }
}

data class Agent(
    val id: String,
    val type: AgentType = AgentType.PERSON,
    val name: String? = null
) {
    companion object {
        val AGENT_PRESETS = listOf(
            Agent(id = "v1", type = AgentType.PERSON, name = "Lead"),
            Agent(id = "v2", type = AgentType.PERSON, name = "Duet"),
            Agent(id = "v1000", type = AgentType.GROUP, name = "Harmony"),
            Agent(id = "v2000", type = AgentType.OTHER, name = "Chorus")
        )
        val DEFAULT_AGENTS = listOf(AGENT_PRESETS[0])
    }
}

data class LinkGroup(
    val id: String,
    val label: String,
    val color: String = "#9ca3af",
    val templateVersion: Int = 1
)

data class WordTiming(
    val text: String,
    val begin: Double,
    val end: Double,
    val explicit: Boolean = false,
    val syllableGroupId: String? = null,
    val transliteration: String? = null,
    val transliterationJoinerAfter: String? = null,
    val confidence: Float? = null,
    val needsReview: Boolean = false
)

data class Bounds(val begin: Double, val end: Double)

enum class BackgroundSource {
    EXTRACTION,
    MANUAL
}

data class TranslationTrack(
    val language: String,
    val text: String,
    val backgroundText: String? = null,
    val origin: String = "import",
    val sourceFingerprint: String = ""
)

data class TransliterationSegment(
    val original: String,
    val transliteration: String
)

data class TransliterationTrack(
    val language: String,
    val text: String,
    val backgroundText: String? = null,
    val segments: List<TransliterationSegment> = emptyList(),
    val backgroundSegments: List<TransliterationSegment>? = null,
    val alignmentStatus: String = "resolved",
    val backgroundAlignmentStatus: String = "resolved",
    val origin: String = "import",
    val sourceFingerprint: String = ""
)

/**
 * Mirrors LyricLine in src/domain/line/model.ts.
 * Invariant enforced by [reconcileLine]: a line with non-null [words] is word-synced
 * (and drops standalone [begin]/[end]), whereas a line without [words] uses [begin]/[end].
 */
data class LyricLine(
    val id: String = NanoIdGenerator.generateLineId(),
    val text: String,
    val agentId: String = "v1",
    val words: List<WordTiming>? = null,
    val begin: Double? = null,
    val end: Double? = null,
    val backgroundText: String? = null,
    val backgroundWords: List<WordTiming>? = null,
    val backgroundTextSource: BackgroundSource? = null,
    val groupId: String? = null,
    val instanceIdx: Int? = null,
    val templateLineIdx: Int? = null,
    val detached: Boolean? = null,
    val translations: Map<String, TranslationTrack>? = null,
    val transliteration: TransliterationTrack? = null
) {
    val isWordSynced: Boolean
        get() = !words.isNullOrEmpty()

    val isLineSynced: Boolean
        get() = words == null && begin != null && end != null && begin.isFinite() && end.isFinite()

    val isLineTimed: Boolean
        get() = effectiveBounds() != null

    val hasMainLyrics: Boolean
        get() = text.trim().isNotEmpty() || !words.isNullOrEmpty()

    fun mainBounds(): Bounds? {
        if (!words.isNullOrEmpty()) {
            return Bounds(
                begin = words.minOf { it.begin },
                end = words.maxOf { it.end }
            )
        }
        if (begin != null && end != null && begin.isFinite() && end.isFinite()) {
            return Bounds(begin, end)
        }
        return null
    }

    fun bgBounds(): Bounds? {
        if (backgroundWords.isNullOrEmpty()) return null
        return Bounds(
            begin = backgroundWords.minOf { it.begin },
            end = backgroundWords.maxOf { it.end }
        )
    }

    fun effectiveBounds(): Bounds? {
        val main = mainBounds() ?: return bgBounds()
        val bg = bgBounds() ?: return main
        return Bounds(
            begin = min(main.begin, bg.begin),
            end = max(main.end, bg.end)
        )
    }

    fun reconcile(splitChar: String = TtmlConstants.DEFAULT_SPLIT_CHARACTER): LyricLine {
        val cleanedBgText = backgroundText?.takeIf { it.trim().isNotEmpty() }
        val cleanedBgWords = backgroundWords?.takeIf { it.isNotEmpty() }
        val resolvedBgSource = if (cleanedBgText == null && cleanedBgWords == null) null else backgroundTextSource

        val derivedMainText = if (!words.isNullOrEmpty()) {
            WordSpacesAndSyllables.reconstructLineText(words, splitChar)
        } else {
            text
        }
        val derivedBgText = if (cleanedBgWords != null) {
            WordSpacesAndSyllables.reconstructLineText(cleanedBgWords, splitChar)
        } else {
            cleanedBgText
        }

        return if (words != null) {
            copy(
                text = derivedMainText,
                words = words,
                begin = null,
                end = null,
                backgroundText = derivedBgText,
                backgroundWords = cleanedBgWords,
                backgroundTextSource = resolvedBgSource
            )
        } else if (begin != null && end != null) {
            copy(
                text = derivedMainText,
                words = null,
                begin = begin,
                end = end,
                backgroundText = derivedBgText,
                backgroundWords = cleanedBgWords,
                backgroundTextSource = resolvedBgSource
            )
        } else {
            copy(
                text = derivedMainText,
                words = null,
                begin = null,
                end = null,
                backgroundText = derivedBgText,
                backgroundWords = cleanedBgWords,
                backgroundTextSource = resolvedBgSource
            )
        }
    }
}

data class ProjectMetadata(
    val title: String = "",
    val artists: List<String> = emptyList(),
    val album: String = "",
    val duration: Double = 0.0,
    val isrc: String? = null,
    val songwriters: List<String>? = null,
    val extra: Map<String, String>? = null,
    val language: String? = null
)

data class MetaPair(val key: String, val value: String)

object MetadataTtmlMapper {
    fun toComposerMeta(metadata: ProjectMetadata): List<MetaPair> {
        val pairs = mutableListOf<MetaPair>()
        for (artist in metadata.artists) {
            if (artist.isNotBlank()) pairs.add(MetaPair("artists", artist))
        }
        if (metadata.album.isNotBlank()) {
            pairs.add(MetaPair("album", metadata.album))
        }
        if (!metadata.isrc.isNullOrBlank()) {
            pairs.add(MetaPair("isrc", metadata.isrc))
        }
        for (writer in metadata.songwriters.orEmpty()) {
            if (writer.isNotBlank()) pairs.add(MetaPair("songwriter", writer))
        }
        val sortedKeys = metadata.extra?.keys?.sorted().orEmpty()
        for (key in sortedKeys) {
            val value = metadata.extra?.get(key)
            if (!value.isNullOrBlank()) {
                pairs.add(MetaPair(key, value))
            }
        }
        return pairs
    }

    fun fromComposerMeta(pairs: List<MetaPair>): ProjectMetadata {
        var title = ""
        val artists = mutableListOf<String>()
        var album = ""
        var isrc: String? = null
        val songwriters = mutableListOf<String>()
        val extra = linkedMapOf<String, String>()

        for ((key, value) in pairs) {
            if (key.isBlank() || value.isBlank()) continue
            when (key) {
                "artists" -> artists.add(value)
                "album" -> album = value
                "isrc" -> isrc = value
                "musicName" -> if (title.isEmpty()) title = value
                "songwriter", "songwriters" -> songwriters.add(value)
                else -> extra[key] = value
            }
        }
        return ProjectMetadata(
            title = title,
            artists = artists,
            album = album,
            isrc = isrc,
            songwriters = songwriters.takeIf { it.isNotEmpty() },
            extra = extra.takeIf { it.isNotEmpty() }
        )
    }
}

object NanoIdGenerator {
    private const val ALPHABET = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz-"
    private val random = SecureRandom()

    fun nanoid(size: Int = 8): String {
        val sb = StringBuilder(size)
        for (i in 0 until size) {
            sb.append(ALPHABET[random.nextInt(ALPHABET.length)])
        }
        return sb.toString()
    }

    fun generateLineId(): String = "line_${nanoid(10)}"
}

// ================================================================================================
// 3. WORD SPACES & SYLLABLE GROUPING (Mirrors word-spaces.ts, syllable-groups.ts, reconstruct-text.ts)
// ================================================================================================

data class SyllableGroup(
    val startIndex: Int,
    val endIndex: Int,
    val originalWord: String
)

enum class SyllablePosition { NONE, FIRST, MIDDLE, LAST }

data class WordContentSpan(val start: Int, val end: Int)

object WordSpacesAndSyllables {

    fun reconstructLineText(
        words: List<WordTiming>,
        splitChar: String = TtmlConstants.DEFAULT_SPLIT_CHARACTER
    ): String {
        val sb = StringBuilder()
        for (i in words.indices) {
            sb.append(words[i].text)
            if (i < words.size - 1 && !words[i].text.endsWith(" ")) {
                sb.append(splitChar)
            }
        }
        return sb.toString()
    }

    fun wordContentSpans(
        words: List<WordTiming>,
        splitChar: String = TtmlConstants.DEFAULT_SPLIT_CHARACTER
    ): List<WordContentSpan> {
        val spans = ArrayList<WordContentSpan>(words.size)
        var cursor = 0
        for (i in words.indices) {
            val text = words[i].text
            val leading = text.length - text.trimStart().length
            val trailing = text.length - text.trimEnd().length
            spans.add(WordContentSpan(start = cursor + leading, end = cursor + text.length - trailing))
            cursor += text.length
            if (i < words.size - 1 && !text.endsWith(" ")) {
                cursor += splitChar.length
            }
        }
        return spans
    }

    fun trimTrailingSpaceFromLast(words: List<WordTiming>): List<WordTiming> {
        if (words.isEmpty()) return words
        val last = words.last()
        if (!last.text.endsWith(" ")) return words
        val next = words.toMutableList()
        next[next.lastIndex] = last.copy(text = last.text.trimEnd())
        return next
    }

    fun resolveOverlapsForward(words: List<WordTiming>, duration: Double): List<WordTiming> {
        if (words.isEmpty()) return words
        val minDur = TtmlConstants.DEFAULT_MIN_WORD_DURATION
        val result = words.toMutableList()
        for (i in 1 until result.size) {
            val prev = result[i - 1]
            val cur = result[i]
            if (cur.begin < prev.end) {
                // First trim previous word's end back to `cur.begin` so `cur.begin` stays locked on its vocal attack
                if (cur.begin >= prev.begin + minDur) {
                    result[i - 1] = prev.copy(end = cur.begin)
                } else {
                    val clampedPrevEnd = prev.begin + minDur
                    result[i - 1] = prev.copy(end = clampedPrevEnd)
                    result[i] = cur.copy(
                        begin = clampedPrevEnd,
                        end = max(cur.end, clampedPrevEnd + minDur)
                    )
                }
            }
        }
        val last = result.last()
        if (duration > 0.0 && last.end > duration) {
            val clampedBegin = min(last.begin, max(0.0, duration - minDur))
            result[result.lastIndex] = last.copy(
                begin = clampedBegin,
                end = max(clampedBegin + minDur, duration)
            )
        }
        return result
    }

    private fun joinSyllableText(words: List<WordTiming>, start: Int, end: Int): String =
        words.subList(start, end + 1).joinToString("") { it.text.trim() }

    fun computeByGroupId(words: List<WordTiming>): List<SyllableGroup> {
        val groups = mutableListOf<SyllableGroup>()
        var i = 0
        while (i < words.size) {
            val id = words[i].syllableGroupId
            if (id == null) {
                i++
                continue
            }
            var end = i
            while (end + 1 < words.size && words[end + 1].syllableGroupId == id) {
                end++
            }
            if (end > i) {
                groups.add(SyllableGroup(i, end, joinSyllableText(words, i, end)))
            }
            i = end + 1
        }
        return groups
    }

    fun computeByTrailingSpace(words: List<WordTiming>): List<SyllableGroup> {
        val groups = mutableListOf<SyllableGroup>()
        var groupStart = 0
        for (i in words.indices) {
            val hasTrailingSpace = words[i].text.endsWith(" ")
            val isLast = i == words.lastIndex
            if (hasTrailingSpace || isLast) {
                if (i > groupStart) {
                    groups.add(SyllableGroup(groupStart, i, joinSyllableText(words, groupStart, i)))
                }
                groupStart = i + 1
            }
        }
        return groups
    }

    fun computeSyllableGroups(words: List<WordTiming>): List<SyllableGroup> =
        if (words.any { it.syllableGroupId != null }) computeByGroupId(words)
        else computeByTrailingSpace(words)

    fun inferSyllableGroupIds(words: List<WordTiming>): List<WordTiming> {
        if (words.isEmpty()) return words
        if (words.any { it.syllableGroupId != null }) return words
        val groups = computeByTrailingSpace(words)
        if (groups.isEmpty()) return words
        val result = words.toMutableList()
        for (group in groups) {
            val groupId = NanoIdGenerator.nanoid(8)
            for (i in group.startIndex..group.endIndex) {
                result[i] = result[i].copy(syllableGroupId = groupId)
            }
        }
        return result
    }

    fun closeIntraGroupGaps(words: List<WordTiming>): List<WordTiming> {
        if (words.size < 2) return words
        var changed = false
        val result = words.toMutableList()
        for (i in 0 until result.size - 1) {
            val id = result[i].syllableGroupId ?: continue
            if (result[i + 1].syllableGroupId != id) continue
            if (result[i].end < result[i + 1].begin) {
                result[i] = result[i].copy(end = result[i + 1].begin)
                changed = true
            }
        }
        return if (changed) result else words
    }

    /**
     * Mirrors splitWordIntoSyllables in src/utils/single-word-syllable-split.ts
     */
    fun splitWordIntoSyllables(
        word: WordTiming,
        splitPoints: List<Int>,
        reuseGroupId: Boolean = false
    ): List<WordTiming> {
        val groupId = if (reuseGroupId && word.syllableGroupId != null) {
            word.syllableGroupId
        } else {
            NanoIdGenerator.nanoid(8)
        }
        val trimmed = word.text.trimEnd()
        if (trimmed.isEmpty()) return listOf(word)

        val parts = mutableListOf<String>()
        var lastIdx = 0
        for (pt in splitPoints.sorted()) {
            if (pt > lastIdx && pt < trimmed.length) {
                parts.add(trimmed.substring(lastIdx, pt))
                lastIdx = pt
            }
        }
        parts.add(trimmed.substring(lastIdx))
        if (parts.size <= 1) return listOf(word)

        val duration = word.end - word.begin
        val charDuration = duration / trimmed.length.toDouble()
        var currentBegin = word.begin

        val newWords = parts.mapIndexed { idx, part ->
            val partEnd = if (idx == parts.lastIndex) word.end else currentBegin + part.length * charDuration
            val w = WordTiming(
                text = part,
                begin = currentBegin,
                end = partEnd,
                explicit = word.explicit,
                syllableGroupId = groupId
            )
            currentBegin = partEnd
            w
        }.toMutableList()

        if (word.text.endsWith(" ") && newWords.isNotEmpty()) {
            val last = newWords.last()
            newWords[newWords.lastIndex] = last.copy(text = "${last.text} ")
        }
        return newWords
    }
}

// ================================================================================================
// 4. BACKGROUND VOCAL EXTRACTION (Mirrors src/utils/background-vocal-extraction.ts & brackets.ts)
// ================================================================================================

object BackgroundVocalExtractor {

    data class ParenGroup(val inner: String, val start: Int, val end: Int)
    enum class ParenScanStatus { BALANCED, UNBALANCED, NESTED }
    data class ParenScan(val status: ParenScanStatus, val groups: List<ParenGroup>)
    enum class LineClassKind { NONE, INLINE, STANDALONE, SKIP }
    data class LineClassification(
        val kind: LineClassKind,
        val groups: List<ParenGroup>,
        val bgText: String,
        val mainText: String
    )
    data class ExtractOptions(
        val mergeStandaloneLines: Boolean = true,
        val preserveBrackets: Boolean = true
    )

    fun scanParenGroups(text: String): ParenScan {
        val groups = mutableListOf<ParenGroup>()
        var depth = 0
        var openIndex = -1
        for (i in text.indices) {
            when (text[i]) {
                '(' -> {
                    depth++
                    if (depth > 1) return ParenScan(ParenScanStatus.NESTED, emptyList())
                    openIndex = i
                }
                ')' -> {
                    depth--
                    if (depth < 0) return ParenScan(ParenScanStatus.UNBALANCED, emptyList())
                    groups.add(ParenGroup(text.substring(openIndex + 1, i), openIndex, i))
                }
            }
        }
        if (depth != 0) return ParenScan(ParenScanStatus.UNBALANCED, emptyList())
        return ParenScan(ParenScanStatus.BALANCED, groups)
    }

    private fun stripGroups(text: String, groups: List<ParenGroup>): String {
        var result = text
        for (i in groups.indices.reversed()) {
            result = result.substring(0, groups[i].start) + result.substring(groups[i].end + 1)
        }
        return result
    }

    private fun collapseSpaces(text: String): String =
        text.replace(Regex(" {2,}"), " ").trim()

    fun classifyLine(text: String): LineClassification {
        val scan = scanParenGroups(text)
        if (scan.status != ParenScanStatus.BALANCED) {
            return LineClassification(LineClassKind.SKIP, emptyList(), "", text)
        }
        if (scan.groups.isEmpty()) {
            return LineClassification(LineClassKind.NONE, emptyList(), "", text)
        }
        val bgText = scan.groups.map { it.inner.trim() }.filter { it.isNotEmpty() }.joinToString(" ")
        if (bgText.isEmpty()) {
            return LineClassification(LineClassKind.NONE, scan.groups, "", text)
        }
        val mainText = collapseSpaces(stripGroups(text, scan.groups))
        val kind = if (mainText.isEmpty()) LineClassKind.STANDALONE else LineClassKind.INLINE
        return LineClassification(kind, scan.groups, bgText, mainText)
    }

    fun bracketWordList(words: List<WordTiming>): List<WordTiming> {
        if (words.isEmpty()) return words
        if (words.size == 1) {
            val only = words[0]
            val core = only.text.trimEnd()
            val trail = only.text.substring(core.length)
            return listOf(only.copy(text = "($core)$trail"))
        }
        val out = words.toMutableList()
        val first = out.first()
        val last = out.last()
        val lastCore = last.text.trimEnd()
        val lastTrail = last.text.substring(lastCore.length)
        out[0] = first.copy(text = "(${first.text}")
        out[out.lastIndex] = last.copy(text = "$lastCore)$lastTrail")
        return out
    }

    private fun joinBackgroundText(
        existing: String?,
        addition: String,
        preserveBrackets: Boolean,
        trailingBracketFromSamePass: Boolean
    ): String {
        val base = existing?.trim().orEmpty()
        if (!preserveBrackets) return if (base.isNotEmpty()) "$base $addition" else addition
        if (base.isEmpty()) return "($addition)"
        if (trailingBracketFromSamePass && base.endsWith(")")) {
            return "${base.dropLast(1)} $addition)"
        }
        return "$base ($addition)"
    }

    fun createInitialBgWords(backgroundText: String, begin: Double, end: Double?): List<WordTiming> {
        val tokens = backgroundText.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (tokens.isEmpty()) return emptyList()
        val resolvedEnd = end ?: (begin + tokens.size * TtmlConstants.DEFAULT_BG_WORD_DURATION)
        val totalChars = tokens.sumOf { it.length }.coerceAtLeast(1)
        val duration = (resolvedEnd - begin).coerceAtLeast(tokens.size * TtmlConstants.DEFAULT_MIN_WORD_DURATION)

        var currentTime = begin
        return tokens.mapIndexed { idx, word ->
            val wordDuration = (word.length.toDouble() / totalChars.toDouble()) * duration
            val isLast = idx == tokens.lastIndex
            val w = WordTiming(
                text = if (isLast) word else "$word ",
                begin = currentTime,
                end = if (isLast) resolvedEnd else currentTime + wordDuration
            )
            currentTime += wordDuration
            w
        }
    }

    fun extractInlineFromLine(line: LyricLine, options: ExtractOptions = ExtractOptions()): LyricLine {
        val classified = classifyLine(line.text)
        if (classified.kind != LineClassKind.INLINE) return line
        if (!line.backgroundWords.isNullOrEmpty()) return line

        if (line.isWordSynced && !line.words.isNullOrEmpty()) {
            val words = line.words
            val splitChar = TtmlConstants.DEFAULT_SPLIT_CHARACTER
            if (WordSpacesAndSyllables.reconstructLineText(words, splitChar) != line.text) return line
            val spans = WordSpacesAndSyllables.wordContentSpans(words, splitChar)
            val survivors = mutableListOf<WordTiming>()
            val extractedBgWords = mutableListOf<WordTiming>()

            for (i in words.indices) {
                val span = spans[i]
                var insideCount = 0
                for (g in classified.groups) {
                    val groupStart = g.start
                    val groupEnd = g.end + 1
                    val overlaps = span.start < groupEnd && span.end > groupStart
                    if (!overlaps) continue
                    val fullyInside = span.start >= groupStart && span.end <= groupEnd
                    if (!fullyInside) return line
                    insideCount++
                }
                if (insideCount == 0) {
                    survivors.add(words[i])
                } else {
                    val cleaned = words[i].text.trim().removePrefix("(").removeSuffix(")")
                    if (cleaned.isNotEmpty()) {
                        extractedBgWords.add(words[i].copy(text = "$cleaned "))
                    }
                }
            }
            if (survivors.isEmpty()) return line
            val trimmedSurvivors = WordSpacesAndSyllables.trimTrailingSpaceFromLast(survivors)
            val trimmedBgWords = WordSpacesAndSyllables.trimTrailingSpaceFromLast(extractedBgWords)
                .let { if (options.preserveBrackets) bracketWordList(it) else it }
            val base = if (line.backgroundTextSource == BackgroundSource.EXTRACTION) null else line.backgroundText
            val joinedBgText = joinBackgroundText(base, classified.bgText, options.preserveBrackets, false)

            return line.copy(
                words = trimmedSurvivors,
                text = WordSpacesAndSyllables.reconstructLineText(trimmedSurvivors, splitChar),
                backgroundText = joinedBgText,
                backgroundWords = trimmedBgWords.takeIf { it.isNotEmpty() },
                backgroundTextSource = if (base != null) BackgroundSource.MANUAL else BackgroundSource.EXTRACTION
            ).reconcile(splitChar)
        }

        val base = if (line.backgroundTextSource == BackgroundSource.EXTRACTION) null else line.backgroundText
        val joinedBgText = joinBackgroundText(base, classified.bgText, options.preserveBrackets, false)
        val seededBgWords = if (line.begin != null && line.end != null) {
            val mid = (line.begin + line.end) / 2.0
            val rawBg = createInitialBgWords(classified.bgText, mid, line.end)
            if (options.preserveBrackets) bracketWordList(rawBg) else rawBg
        } else null

        return line.copy(
            text = classified.mainText,
            backgroundText = joinedBgText,
            backgroundWords = seededBgWords,
            backgroundTextSource = if (base != null) BackgroundSource.MANUAL else BackgroundSource.EXTRACTION
        ).reconcile()
    }

    fun extractBackgroundVocals(
        lines: List<LyricLine>,
        options: ExtractOptions = ExtractOptions()
    ): List<LyricLine> {
        val result = mutableListOf<LyricLine>()
        val sameSessionWriteIndices = mutableSetOf<Int>()

        for (line in lines) {
            val classified = classifyLine(line.text)
            if (classified.kind == LineClassKind.INLINE) {
                val extracted = extractInlineFromLine(line, options)
                result.add(extracted)
                if (extracted != line) sameSessionWriteIndices.add(result.lastIndex)
                continue
            }
            if (classified.kind == LineClassKind.STANDALONE && options.mergeStandaloneLines) {
                val prevIndex = result.lastIndex
                val prev = result.lastOrNull()
                if (prev != null &&
                    prev.text.trim().isNotEmpty() &&
                    classifyLine(prev.text).kind == LineClassKind.NONE &&
                    prev.groupId == null &&
                    line.groupId == null
                ) {
                    val carried = when {
                        !line.words.isNullOrEmpty() -> {
                            val stripped = line.words.mapIndexed { idx, w ->
                                val core = w.text.trim().removePrefix("(").removeSuffix(")")
                                w.copy(text = if (idx < line.words.lastIndex) "$core " else core)
                            }
                            if (options.preserveBrackets) bracketWordList(stripped) else stripped
                        }
                        line.begin != null && line.end != null -> {
                            val raw = createInitialBgWords(classified.bgText, line.begin, line.end)
                            if (options.preserveBrackets) bracketWordList(raw) else raw
                        }
                        else -> null
                    }
                    val joinedText = joinBackgroundText(
                        prev.backgroundText,
                        classified.bgText,
                        options.preserveBrackets,
                        sameSessionWriteIndices.contains(prevIndex)
                    )
                    val combinedWords = when {
                        !prev.backgroundWords.isNullOrEmpty() && !carried.isNullOrEmpty() ->
                            prev.backgroundWords + carried
                        !carried.isNullOrEmpty() -> carried
                        else -> prev.backgroundWords
                    }
                    result[prevIndex] = prev.copy(
                        backgroundText = if (!combinedWords.isNullOrEmpty()) {
                            WordSpacesAndSyllables.reconstructLineText(combinedWords)
                        } else joinedText,
                        backgroundWords = combinedWords,
                        backgroundTextSource = BackgroundSource.EXTRACTION
                    ).reconcile()
                    sameSessionWriteIndices.add(prevIndex)
                    continue
                }
            }
            result.add(line)
        }
        return result
    }
}

// ================================================================================================
// 5. TTML FORMATTER & TIMESTAMP PARSER (Mirrors format-time.ts, ttml-markup.ts, ttml-helpers.ts)
// ================================================================================================

object TtmlFormatting {
    private const val MS_PER_SECOND = 1000L
    private const val MS_PER_MINUTE = 60L * MS_PER_SECOND
    private val OFFSET_TIME = Regex("^([+-]?(?:\\d+(?:\\.\\d*)?|\\.\\d+))(ms|h|m|s|f|t)$", RegexOption.IGNORE_CASE)
    private val CLOCK_TIME = Regex("^(?:(\\d+):)?(\\d{1,2}):(\\d{1,2})(?:\\.(\\d+))?(?::(\\d+)(?:\\.(\\d+))?)?$")

    /**
     * Strict TTML time expression parser used by semantic validation. Supports clock-time,
     * frame-clock and offset-time forms without changing the permissive legacy parser below.
     */
    fun parseTimeExpression(
        expression: String,
        frameRate: Double = 30.0,
        tickRate: Double = frameRate
    ): Double? {
        val raw = expression.trim()
        if (raw.isEmpty()) return null
        val clock = CLOCK_TIME.matchEntire(raw)
        if (clock != null) {
            val (hoursRaw, minutesRaw, secondsRaw, fractionRaw, framesRaw, subframesRaw) = clock.destructured
            val hours = hoursRaw.ifEmpty { "0" }.toLongOrNull() ?: return null
            val minutes = minutesRaw.toLongOrNull() ?: return null
            val seconds = secondsRaw.toLongOrNull() ?: return null
            if (minutes > 59 || seconds > 59) return null
            val fraction = if (fractionRaw.isEmpty()) 0.0 else {
                ("0.$fractionRaw").toDoubleOrNull() ?: return null
            }
            val frames = framesRaw.toLongOrNull()
            val subframes = subframesRaw.toLongOrNull()
            if (frames != null && (frameRate <= 0.0 || frames >= frameRate)) return null
            val framePart = if (frames != null) {
                (frames + (subframes ?: 0L) / 100.0) / frameRate
            } else 0.0
            val total = hours * 3600.0 + minutes * 60.0 + seconds + fraction + framePart
            return total.takeIf { it.isFinite() }
        }

        val offset = OFFSET_TIME.matchEntire(raw) ?: return null
        val value = offset.groupValues[1].toDoubleOrNull()?.takeIf { it.isFinite() } ?: return null
        val unit = offset.groupValues[2].lowercase(Locale.ROOT)
        val seconds = when (unit) {
            "h" -> value * 3600.0
            "m" -> value * 60.0
            "s" -> value
            "ms" -> value / 1000.0
            "f" -> if (frameRate > 0.0) value / frameRate else return null
            "t" -> if (tickRate > 0.0) value / tickRate else return null
            else -> return null
        }
        return seconds.takeIf { it.isFinite() }
    }

    /**
     * Exact port of src/utils/format-time.ts:
     * Formats seconds as M:SS.mmm (e.g. 0:04.120, 12:34.567)
     */
    fun formatTime(seconds: Double, precision: Int = 3): String {
        if (!seconds.isFinite() || seconds < 0.0) {
            return if (precision == 0) "0:00" else "0:00.${"0".repeat(precision)}"
        }
        val totalMs = (seconds * MS_PER_SECOND.toDouble()).roundToLong()
        val mins = totalMs / MS_PER_MINUTE
        val secs = (totalMs % MS_PER_MINUTE) / MS_PER_SECOND
        val base = "$mins:${secs.toString().padStart(2, '0')}"
        if (precision == 0) return base
        val divisor = 10.0.pow(3 - precision).roundToLong().coerceAtLeast(1L)
        val fraction = (totalMs % MS_PER_SECOND) / divisor
        return "$base.${fraction.toString().padStart(precision, '0')}"
    }

    /**
     * Exact port of parseTtmlTimestamp in src/utils/lyrics-parsers/ttml-helpers.ts
     */
    fun parseTtmlTimestamp(timestamp: String): Double {
        val trimmed = timestamp.trim()
        if (trimmed.isEmpty()) return 0.0

        val parts = trimmed.split(":")
        return when (parts.size) {
            3 -> {
                val hours = parts[0].toIntOrNull() ?: 0
                val minutes = parts[1].toIntOrNull() ?: 0
                val secParts = parts[2].split(".")
                val seconds = secParts[0].toIntOrNull() ?: 0
                val millis = if (secParts.size > 1) {
                    secParts[1].padEnd(3, '0').take(3).toIntOrNull() ?: 0
                } else 0
                hours * 3600.0 + minutes * 60.0 + seconds + millis / 1000.0
            }
            2 -> {
                val minutes = parts[0].toIntOrNull() ?: 0
                val secParts = parts[1].split(".")
                val seconds = secParts[0].toIntOrNull() ?: 0
                val millis = if (secParts.size > 1) {
                    secParts[1].padEnd(3, '0').take(3).toIntOrNull() ?: 0
                } else 0
                minutes * 60.0 + seconds + millis / 1000.0
            }
            else -> {
                val secParts = trimmed.split(".")
                val seconds = secParts[0].toIntOrNull() ?: 0
                val millis = if (secParts.size > 1) {
                    secParts[1].padEnd(3, '0').take(3).toIntOrNull() ?: 0
                } else 0
                seconds + millis / 1000.0
            }
        }
    }

    fun escapeXml(str: String): String =
        str.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")

    fun escapeXmlAttribute(str: String): String =
        escapeXml(str).replace("\"", "&quot;")

    fun emitWordSpan(word: WordTiming, text: String): String {
        val explicitAttr = if (word.explicit) " composer:explicit=\"true\"" else ""
        return "<span begin=\"${formatTime(word.begin)}\" end=\"${formatTime(word.end)}\"$explicitAttr>${escapeXml(text)}</span>"
    }

    fun normalizeLanguageTag(input: String?): String? {
        val trimmed = input?.trim().orEmpty()
        if (trimmed.isEmpty()) return null
        val locale = Locale.forLanguageTag(trimmed)
        val tag = locale.toLanguageTag()
        return if (tag.isBlank() || tag == "und") null else tag
    }
}

// ================================================================================================
// 6. TTML SERIALIZER (100% Bit-Exact Parity with src/utils/ttml.ts)
// ================================================================================================

data class TTMLOptions(
    val metadata: ProjectMetadata,
    val agents: List<Agent> = Agent.DEFAULT_AGENTS,
    val lines: List<LyricLine>,
    val groups: List<LinkGroup>? = null,
    val minify: Boolean = false,
    val duration: Double? = null,
    val includeAmllNamespace: Boolean = true
)

object TtmlSerializer {

    fun generateTTML(options: TTMLOptions): String {
        val nl = if (options.minify) "" else "\n"
        fun ind(n: Int): String = if (options.minify) "" else "  ".repeat(n)

        val timingValue = if (options.lines.any { it.isWordSynced }) "Word" else "Line"
        val keyedLines = options.lines
            .filter { it.isLineTimed }
            .mapIndexed { idx, line -> line to "L${idx + 1}" }
        val keyById = keyedLines.associate { (line, key) -> line.id to key }

        val language = TtmlFormatting.normalizeLanguageTag(options.metadata.language)
        val langAttr = if (language != null) " xml:lang=\"${TtmlFormatting.escapeXmlAttribute(language)}\"" else ""
        val amllAttr = if (options.includeAmllNamespace) " xmlns:amll=\"${TtmlConstants.AMLL_NS}\"" else ""

        val parts = mutableListOf<String>()

        parts.add(
            "<tt xmlns=\"${TtmlConstants.TTML_NS}\" " +
                "xmlns:ttm=\"${TtmlConstants.TTM_NS}\" " +
                "xmlns:ttp=\"${TtmlConstants.TTP_NS}\"" +
                "$amllAttr " +
                "xmlns:itunes=\"${TtmlConstants.APPLE_LYRIC_NS}\" " +
                "xmlns:composer=\"${TtmlConstants.COMPOSER_NS}\" " +
                "ttp:timeBase=\"media\"$langAttr " +
                "itunes:timing=\"$timingValue\" " +
                "composer:timing=\"$timingValue\">"
        )

        // <head><metadata>
        parts.add("${ind(1)}<head>")
        parts.add("${ind(2)}<metadata>")

        if (options.metadata.title.isNotBlank()) {
            parts.add("${ind(3)}<ttm:title>${TtmlFormatting.escapeXml(options.metadata.title)}</ttm:title>")
        }

        for ((key, value) in MetadataTtmlMapper.toComposerMeta(options.metadata)) {
            parts.add(
                "${ind(3)}<composer:meta key=\"${TtmlFormatting.escapeXmlAttribute(key)}\" " +
                    "value=\"${TtmlFormatting.escapeXmlAttribute(value)}\"/>"
            )
        }

        for (agent in options.agents) {
            if (!agent.name.isNullOrBlank()) {
                parts.add(
                    "${ind(3)}<ttm:agent xml:id=\"${TtmlFormatting.escapeXmlAttribute(agent.id)}\" type=\"${agent.type.xmlValue}\">"
                )
                parts.add("${ind(4)}<ttm:name>${TtmlFormatting.escapeXml(agent.name)}</ttm:name>")
                parts.add("${ind(3)}</ttm:agent>")
            } else {
                parts.add(
                    "${ind(3)}<ttm:agent xml:id=\"${TtmlFormatting.escapeXmlAttribute(agent.id)}\" type=\"${agent.type.xmlValue}\"/>"
                )
            }
        }

        if (!options.groups.isNullOrEmpty()) {
            parts.add("${ind(3)}<composer:groups>")
            for (g in options.groups) {
                parts.add(
                    "${ind(4)}<composer:group id=\"${TtmlFormatting.escapeXmlAttribute(g.id)}\" " +
                        "label=\"${TtmlFormatting.escapeXmlAttribute(g.label)}\" " +
                        "color=\"${TtmlFormatting.escapeXmlAttribute(g.color)}\" " +
                        "templateVersion=\"${g.templateVersion}\"/>"
                )
            }
            parts.add("${ind(3)}</composer:groups>")
        }

        // Translations & Transliterations inside <iTunesMetadata>
        val translationLanguages = linkedSetOf<String>()
        for ((line, _) in keyedLines) {
            for ((lang, track) in line.translations.orEmpty()) {
                if (track.text.isNotBlank() || !track.backgroundText.isNullOrBlank()) {
                    translationLanguages.add(lang)
                }
            }
        }
        val transliterationLines = keyedLines.filter { (line, _) ->
            val tr = line.transliteration
            tr != null && (tr.text.isNotBlank() || !tr.backgroundText.isNullOrBlank())
        }

        if (translationLanguages.isNotEmpty() || transliterationLines.isNotEmpty()) {
            parts.add("${ind(3)}<iTunesMetadata xmlns=\"${TtmlConstants.APPLE_LYRIC_NS}\">")
            if (translationLanguages.isNotEmpty()) {
                parts.add("${ind(4)}<translations>")
                for (lang in translationLanguages) {
                    parts.add("${ind(5)}<translation xml:lang=\"${TtmlFormatting.escapeXml(lang)}\" type=\"subtitle\">")
                    for ((line, key) in keyedLines) {
                        val track = line.translations?.get(lang)
                        if (track != null && (track.text.isNotBlank() || !track.backgroundText.isNullOrBlank())) {
                            val rendered = if (!track.backgroundText.isNullOrBlank()) {
                                "${TtmlFormatting.escapeXml(track.text)} <span ttm:role=\"x-bg\">${TtmlFormatting.escapeXml(track.backgroundText.trim())}</span>"
                            } else {
                                TtmlFormatting.escapeXml(track.text)
                            }
                            parts.add("${ind(6)}<text for=\"$key\">$rendered</text>")
                        }
                    }
                    parts.add("${ind(5)}</translation>")
                }
                parts.add("${ind(4)}</translations>")
            }
            if (transliterationLines.isNotEmpty()) {
                val byLang = transliterationLines.groupBy { it.first.transliteration!!.language }
                parts.add("${ind(4)}<transliterations>")
                for ((lang, langLines) in byLang) {
                    parts.add("${ind(5)}<transliteration xml:lang=\"${TtmlFormatting.escapeXml(lang)}\">")
                    for ((line, key) in langLines) {
                        val tr = line.transliteration!!
                        val mainBody = TtmlFormatting.escapeXml(tr.text)
                        val fullBody = if (!tr.backgroundText.isNullOrBlank()) {
                            "$mainBody <span ttm:role=\"x-bg\">${TtmlFormatting.escapeXml(tr.backgroundText.trim())}</span>"
                        } else mainBody
                        parts.add("${ind(6)}<text for=\"$key\">$fullBody</text>")
                    }
                    parts.add("${ind(5)}</transliteration>")
                }
                parts.add("${ind(4)}</transliterations>")
            }
            parts.add("${ind(3)}</iTunesMetadata>")
        }

        parts.add("${ind(2)}</metadata>")
        parts.add("${ind(1)}</head>")

        // <body><div>
        val resolvedDuration = options.duration ?: options.metadata.duration.takeIf { it > 0.0 }
        val durAttr = if (resolvedDuration != null && resolvedDuration > 0.0) {
            " dur=\"${TtmlFormatting.formatTime(resolvedDuration)}\""
        } else ""
        parts.add("${ind(1)}<body$durAttr>")
        parts.add("${ind(2)}<div>")

        for (line in options.lines) {
            val timing = line.effectiveBounds() ?: continue
            if (!line.hasMainLyrics && line.backgroundText.isNullOrBlank()) continue

            val agentAttr = if (line.agentId.isNotBlank()) {
                " ttm:agent=\"${TtmlFormatting.escapeXmlAttribute(line.agentId)}\""
            } else ""
            val lineKey = keyById[line.id]
            val keyAttr = if (lineKey != null) " itunes:key=\"$lineKey\"" else ""
            val groupAttr = if (!line.groupId.isNullOrBlank()) {
                val detachedAttr = if (line.detached == true) " composer:detached=\"true\"" else ""
                " composer:groupId=\"${TtmlFormatting.escapeXmlAttribute(line.groupId)}\" " +
                    "composer:instanceIdx=\"${line.instanceIdx ?: 0}\" " +
                    "composer:templateLineIdx=\"${line.templateLineIdx ?: 0}\"$detachedAttr"
            } else ""

            val contentBuilder = StringBuilder()

            if (line.isWordSynced && !line.words.isNullOrEmpty()) {
                val words = line.words
                for (i in words.indices) {
                    val word = words[i]
                    val text = word.text.trimEnd()
                    val needsSpace = i < words.size - 1 && word.text.endsWith(" ")
                    contentBuilder.append(TtmlFormatting.emitWordSpan(word, text))
                    if (needsSpace) contentBuilder.append(" ")
                }
            } else {
                val cleanLineText = line.text.replace(TtmlConstants.DEFAULT_SPLIT_CHARACTER, "")
                contentBuilder.append(TtmlFormatting.escapeXml(cleanLineText))
            }

            if (!line.backgroundText.isNullOrBlank() && !line.backgroundWords.isNullOrEmpty()) {
                val bgWords = line.backgroundWords
                val bgBuilder = StringBuilder()
                for (i in bgWords.indices) {
                    val bgWord = bgWords[i]
                    val text = bgWord.text.trimEnd()
                    val needsSpace = i < bgWords.size - 1 && bgWord.text.endsWith(" ")
                    bgBuilder.append(TtmlFormatting.emitWordSpan(bgWord, text))
                    if (needsSpace) bgBuilder.append(" ")
                }
                contentBuilder.append("<span ttm:role=\"x-bg\">$bgBuilder</span>")
            } else if (!line.backgroundText.isNullOrBlank()) {
                contentBuilder.append(
                    "<span ttm:role=\"x-bg\"><span begin=\"${TtmlFormatting.formatTime(timing.begin)}\" " +
                        "end=\"${TtmlFormatting.formatTime(timing.end)}\">${TtmlFormatting.escapeXml(line.backgroundText)}</span></span>"
                )
            }

            parts.add(
                "${ind(3)}<p begin=\"${TtmlFormatting.formatTime(timing.begin)}\" " +
                    "end=\"${TtmlFormatting.formatTime(timing.end)}\"$keyAttr$agentAttr$groupAttr>$contentBuilder</p>"
            )
        }

        parts.add("${ind(2)}</div>")
        parts.add("${ind(1)}</body>")
        parts.add("</tt>")

        return parts.joinToString(nl)
    }
}

// ================================================================================================
// 7. TTML VALIDATOR & PARSER (Mirrors validate-ttml.ts, ttml.ts, ttml-helpers.ts)
// ================================================================================================

sealed class TtmlValidation {
    data object Ok : TtmlValidation()
    data class Error(val message: String) : TtmlValidation()
    data class Warnings(val issues: List<TtmlValidationIssue>) : TtmlValidation()
}

enum class TtmlIssueSeverity { WARNING, TIMING, UNSUPPORTED }

data class TtmlValidationIssue(
    val severity: TtmlIssueSeverity,
    val location: String,
    val message: String
)

data class ParseIssue(
    val line: Int,
    val text: String,
    val reason: String
)

data class ParseResult(
    val lines: List<LyricLine>,
    val metadata: ProjectMetadata,
    val hasTimingData: Boolean,
    val agents: List<Agent>? = null,
    val groups: List<LinkGroup>? = null,
    val issues: List<ParseIssue> = emptyList()
)

object TtmlValidatorAndParser {

    private val ELEMENT_PREFIX_REGEX = Regex("</?([A-Za-z][\\w.-]*):")
    private val ATTRIBUTE_PREFIX_REGEX = Regex("\\s([A-Za-z][\\w.-]*):[\\w.-]+\\s*=")
    private val DECLARED_PREFIX_REGEX = Regex("xmlns:([A-Za-z][\\w.-]*)\\s*=")
    private val ROOT_TT_TAG_REGEX = Regex("<tt\\b[^>]*>")

    /**
     * Exact port of declareMissingNamespaces in src/utils/lyrics-parsers/ttml-helpers.ts
     */
    fun declareMissingNamespaces(content: String): String {
        val rootMatch = ROOT_TT_TAG_REGEX.find(content) ?: return content
        val rootTag = rootMatch.value

        val declared = mutableSetOf("xml", "xmlns")
        for (m in DECLARED_PREFIX_REGEX.findAll(rootTag)) {
            declared.add(m.groupValues[1])
        }

        val used = linkedSetOf<String>()
        for (m in ELEMENT_PREFIX_REGEX.findAll(content)) {
            used.add(m.groupValues[1])
        }
        for (m in ATTRIBUTE_PREFIX_REGEX.findAll(content)) {
            used.add(m.groupValues[1])
        }

        val missing = used.filterNot { declared.contains(it) }
        if (missing.isEmpty()) return content

        val additions = missing.joinToString("") { prefix ->
            " xmlns:$prefix=\"urn:composer:unbound:$prefix\""
        }
        val patchedRootTag = rootTag.replace(Regex(">$"), "$additions>")
        return content.replaceFirst(rootTag, patchedRootTag)
    }

    fun parseXmlDocument(xml: String): Result<Document> = runCatching {
        if (isAndroidXmlRuntime()) {
            parseAndroidXmlWithPullParser(xml)
        } else {
            parseXmlWithHardenedJaxp(xml)
        }
    }

    private fun isAndroidXmlRuntime(): Boolean {
        val vmName = System.getProperty("java.vm.name").orEmpty()
        val runtimeName = System.getProperty("java.runtime.name").orEmpty()
        return vmName.contains("Dalvik", ignoreCase = true) ||
            vmName.contains("ART", ignoreCase = true) ||
            runtimeName.contains("Android", ignoreCase = true)
    }

    /**
     * Android's platform DocumentBuilderFactory does not consistently implement JAXP's secure
     * processing and ACCESS_EXTERNAL_* controls. Use the pull-parser's supported document-
     * declaration switch there, then construct the DOM ourselves. With declaration processing
     * disabled the parser cannot load external DTDs/entities; nextToken lets us reject any
     * encountered DOCTYPE. Pull parsing does not perform XInclude or schema validation.
     */
    private fun parseAndroidXmlWithPullParser(xml: String): Document {
        val pullFactory = XmlPullParserFactory.newInstance().apply {
            isNamespaceAware = true
            setFeature(XmlPullParser.FEATURE_PROCESS_DOCDECL, false)
            require(!getFeature(XmlPullParser.FEATURE_PROCESS_DOCDECL)) {
                "XML parser did not disable document declaration processing"
            }
        }
        val parser = pullFactory.newPullParser().apply {
            setFeature(XmlPullParser.FEATURE_PROCESS_DOCDECL, false)
            require(!getFeature(XmlPullParser.FEATURE_PROCESS_DOCDECL)) {
                "XML parser did not disable document declaration processing"
            }
            setInput(StringReader(xml))
        }

        // This factory is used only to allocate an empty DOM, never to parse untrusted input.
        val document = DocumentBuilderFactory.newInstance()
            .apply { isNamespaceAware = true }
            .newDocumentBuilder()
            .newDocument()
        val elements = ArrayDeque<Element>()

        while (true) {
            when (parser.nextToken()) {
                XmlPullParser.START_TAG -> {
                    val prefix = parser.prefix.orEmpty()
                    val qualifiedName = if (prefix.isEmpty()) parser.name else "$prefix:${parser.name}"
                    val namespace = parser.namespace?.takeIf { it.isNotEmpty() }
                    val element = document.createElementNS(namespace, qualifiedName)
                    for (index in 0 until parser.attributeCount) {
                        val attrPrefix = parser.getAttributePrefix(index).orEmpty()
                        val attrName = parser.getAttributeName(index)
                        val attrQualifiedName = if (attrPrefix.isEmpty()) attrName else "$attrPrefix:$attrName"
                        val attrNamespace = parser.getAttributeNamespace(index)?.takeIf { it.isNotEmpty() }
                        element.setAttributeNS(attrNamespace, attrQualifiedName, parser.getAttributeValue(index))
                    }
                    if (elements.isEmpty()) {
                        document.appendChild(element)
                    } else {
                        elements.last().appendChild(element)
                    }
                    elements.addLast(element)
                }
                XmlPullParser.END_TAG -> if (elements.isNotEmpty()) elements.removeLast()
                XmlPullParser.TEXT -> if (elements.isNotEmpty()) {
                    elements.last().appendChild(document.createTextNode(parser.text.orEmpty()))
                }
                XmlPullParser.CDSECT -> if (elements.isNotEmpty()) {
                    elements.last().appendChild(document.createCDATASection(parser.text.orEmpty()))
                }
                XmlPullParser.COMMENT -> if (elements.isNotEmpty()) {
                    elements.last().appendChild(document.createComment(parser.text.orEmpty()))
                }
                XmlPullParser.DOCDECL, XmlPullParser.ENTITY_REF ->
                    throw SAXException("DOCTYPE declarations and entity references are forbidden")
                XmlPullParser.END_DOCUMENT -> return document
            }
        }
    }

    private fun parseXmlWithHardenedJaxp(xml: String): Document {
        val factory = DocumentBuilderFactory.newInstance().apply {
            isNamespaceAware = true
            isValidating = false
            isXIncludeAware = false

            // TTML does not need DTDs or external entities. Treat unsupported security
            // features as a hard failure rather than silently parsing with weaker defaults.
            setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true)
            setFeature("http://apache.org/xml/features/disallow-doctype-decl", true)
            setFeature("http://xml.org/sax/features/external-general-entities", false)
            setFeature("http://xml.org/sax/features/external-parameter-entities", false)
            setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false)
            setAttribute("http://javax.xml.XMLConstants/property/accessExternalDTD", "")
            setAttribute("http://javax.xml.XMLConstants/property/accessExternalSchema", "")

            require(getFeature(XMLConstants.FEATURE_SECURE_PROCESSING))
            require(getFeature("http://apache.org/xml/features/disallow-doctype-decl"))
            require(!getFeature("http://xml.org/sax/features/external-general-entities"))
            require(!getFeature("http://xml.org/sax/features/external-parameter-entities"))
            require(!getFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd"))
            require(!isXIncludeAware)
            require(getAttribute("http://javax.xml.XMLConstants/property/accessExternalDTD") == "")
            require(getAttribute("http://javax.xml.XMLConstants/property/accessExternalSchema") == "")
        }
        val builder = factory.newDocumentBuilder().apply {
            setEntityResolver { _, systemId ->
                throw SAXException("External XML resources are forbidden: $systemId")
            }
        }
        return builder.parse(InputSource(StringReader(xml)))
    }

    /**
     * Exact port of validateTtml in src/utils/lyrics-parsers/validate-ttml.ts
     */
    fun validateTtml(xml: String): TtmlValidation {
        if (xml.isBlank()) return TtmlValidation.Error("the document is not well-formed (empty)")
        val doc = parseXmlDocument(xml).getOrElse { err ->
            return TtmlValidation.Error(err.message?.lineSequence()?.firstOrNull() ?: "XML is not well-formed")
        }
        val root = doc.documentElement
        if (root == null || (root.localName ?: root.tagName.substringAfterLast(':')) != "tt") {
            return TtmlValidation.Error("Root element must be <tt>")
        }

        val issues = validateSemantics(doc)
        return if (issues.isEmpty()) TtmlValidation.Ok else TtmlValidation.Warnings(issues)
    }

    /**
     * TTML validation is intentionally conservative: malformed XML/root is fatal, while semantic
     * and timing anomalies are reported as reviewable issues because TTML permits timing
     * inheritance, overlapping singers, foreign namespaces, and vendor extensions.
     */
    private fun validateSemantics(doc: Document): List<TtmlValidationIssue> {
        val issues = mutableListOf<TtmlValidationIssue>()
        val root = doc.documentElement
        val ttpNs = TtmlConstants.TTP_NS
        val frameRate = root.getAttributeNS(ttpNs, "frameRate").toDoubleOrNull()
            ?.takeIf { it.isFinite() && it > 0.0 } ?: 30.0
        val multiplierParts = root.getAttributeNS(ttpNs, "frameRateMultiplier")
            .trim().split(Regex("\\s+")).mapNotNull { it.toDoubleOrNull() }
        val frameRateMultiplier = if (multiplierParts.size == 2 && multiplierParts[1] != 0.0) {
            multiplierParts[0] / multiplierParts[1]
        } else 1.0
        val effectiveFrameRate = frameRate * frameRateMultiplier
        val tickRate = root.getAttributeNS(ttpNs, "tickRate").toDoubleOrNull()
            ?.takeIf { it.isFinite() && it > 0.0 } ?: effectiveFrameRate

        fun localName(node: Node): String =
            (node.localName ?: node.nodeName.substringAfterLast(':')).lowercase(Locale.ROOT)

        fun time(element: Element, attribute: String): Double? {
            val raw = element.getAttribute(attribute).takeIf { it.isNotBlank() } ?: return null
            return TtmlFormatting.parseTimeExpression(raw, effectiveFrameRate, tickRate)
        }

        val ids = mutableMapOf<String, String>()
        val agents = mutableSetOf<String>()
        val elements = doc.getElementsByTagName("*")
        for (index in 0 until elements.length) {
            val node = elements.item(index) as? Element ?: continue
            val name = localName(node)
            val location = "$name[${index + 1}]"
            val id = node.getAttributeNS(TtmlConstants.XML_NS, "id")
                .ifBlank { node.getAttribute("xml:id") }
                .ifBlank { node.getAttribute("id") }
            if (id.isNotBlank()) {
                val previous = ids[id]
                if (previous != null) {
                    issues += TtmlValidationIssue(
                        TtmlIssueSeverity.WARNING, location, "Duplicate identifier '$id' (first declared at $previous)."
                    )
                } else {
                    ids[id] = location
                }
                if (name == "agent") agents += id.removePrefix("#")
            }
            for (attribute in listOf("begin", "end", "dur")) {
                val raw = node.getAttribute(attribute).takeIf { it.isNotBlank() } ?: continue
                if (TtmlFormatting.parseTimeExpression(raw, effectiveFrameRate, tickRate) == null) {
                    issues += TtmlValidationIssue(
                        TtmlIssueSeverity.TIMING, location, "Invalid TTML $attribute time expression '$raw'."
                    )
                }
            }

            val beginRaw = node.getAttribute("begin").takeIf { it.isNotBlank() }
            val endRaw = node.getAttribute("end").takeIf { it.isNotBlank() }
            if (beginRaw != null && endRaw != null) {
                val begin = TtmlFormatting.parseTimeExpression(beginRaw, effectiveFrameRate, tickRate)
                val end = TtmlFormatting.parseTimeExpression(endRaw, effectiveFrameRate, tickRate)
                if (begin != null && end != null) {
                    if (begin < 0.0 || end < 0.0) {
                        issues += TtmlValidationIssue(TtmlIssueSeverity.TIMING, location, "Negative timing is not valid for media-time TTML.")
                    } else if (end <= begin) {
                        issues += TtmlValidationIssue(TtmlIssueSeverity.TIMING, location, "End time must be later than begin time.")
                    }
                }
            }
        }

        // Check sequential sibling spans, not all descendants: x-bg, nested highlights, and
        // different singer layers can intentionally overlap in time.
        val paragraphs = doc.getElementsByTagNameNS("*", "p")
        for (pIndex in 0 until paragraphs.length) {
            val paragraph = paragraphs.item(pIndex) as? Element ?: continue
            val pending = ArrayDeque<Triple<Element, String, Int>>()
            pending.addLast(Triple(paragraph, "p[${pIndex + 1}]", 0))
            while (pending.isNotEmpty()) {
                val (parent, path, depth) = pending.removeLast()
                if (depth > 512) {
                    issues += TtmlValidationIssue(
                        TtmlIssueSeverity.UNSUPPORTED, path,
                        "TTML element nesting exceeds the validator's safe inspection depth."
                    )
                    continue
                }
                val children = mutableListOf<Element>()
                val childNodes = parent.childNodes
                for (childIndex in 0 until childNodes.length) {
                    (childNodes.item(childIndex) as? Element)?.let(children::add)
                }
                var precedingEnd: Double? = null
                var timedIndex = 0
                for (child in children) {
                    if (localName(child) == "span") {
                        val begin = time(child, "begin")
                        val end = time(child, "end")
                        if (begin != null && end != null && end > begin) {
                            timedIndex++
                            if (precedingEnd != null && begin < precedingEnd - 0.001) {
                                issues += TtmlValidationIssue(
                                    TtmlIssueSeverity.TIMING,
                                    "$path/span[$timedIndex]",
                                    "Timed sibling span overlaps a preceding span; review unless intentional."
                                )
                            }
                            precedingEnd = max(precedingEnd ?: end, end)
                        }
                    }
                }
                for (child in children.asReversed()) {
                    pending.addLast(Triple(child, "$path/${localName(child)}", depth + 1))
                }
            }
        }

        val body = doc.getElementsByTagNameNS("*", "body").item(0) as? Element
        val bodyDuration = body?.let { time(it, "dur") }
        if (bodyDuration != null) {
            for (pIndex in 0 until paragraphs.length) {
                val paragraph = paragraphs.item(pIndex) as? Element ?: continue
                val end = time(paragraph, "end")
                if (end != null && end > bodyDuration + 0.001) {
                    issues += TtmlValidationIssue(
                        TtmlIssueSeverity.TIMING, "p[${pIndex + 1}]",
                        "Paragraph ends after body duration ($end > $bodyDuration seconds)."
                    )
                }
            }
        }

        for (index in 0 until paragraphs.length) {
            val paragraph = paragraphs.item(index) as? Element ?: continue
            val agent = getAttr(paragraph, "ttm:agent", TtmlConstants.TTM_NS, "agent")
                ?.removePrefix("#") ?: continue
            if (agents.isNotEmpty() && agent !in agents) {
                issues += TtmlValidationIssue(
                    TtmlIssueSeverity.WARNING, "p[${index + 1}]",
                    "Singer/agent reference '$agent' is not declared in this document."
                )
            }
        }
        return issues.distinct()
    }

    private fun getAttr(el: Element, prefixedName: String, nsUri: String? = null, localName: String? = null): String? {
        if (el.hasAttribute(prefixedName)) {
            val v = el.getAttribute(prefixedName)
            if (v.isNotEmpty()) return v
        }
        if (nsUri != null && localName != null && el.hasAttributeNS(nsUri, localName)) {
            val v = el.getAttributeNS(nsUri, localName)
            if (v.isNotEmpty()) return v
        }
        return null
    }

    private fun getComposerAttribute(el: Element, name: String): String? {
        val prefixed = el.getAttribute("composer:$name")
        if (prefixed.isNotEmpty()) return prefixed
        for (ns in TtmlConstants.COMPOSER_NAMESPACES) {
            val v = el.getAttributeNS(ns, name)
            if (v.isNotEmpty()) return v
        }
        return null
    }

    private fun elementRole(el: Element): String? =
        getAttr(el, "ttm:role", TtmlConstants.TTM_NS, "role")

    private fun readExplicitFlag(el: Element): Boolean {
        val map = el.attributes ?: return false
        for (i in 0 until map.length) {
            val attr = map.item(i)
            val local = (attr.localName ?: attr.nodeName.substringAfterLast(':')).lowercase(Locale.ROOT)
            if (local == "explicit" || local == "obscene") {
                val raw = (attr.nodeValue ?: "").trim().lowercase(Locale.ROOT)
                return raw.isEmpty() || raw == "true" || raw == "1" || raw == "yes"
            }
        }
        return false
    }

    /**
     * Exact port of extractTimedWords in src/utils/lyrics-parsers/ttml-helpers.ts
     */
    fun extractTimedWords(parent: Element, excludeContainer: Element?): List<WordTiming> {
        val words = mutableListOf<WordTiming>()
        val children = parent.childNodes
        for (i in 0 until children.length) {
            val node = children.item(i)
            if (node.nodeType == Node.ELEMENT_NODE) {
                val el = node as Element
                val role = elementRole(el)
                if (role == "x-bg" || (excludeContainer != null && el == excludeContainer)) continue

                val tagName = (el.localName ?: el.tagName).lowercase(Locale.ROOT)
                if (tagName == "span" && el.hasAttribute("begin")) {
                    val begin = TtmlFormatting.parseTtmlTimestamp(el.getAttribute("begin"))
                    val end = TtmlFormatting.parseTtmlTimestamp(el.getAttribute("end"))
                    val text = el.textContent ?: ""
                    if (text.trim().isNotEmpty()) {
                        words.add(
                            WordTiming(
                                text = text,
                                begin = begin,
                                end = end,
                                explicit = readExplicitFlag(el)
                            )
                        )
                    }
                }
            } else if (node.nodeType == Node.TEXT_NODE) {
                val content = node.textContent ?: ""
                if (content.any { it.isWhitespace() } && words.isNotEmpty()) {
                    val last = words.last()
                    if (!last.text.endsWith(" ")) {
                        words[words.lastIndex] = last.copy(text = "${last.text} ")
                    }
                }
            }
        }
        return words
    }

    /**
     * Exact port of parseTtml in src/utils/lyrics-parsers/ttml.ts
     */
    fun parseTtml(content: String, fallbackDuration: Double? = null): ParseResult {
        val unescaped = content.replace("\\\"", "\"").replace("\\n", "\n")
        val patched = declareMissingNamespaces(unescaped)
        val doc = parseXmlDocument(patched).getOrElse {
            return ParseResult(
                lines = emptyList(),
                metadata = ProjectMetadata(),
                hasTimingData = false,
                issues = listOf(ParseIssue(1, "", "empty-document"))
            )
        }

        // 1. Metadata
        var title = ""
        val titleList = doc.getElementsByTagName("title")
        if (titleList.length > 0) title = titleList.item(0).textContent?.trim().orEmpty()
        if (title.isEmpty()) {
            val ttmTitleList = doc.getElementsByTagName("ttm:title")
            if (ttmTitleList.length > 0) title = ttmTitleList.item(0).textContent?.trim().orEmpty()
        }

        val docLang = TtmlFormatting.normalizeLanguageTag(doc.documentElement.getAttribute("xml:lang"))

        val metaPairs = mutableListOf<MetaPair>()
        val metaNodes = doc.getElementsByTagName("composer:meta")
        for (i in 0 until metaNodes.length) {
            val el = metaNodes.item(i) as Element
            metaPairs.add(MetaPair(el.getAttribute("key"), el.getAttribute("value")))
        }
        val mappedMeta = MetadataTtmlMapper.fromComposerMeta(metaPairs)
        val bodyList = doc.getElementsByTagName("body")
        val bodyDur = if (bodyList.length > 0) {
            val durStr = (bodyList.item(0) as Element).getAttribute("dur")
            if (durStr.isNotBlank()) TtmlFormatting.parseTtmlTimestamp(durStr) else 0.0
        } else 0.0

        val finalMetadata = mappedMeta.copy(
            title = title.ifEmpty { mappedMeta.title },
            language = docLang ?: mappedMeta.language,
            duration = if (bodyDur > 0.0) bodyDur else (fallbackDuration ?: 0.0)
        )

        // 2. Agents
        val agents = mutableListOf<Agent>()
        val agentNodes = doc.getElementsByTagName("ttm:agent")
        for (i in 0 until agentNodes.length) {
            val el = agentNodes.item(i) as Element
            val id = getAttr(el, "xml:id", TtmlConstants.XML_NS, "id") ?: continue
            val type = AgentType.fromXml(el.getAttribute("type"))
            val nameNodes = el.getElementsByTagName("ttm:name")
            val name = if (nameNodes.length > 0) nameNodes.item(0).textContent?.trim() else "Voice ${agents.size + 1}"
            agents.add(Agent(id = id, type = type, name = name))
        }

        // 3. Groups
        val groups = mutableListOf<LinkGroup>()
        val seenGroupIds = mutableSetOf<String>()
        val groupNodes = doc.getElementsByTagName("composer:group")
        for (i in 0 until groupNodes.length) {
            val el = groupNodes.item(i) as Element
            val id = el.getAttribute("id").takeIf { it.isNotBlank() } ?: continue
            if (!seenGroupIds.add(id)) continue
            val label = el.getAttribute("label").ifBlank { "Group" }
            val color = el.getAttribute("color").ifBlank { "#9ca3af" }
            val templateVersion = el.getAttribute("templateVersion").toIntOrNull() ?: 1
            groups.add(LinkGroup(id, label, color, templateVersion))
        }

        // 4. Paragraphs (<p>)
        val lines = mutableListOf<LyricLine>()
        val paragraphs = doc.getElementsByTagName("p")
        val lineIndexesByTtmlKey = mutableMapOf<String, Int>()
        for (i in 0 until paragraphs.length) {
            val p = paragraphs.item(i) as Element
            val previousLineCount = lines.size
            val begin = TtmlFormatting.parseTtmlTimestamp(p.getAttribute("begin"))
            val end = TtmlFormatting.parseTtmlTimestamp(p.getAttribute("end"))
            val agentId = (getAttr(p, "ttm:agent", TtmlConstants.TTM_NS, "agent") ?: "v1").removePrefix("#")

            val rawGroupId = getComposerAttribute(p, "groupId")
            val knownGroupId = if (rawGroupId != null && seenGroupIds.contains(rawGroupId)) rawGroupId else null
            val instanceIdx = getComposerAttribute(p, "instanceIdx")?.toIntOrNull()
            val templateLineIdx = getComposerAttribute(p, "templateLineIdx")?.toIntOrNull()
            val detached = getComposerAttribute(p, "detached") == "true"

            // Locate x-bg span
            var bgContainer: Element? = null
            val allSpans = p.getElementsByTagName("span")
            for (s in 0 until allSpans.length) {
                val span = allSpans.item(s) as Element
                if (elementRole(span) == "x-bg") {
                    bgContainer = span
                    break
                }
            }

            var backgroundText: String? = null
            var backgroundWords: List<WordTiming>? = null
            if (bgContainer != null) {
                val extractedBg = WordSpacesAndSyllables.inferSyllableGroupIds(extractTimedWords(bgContainer, null))
                if (extractedBg.isNotEmpty()) {
                    backgroundWords = extractedBg
                    backgroundText = WordSpacesAndSyllables.reconstructLineText(extractedBg)
                } else {
                    backgroundText = bgContainer.textContent?.trim()?.takeIf { it.isNotEmpty() }
                }
            }
            val backgroundTextSource = if (backgroundText != null || !backgroundWords.isNullOrEmpty()) {
                BackgroundSource.MANUAL
            } else null

            val words = WordSpacesAndSyllables.inferSyllableGroupIds(extractTimedWords(p, bgContainer))
            if (words.isNotEmpty()) {
                lines.add(
                    LyricLine(
                        id = NanoIdGenerator.generateLineId(),
                        text = WordSpacesAndSyllables.reconstructLineText(words),
                        agentId = agentId,
                        words = words,
                        backgroundText = backgroundText,
                        backgroundWords = backgroundWords,
                        backgroundTextSource = backgroundTextSource,
                        groupId = knownGroupId,
                        instanceIdx = if (knownGroupId != null) (instanceIdx ?: 0) else null,
                        templateLineIdx = if (knownGroupId != null) (templateLineIdx ?: 0) else null,
                        detached = if (knownGroupId != null && detached) true else null
                    ).reconcile()
                )
            } else {
                val sb = StringBuilder()
                val childNodes = p.childNodes
                for (c in 0 until childNodes.length) {
                    val node = childNodes.item(c)
                    if (node.nodeType == Node.TEXT_NODE) {
                        sb.append(node.textContent ?: "")
                    } else if (node.nodeType == Node.ELEMENT_NODE) {
                        val el = node as Element
                        if (elementRole(el) != "x-bg") {
                            sb.append(el.textContent ?: "")
                        }
                    }
                }
                val text = sb.toString().trim()
                if (text.isNotEmpty()) {
                    lines.add(
                        LyricLine(
                            id = NanoIdGenerator.generateLineId(),
                            text = text,
                            agentId = agentId,
                            begin = if (p.hasAttribute("begin")) begin else null,
                            end = if (p.hasAttribute("end")) end else null,
                            backgroundText = backgroundText,
                            backgroundWords = backgroundWords,
                            backgroundTextSource = backgroundTextSource,
                            groupId = knownGroupId,
                            instanceIdx = if (knownGroupId != null) (instanceIdx ?: 0) else null,
                            templateLineIdx = if (knownGroupId != null) (templateLineIdx ?: 0) else null,
                            detached = if (knownGroupId != null && detached) true else null
                        ).reconcile()
                    )
                }
            }
            if (lines.size > previousLineCount) {
                val ttmlKey = getAttr(p, "itunes:key", TtmlConstants.APPLE_LYRIC_NS, "key")
                    ?.takeIf { it.isNotBlank() }
                if (ttmlKey != null) lineIndexesByTtmlKey[ttmlKey] = lines.lastIndex
            }
        }

        // Apple-style iTunesMetadata tracks reference paragraph keys using <text for="L1">.
        // Resolve these only after every paragraph has been parsed so document ordering is free.
        val translationsByLine = mutableMapOf<Int, MutableMap<String, TranslationTrack>>()
        val transliterationsByLine = mutableMapOf<Int, TransliterationTrack>()

        fun trackText(textElement: Element): Pair<String, String?> {
            val main = StringBuilder()
            var background: String? = null
            val children = textElement.childNodes
            for (childIndex in 0 until children.length) {
                val child = children.item(childIndex)
                if (child.nodeType == Node.TEXT_NODE || child.nodeType == Node.CDATA_SECTION_NODE) {
                    main.append(child.nodeValue.orEmpty())
                } else if (child.nodeType == Node.ELEMENT_NODE) {
                    val element = child as Element
                    if (elementRole(element) == "x-bg") {
                        background = element.textContent?.trim()?.takeIf { it.isNotEmpty() }
                    } else {
                        main.append(element.textContent.orEmpty())
                    }
                }
            }
            return main.toString().trim() to background
        }

        fun trackLanguage(element: Element): String? =
            getAttr(element, "xml:lang", TtmlConstants.XML_NS, "lang")
                ?.let(TtmlFormatting::normalizeLanguageTag)

        val translationNodes = doc.getElementsByTagNameNS(TtmlConstants.APPLE_LYRIC_NS, "translation")
        for (translationIndex in 0 until translationNodes.length) {
            val translation = translationNodes.item(translationIndex) as? Element ?: continue
            val language = trackLanguage(translation) ?: continue
            val textNodes = translation.getElementsByTagNameNS("*", "text")
            for (textIndex in 0 until textNodes.length) {
                val textElement = textNodes.item(textIndex) as? Element ?: continue
                val key = getAttr(textElement, "for")?.removePrefix("#") ?: continue
                val lineIndex = lineIndexesByTtmlKey[key] ?: continue
                val (text, background) = trackText(textElement)
                if (text.isEmpty() && background.isNullOrEmpty()) continue
                translationsByLine.getOrPut(lineIndex) { linkedMapOf() }[language] =
                    TranslationTrack(language = language, text = text, backgroundText = background)
            }
        }

        val transliterationNodes = doc.getElementsByTagNameNS(TtmlConstants.APPLE_LYRIC_NS, "transliteration")
        for (trackIndex in 0 until transliterationNodes.length) {
            val track = transliterationNodes.item(trackIndex) as? Element ?: continue
            val language = trackLanguage(track) ?: continue
            val textNodes = track.getElementsByTagNameNS("*", "text")
            for (textIndex in 0 until textNodes.length) {
                val textElement = textNodes.item(textIndex) as? Element ?: continue
                val key = getAttr(textElement, "for")?.removePrefix("#") ?: continue
                val lineIndex = lineIndexesByTtmlKey[key] ?: continue
                val (text, background) = trackText(textElement)
                if (text.isEmpty() && background.isNullOrEmpty()) continue
                transliterationsByLine[lineIndex] = TransliterationTrack(
                    language = language,
                    text = text,
                    backgroundText = background,
                    segments = listOf(TransliterationSegment(lines[lineIndex].text, text))
                )
            }
        }

        for (lineIndex in lines.indices) {
            val translations = translationsByLine[lineIndex]
            val transliteration = transliterationsByLine[lineIndex]
            if (translations != null || transliteration != null) {
                lines[lineIndex] = lines[lineIndex].copy(
                    translations = translations,
                    transliteration = transliteration
                )
            }
        }

        return ParseResult(
            lines = lines,
            metadata = finalMetadata,
            hasTimingData = lines.any { it.begin != null || !it.words.isNullOrEmpty() },
            agents = agents.takeIf { it.isNotEmpty() },
            groups = groups.takeIf { it.isNotEmpty() },
            issues = emptyList()
        )
    }
}
