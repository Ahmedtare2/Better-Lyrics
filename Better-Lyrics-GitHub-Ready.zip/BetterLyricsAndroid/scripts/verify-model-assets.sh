#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
MODEL_DIR="${MODEL_ASSETS_DIR:-${ROOT_DIR}/app/src/main/assets/models}"

required_models=("ctc_ar.onnx:50000000" "ctc_en.onnx:50000000" "htdemucs_fp16.onnx:100000000")
for entry in "${required_models[@]}"; do
  name="${entry%%:*}"
  minimum="${entry##*:}"
  path="${MODEL_DIR}/${name}"
  if [[ ! -s "$path" ]]; then
    echo "Required model asset is missing: ${path}" >&2
    exit 1
  fi
  size="$(stat -c '%s' "$path")"
  if (( size < minimum )); then
    echo "Required model asset is incomplete: ${name} is ${size} bytes; expected at least ${minimum}." >&2
    exit 1
  fi
  first_byte="$(od -An -N1 -tx1 "$path" | tr -d '[:space:]')"
  if [[ "$first_byte" == "3c" ]]; then
    echo "Model asset ${name} appears to contain an HTML error response." >&2
    exit 1
  fi
done

for vocab in vocab_ar.json vocab_en.json; do
  path="${MODEL_DIR}/${vocab}"
  if [[ ! -s "$path" ]]; then
    echo "Required vocabulary asset is missing: ${path}" >&2
    exit 1
  fi
  python3 - "$path" <<'PY'
import json
import pathlib
import sys

path = pathlib.Path(sys.argv[1])
try:
    data = json.loads(path.read_text(encoding="utf-8"))
except Exception as exc:
    raise SystemExit(f"Invalid vocabulary JSON {path.name}: {exc}")
if not isinstance(data, dict) or not data:
    raise SystemExit(f"Vocabulary {path.name} must be a non-empty JSON object")
PY
done

# Verify meta files (required for blank_id and word_delimiter_token)
for meta in meta_ar.json meta_en.json; do
  path="${MODEL_DIR}/${meta}"
  if [[ ! -s "$path" ]]; then
    echo "Required metadata asset is missing: ${path}" >&2
    exit 1
  fi
  python3 - "$path" <<'PY'
import json
import pathlib
import sys

path = pathlib.Path(sys.argv[1])
try:
    data = json.loads(path.read_text(encoding="utf-8"))
except Exception as exc:
    raise SystemExit(f"Invalid metadata JSON {path.name}: {exc}")
if not isinstance(data, dict) or not data:
    raise SystemExit(f"Metadata {path.name} must be a non-empty JSON object")
# Check for required fields
if "blank_id" not in data and "pad_token_id" not in data:
    print(f"Warning: {path.name} missing blank_id/pad_token_id", file=sys.stderr)
if "word_delimiter_token" not in data and "delimiter" not in data:
    print(f"Warning: {path.name} missing word_delimiter_token/delimiter", file=sys.stderr)
PY
done

if [[ ! -s "${MODEL_DIR}/model-assets.properties" || ! -s "${MODEL_DIR}/model-assets.sha256" ]]; then
  echo "Pinned model provenance/integrity manifests are missing." >&2
  exit 1
fi
(
  cd "$MODEL_DIR"
  sha256sum --check --status model-assets.sha256
)

echo "Verified required Arabic/English CTC models, vocabularies, metadata, and HTDemucs model:"
du -h "${MODEL_DIR}"/*.onnx "${MODEL_DIR}"/*.json
