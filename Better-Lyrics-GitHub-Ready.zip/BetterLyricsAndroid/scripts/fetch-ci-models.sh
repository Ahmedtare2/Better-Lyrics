#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
MODEL_DIR="${ROOT_DIR}/app/src/main/assets/models"
mkdir -p "$MODEL_DIR"

# Revisions are pinned to immutable Hugging Face repository commits. Source ONNX hashes are the
# repositories' published LFS SHA-256 values and are checked before packaging.
AR_REPO="onnx-community/wav2vec2-base-arabic-without-reused-en-token-ids-v1-ONNX"
AR_REV="908b2bead4fe5c3ea5d5e31be904129fda068f74"
AR_MODEL_SHA="209d73e012442c76b68a1df998e758876cda48c621bea28dae7e88c252d1773c"
EN_REPO="onnx-community/wav2vec2-base-960h-ONNX"
EN_REV="729c1a6730fb549c20a1c73a3d3f96f11020225e"
EN_MODEL_SHA="1d9a366c27b2966625cd5035ac3db8847c53bba617169912bb251b42975a3a22"
DEMUCS_REPO="StemSplitio/htdemucs-onnx"
DEMUCS_REV="d54ed9eb60e258ea82131c6ee14578628816456a"
DEMUCS_SHA="d05c269d0178d2a72ad484b10b11dd370193fc923201c3b27a99f848745db70a"

download_verified() {
  local target="$1" url="$2" expected_sha="$3" minimum_bytes="$4"
  local temp="${target}.part"
  rm -f "$temp"
  echo "Downloading $(basename "$target") from pinned model revision."
  curl --fail --location --retry 4 --retry-all-errors --connect-timeout 30 \
    --max-time 1800 --output "$temp" "$url"
  if [[ -n "$expected_sha" ]]; then
    echo "${expected_sha}  ${temp}" | sha256sum --check --status
  fi
  if [[ "$(stat -c '%s' "$temp")" -lt "$minimum_bytes" ]]; then
    rm -f "$temp"
    echo "Downloaded model is smaller than its expected minimum: $(basename "$target")" >&2
    return 1
  fi
  mv "$temp" "$target"
}

# Arabic model (MMS-FA base) - download source, quantize to UINT8 MatMul
ar_source="${MODEL_DIR}/ctc_ar.source.onnx"
download_verified "$ar_source" \
  "https://huggingface.co/${AR_REPO}/resolve/${AR_REV}/onnx/model.onnx" \
  "$AR_MODEL_SHA" 300000000

# The upstream Arabic checkpoint is full precision. Preserve the project's established dynamic
# UINT8 MatMul quantization step, pin its tool versions, and verify the source before conversion.
python3 -m pip install --disable-pip-version-check --no-warn-script-location \
  "onnx==1.16.2" "onnxruntime==1.19.2"
python3 - "$ar_source" "${MODEL_DIR}/ctc_ar.onnx" <<'PY'
import os
import sys
from onnxruntime.quantization import QuantType, quantize_dynamic

source, destination = sys.argv[1:]
temporary = destination + ".part"
try:
    quantize_dynamic(
        source,
        temporary,
        weight_type=QuantType.QUInt8,
        op_types_to_quantize=["MatMul"],
    )
    if not os.path.isfile(temporary) or os.path.getsize(temporary) < 50_000_000:
        raise RuntimeError("Quantized Arabic model output is missing or unexpectedly small")
    os.replace(temporary, destination)
finally:
    if os.path.exists(temporary):
        os.remove(temporary)
    os.remove(source)
PY

# Arabic vocab and meta
download_verified "${MODEL_DIR}/vocab_ar.json" \
  "https://huggingface.co/${AR_REPO}/resolve/${AR_REV}/vocab.json" \
  "" 16
download_verified "${MODEL_DIR}/meta_ar.json" \
  "https://huggingface.co/${AR_REPO}/resolve/${AR_REV}/meta.json" \
  "" 16

# English model (download FP32 source, then quantize to UINT8 MatMul for 2x speedup)
en_source="${MODEL_DIR}/ctc_en.source.onnx"
download_verified "$en_source" \
  "https://huggingface.co/${EN_REPO}/resolve/${EN_REV}/onnx/model.onnx" \
  "$EN_MODEL_SHA" 150000000

python3 -m pip install --disable-pip-version-check --no-warn-script-location \
  "onnx==1.16.2" "onnxruntime==1.19.2"
python3 - "$en_source" "${MODEL_DIR}/ctc_en.onnx" <<'PY'
import os
import sys
from onnxruntime.quantization import QuantType, quantize_dynamic

source, destination = sys.argv[1:]
temporary = destination + ".part"
try:
    quantize_dynamic(
        source,
        temporary,
        weight_type=QuantType.QUInt8,
        op_types_to_quantize=["MatMul"],
    )
    if not os.path.isfile(temporary) or os.path.getsize(temporary) < 30_000_000:
        raise RuntimeError("Quantized English model output is missing or unexpectedly small")
    os.replace(temporary, destination)
finally:
    if os.path.exists(temporary):
        os.remove(temporary)
    os.remove(source)
PY

# English vocab and meta
download_verified "${MODEL_DIR}/vocab_en.json" \
  "https://huggingface.co/${EN_REPO}/resolve/${EN_REV}/vocab.json" \
  "" 16
download_verified "${MODEL_DIR}/meta_en.json" \
  "https://huggingface.co/${EN_REPO}/resolve/${EN_REV}/meta.json" \
  "" 16

# HTDemucs FP16
download_verified "${MODEL_DIR}/htdemucs_fp16.onnx" \
  "https://huggingface.co/${DEMUCS_REPO}/resolve/${DEMUCS_REV}/htdemucs_fp16weights.onnx" \
  "$DEMUCS_SHA" 100000000

# Generate provenance manifests
cat > "${MODEL_DIR}/model-assets.properties" <<EOF
arabic.repository=${AR_REPO}
arabic.revision=${AR_REV}
arabic.source.sha256=${AR_MODEL_SHA}
arabic.quantization=onnxruntime-1.19.2-dynamic-uint8-matmul
english.repository=${EN_REPO}
english.revision=${EN_REV}
english.source.sha256=${EN_MODEL_SHA}
english.quantization=onnxruntime-1.19.2-dynamic-uint8-matmul
demucs.repository=${DEMUCS_REPO}
demucs.revision=${DEMUCS_REV}
demucs.sha256=${DEMUCS_SHA}
EOF
(cd "$MODEL_DIR" && sha256sum ctc_ar.onnx ctc_en.onnx htdemucs_fp16.onnx vocab_ar.json vocab_en.json meta_ar.json meta_en.json > model-assets.sha256)

echo "Required model asset set downloaded and generated from pinned sources."
