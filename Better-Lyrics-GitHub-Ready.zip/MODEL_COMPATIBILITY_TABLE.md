# Model Asset Compatibility Table

## Models Expected by Android App (from ModelId enum + constants)

| ModelId / Constant | Filename | Vocab Filename | Required? | Purpose |
|---|---|---|---|---|
| HTDEMUCS_FP32 | htdemucs_fp32.onnx | - | Optional (FP32 fallback) | 4-stem vocal separation (FP32) |
| HTDEMUCS_FP16 | htdemucs_fp16.onnx | - | **Required** | 4-stem vocal separation (FP16) |
| MMS_FA_AR_EN_FP32 | ctc_ar.onnx | vocab_ar.json | **Required** | Arabic+English CTC (MMS-FA base) |
| PARSEH_ALIGNER_AR_INT8 | parseh_aligner_ar_int8.onnx | vocab_parseh_ar.json | Optional | Arabic CTC (XLSR-53 large) |
| UVR_MDXNET_KARA_2 | uvr_mdxnet_kara_2.onnx | - | Optional | Lead vs backing vocal separation |
| EN_CTC_FILENAME | ctc_en.onnx | vocab_en.json | **Required** | English CTC (wav2vec2-base-960h) |

## Additional Files Expected by App (hardcoded in service)

| File | Required? | Source |
|---|---|---|
| meta_ar.json | Optional (fallback exists) | Meta for Arabic CTC (blank_id, word_delimiter) |
| meta_en.json | Optional (fallback exists) | Meta for English CTC |
| meta_parseh_ar.json | Optional | Meta for Parseh Arabic CTC |

---

## CI Pipeline Downloads (fetch-ci-models.sh)

| File | Downloaded? | Source | Notes |
|---|---|---|---|
| ctc_ar.onnx | ✅ | onnx-community/wav2vec2-base-arabic (quantized UINT8 MatMul) | ~95MB equivalent |
| vocab_ar.json | ✅ | Same repo | |
| ctc_en.onnx | ✅ | onnx-community/wav2vec2-base-960h (pre-quantized) | ~50MB |
| vocab_en.json | ✅ | Same repo | |
| htdemucs_fp16.onnx | ✅ | StemSplitio/htdemucs-onnx | 166MB |
| meta_ar.json | ❌ | **NOT DOWNLOADED** | Needed for blank_id, word_delimiter |
| meta_en.json | ❌ | **NOT DOWNLOADED** | Needed for blank_id, word_delimiter |
| htdemucs_fp32.onnx | ❌ | NOT DOWNLOADED | Optional FP32 |
| parseh_aligner_ar_int8.onnx | ❌ | NOT DOWNLOADED | Optional Parseh XLSR-53 |
| vocab_parseh_ar.json | ❌ | NOT DOWNLOADED | Optional |
| meta_parseh_ar.json | ❌ | NOT DOWNLOADED | Optional |
| uvr_mdxnet_kara_2.onnx | ❌ | NOT DOWNLOADED | Optional |

---

## Offline Models on Phone (/storage/emulated/0/Download/TTML-models/)

### aligner-ar/ (Parseh XLSR-53 Arabic)
| File | Size | Format | Compatible? |
|---|---|---|---|
| model.int8.onnx | 356 MB | ONNX INT8 dynamic | ✅ **YES** - Parseh XLSR-53 Arabic |
| meta.json | 3.7 KB | JSON | ✅ **YES** - Contains blank_id=0, word_delimiter="|", vocab_size=51 |
| vocab.json | 507 B | JSON | ✅ **YES** - 51 tokens (Arabic + diacritics) |
| .cache/ | - | - | Internal cache |

**Compatibility**: This is the **PARSEH_ALIGNER_AR_INT8** model. The app expects `parseh_aligner_ar_int8.onnx` but the phone has `model.int8.onnx`. The SAF import logic in `tryImportFromDownloadTtmlModelsDir()` handles this by looking for `model.int8.onnx` in the aligner-ar directory and copying to `getArabicCtcFile()` (which expects `ctc_ar.onnx`). **This will work for Arabic CTC but uses the Parseh model instead of MMS-FA.**

### aligner-en/ (Parseh XLSR-53 English)
| File | Size | Format | Compatible? |
|---|---|---|---|
| model.int8.onnx | 356 MB | ONNX INT8 dynamic | ✅ **YES** - Parseh XLSR-53 English |
| meta.json | 4.0 KB | JSON | ✅ **YES** - Contains blank_id=0, word_delimiter="|", vocab_size=33 |
| vocab.json | 300 B | JSON | ✅ **YES** - 33 tokens (a-z, special) |
| .cache/ | - | - | Internal cache |

**Compatibility**: This is a Parseh-style English model. The app expects `ctc_en.onnx` for English. The SAF import will copy `model.int8.onnx` to `getEnglishCtcFile()` (ctc_en.onnx). **This will work for English CTC.**

---

## Key Compatibility Findings

1. **Phone models are Parseh XLSR-53 (340MB each)**, CI downloads **MMS-FA base models (~95MB each)**
   - Phone models: More accurate, larger, INT8 dynamic quantization
   - CI models: Smaller, UINT8 MatMul quantization, wav2vec2-base architecture
   - **Both are functional** - the CtcVocab loader handles both formats

2. **Vocabulary format is compatible** - Both use JSON token->id mapping with special tokens (<pad>, <s>, </s>, <unk>, |)

3. **Meta files on phone contain required fields** - blank_id, word_delimiter_token, vocab_size

4. **SAF import already handles phone models** - `tryImportFromDownloadTtmlModelsDir()` looks for `model.int8.onnx` in aligner-ar/ and aligner-en/ and copies to expected filenames

5. **Missing from CI**: meta_ar.json, meta_en.json (needed for explicit blank_id/word_delimiter), optional models (HTDEMUCS_FP32, PARSEH_ALIGNER_AR_INT8, UVR_MDXNET_KARA_2)

---

## Recommended Actions

### Required Fixes (for CI reliability)
1. **Add meta_ar.json and meta_en.json downloads** to fetch-ci-models.sh
2. **Update verify-model-assets.sh** to check for meta files
3. **Add optional model downloads** (or document they're optional)

### Optional Enhancements
1. **Add PARSEH_ALIGNER_AR_INT8 download** to CI (340MB) - but this bloats APK significantly
2. **Add UVR_MDXNET_KARA_2 download** (52MB) - for lead/backing separation
3. **Document that phone models can be imported via SAF** - no need to bundle everything

### APK Size Considerations
- Current bundled models (if all downloaded): ~400MB+
- Recommended: Only bundle **required** models (htdemucs_fp16.onnx, ctc_ar.onnx, ctc_en.onnx + vocabs + metas) = ~300MB
- Optional models should be downloaded on-demand or imported via SAF

---

## Model Loading Priority (in app)

1. **User-imported via SAF** (highest priority) - from /storage/emulated/0/Download/TTML-models/
2. **Bundled assets** (from APK assets/models/) - downloaded by CI
3. **Downloaded at runtime** - from HuggingFace via app UI
4. **Fallback vocabularies** (hardcoded in CtcVocab) - last resort

The app correctly preserves user-imported models and never overwrites them.
