package org.betterlyrics.android

import org.betterlyrics.android.alignment.BilingualForcedAlignmentEngine
import org.betterlyrics.android.alignment.BilingualScriptAndNormalizer
import org.betterlyrics.android.alignment.BilingualSyllabifier
import org.betterlyrics.android.alignment.CtcVocab
import org.betterlyrics.android.alignment.ForcedAlignmentConfig
import org.betterlyrics.android.alignment.WordScript
import org.betterlyrics.android.data.lyrics.LrcAndTextParser
import org.betterlyrics.android.domain.ttml.Agent
import org.betterlyrics.android.domain.ttml.AgentType
import org.betterlyrics.android.domain.ttml.BackgroundVocalExtractor
import org.betterlyrics.android.domain.ttml.LyricLine
import org.betterlyrics.android.domain.ttml.ProjectMetadata
import org.betterlyrics.android.domain.ttml.TTMLOptions
import org.betterlyrics.android.domain.ttml.TtmlFormatting
import org.betterlyrics.android.domain.ttml.TtmlConstants
import org.betterlyrics.android.domain.ttml.TtmlSerializer
import org.betterlyrics.android.domain.ttml.TtmlValidation
import org.betterlyrics.android.domain.ttml.TtmlValidatorAndParser
import org.betterlyrics.android.domain.ttml.TranslationTrack
import org.betterlyrics.android.domain.ttml.TransliterationTrack
import org.betterlyrics.android.domain.ttml.WordSpacesAndSyllables
import org.betterlyrics.android.domain.ttml.WordTiming
import org.betterlyrics.android.dsp.AudioCodec
import org.betterlyrics.android.dsp.DemucsChunkerAndSpec
import org.betterlyrics.android.dsp.LamePrimingParser
import org.betterlyrics.android.dsp.SpectralFluxAnalysis
import org.betterlyrics.android.dsp.SpectralOnsetDetector
import org.betterlyrics.android.dsp.StftProcessor
import org.betterlyrics.android.dsp.VocalOnsetSnapper
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.nio.file.Files
import java.net.ServerSocket
import java.net.SocketTimeoutException
import java.net.InetAddress
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sin

class TtmlAndDspParityTest {

    @Test
    fun ttmlParserRejectsExternalGeneralEntities() {
        val secret = Files.createTempFile("ttml-xxe-", ".txt")
        try {
            Files.writeString(secret, "LOCAL_FILE_SECRET")
            val xml = """
                <!DOCTYPE tt [
                  <!ENTITY xxe SYSTEM "${secret.toUri()}">
                ]>
                <tt xmlns="http://www.w3.org/ns/ttml">
                  <body><div><p begin="0:00.000" end="0:01.000">&xxe;</p></div></body>
                </tt>
            """.trimIndent()

            val parsed = TtmlValidatorAndParser.parseTtml(xml)
            assertTrue("DOCTYPE-bearing XML must be rejected", parsed.lines.isEmpty())
            assertTrue(parsed.issues.isNotEmpty())
            assertFalse(parsed.lines.any { it.text.contains("LOCAL_FILE_SECRET") })
        } finally {
            Files.deleteIfExists(secret)
        }
    }

    @Test
    fun ttmlParserRejectsExternalParameterEntitiesAndDtds() {
        val externalDtd = Files.createTempFile("ttml-dtd-", ".dtd")
        try {
            Files.writeString(externalDtd, "<!ENTITY payload 'EXTERNAL_DTD_SECRET'>")
            val xml = """
                <!DOCTYPE tt SYSTEM "${externalDtd.toUri()}">
                <tt xmlns="http://www.w3.org/ns/ttml">
                  <body><div><p begin="0:00.000" end="0:01.000">Safe text</p></div></body>
                </tt>
            """.trimIndent()

            val result = TtmlValidatorAndParser.parseXmlDocument(xml)
            assertTrue("External DTD must not be parsed", result.isFailure)
            assertTrue(TtmlValidatorAndParser.parseTtml(xml).lines.isEmpty())
        } finally {
            Files.deleteIfExists(externalDtd)
        }

        val parameterEntityXml = """
            <!DOCTYPE tt [
              <!ENTITY % remote SYSTEM "file:///etc/passwd">
              %remote;
            ]>
            <tt xmlns="http://www.w3.org/ns/ttml"/>
        """.trimIndent()
        assertTrue(TtmlValidatorAndParser.parseXmlDocument(parameterEntityXml).isFailure)
    }

    @Test
    fun ttmlParserDoesNotFetchExternalNetworkResources() {
        ServerSocket(0, 1, InetAddress.getByName("127.0.0.1")).use { server ->
            server.soTimeout = 700
            val executor = Executors.newSingleThreadExecutor()
            try {
                val acceptedConnection = executor.submit<Boolean> {
                    try {
                        server.accept().use { true }
                    } catch (_: SocketTimeoutException) {
                        false
                    }
                }
                val xml = """
                    <!DOCTYPE tt SYSTEM "http://${server.inetAddress.hostAddress}:${server.localPort}/external.dtd">
                    <tt xmlns="http://www.w3.org/ns/ttml"/>
                """.trimIndent()

                assertTrue(TtmlValidatorAndParser.parseXmlDocument(xml).isFailure)
                assertFalse("Parser must not make an external HTTP request", acceptedConnection.get(2, TimeUnit.SECONDS))
            } finally {
                executor.shutdownNow()
            }
        }
    }

    @Test
    fun ttmlParserDoesNotFetchXIncludeOrSchemaHints() {
        ServerSocket(0, 1, InetAddress.getByName("127.0.0.1")).use { server ->
            server.soTimeout = 700
            val executor = Executors.newSingleThreadExecutor()
            try {
                val acceptedConnection = executor.submit<Boolean> {
                    try {
                        server.accept().use { true }
                    } catch (_: SocketTimeoutException) {
                        false
                    }
                }
                val base = "http://${server.inetAddress.hostAddress}:${server.localPort}"
                val xml = """
                    <tt xmlns="http://www.w3.org/ns/ttml"
                        xmlns:xi="http://www.w3.org/2001/XInclude"
                        xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                        xsi:schemaLocation="http://www.w3.org/ns/ttml $base/ttml.xsd">
                      <body><div><xi:include href="$base/remote.xml"/></div></body>
                    </tt>
                """.trimIndent()

                assertTrue(TtmlValidatorAndParser.parseXmlDocument(xml).isSuccess)
                assertFalse("Parser must not resolve XInclude/schema URLs", acceptedConnection.get(2, TimeUnit.SECONDS))
            } finally {
                executor.shutdownNow()
            }
        }
    }

    @Test
    fun testArabicAndEnglishTtmlRoundTripAndOrthographyPreservation() {
        val arabicWords = listOf(
            WordTiming(text = "يَا ", begin = 1.250, end = 1.850, confidence = 0.91f),
            WordTiming(text = "حَبِيبِي ", begin = 1.850, end = 2.640, confidence = 0.88f),
            WordTiming(text = "أَهْوَاكَ", begin = 2.640, end = 3.900, confidence = 0.86f)
        )
        val bgWords = BackgroundVocalExtractor.bracketWordList(
            listOf(
                WordTiming(text = "آه ", begin = 2.800, end = 3.200, confidence = 0.82f),
                WordTiming(text = "يَا لَيْل", begin = 3.200, end = 3.850, confidence = 0.84f)
            )
        )

        val line1 = LyricLine(
            id = "line_ar_1",
            text = WordSpacesAndSyllables.reconstructLineText(arabicWords),
            agentId = "v1",
            words = arabicWords,
            backgroundText = WordSpacesAndSyllables.reconstructLineText(bgWords),
            backgroundWords = bgWords
        ).reconcile()

        // Multi-syllable English line with intra-word syllable split (no space between "hel" and "lo ")
        val englishWords = listOf(
            WordTiming(text = "hel", begin = 4.000, end = 4.250, syllableGroupId = "grp1"),
            WordTiming(text = "lo ", begin = 4.250, end = 4.600, syllableGroupId = "grp1"),
            WordTiming(text = "world", begin = 4.600, end = 5.200)
        )
        val line2 = LyricLine(
            id = "line_en_2",
            text = WordSpacesAndSyllables.reconstructLineText(englishWords),
            agentId = "v2",
            words = englishWords,
            translations = mapOf(
                "ar" to TranslationTrack(
                    language = "ar",
                    text = "مرحبا بالعالم",
                    backgroundText = "أهلاً"
                )
            ),
            transliteration = TransliterationTrack(
                language = "en",
                text = "marhaban bil aalami",
                backgroundText = "ahlan"
            )
        ).reconcile()

        val metadata = ProjectMetadata(
            title = "ليالي الشرق / Nights",
            artists = listOf("Fairuz", "Guest Vocal"),
            album = "Live in Cairo",
            duration = 185.42,
            isrc = "EGABC2600001",
            songwriters = listOf("Rahbani Brothers"),
            language = "ar"
        )

        val xml = TtmlSerializer.generateTTML(
            TTMLOptions(
                metadata = metadata,
                agents = listOf(
                    Agent("v1", AgentType.PERSON, "Lead"),
                    Agent("v2", AgentType.PERSON, "Duet")
                ),
                lines = listOf(line1, line2),
                duration = metadata.duration
            )
        )

        // 1. Validate XML well-formedness & root <tt>
        val validation = TtmlValidatorAndParser.validateTtml(xml)
        assertTrue("Expected valid TTML", validation is TtmlValidation.Ok)

        // 2. Verify exact syllable vs. word spacing rules
        assertTrue(
            "Intra-word syllables must be adjacent without space",
            xml.contains("<span begin=\"0:04.000\" end=\"0:04.250\">hel</span><span begin=\"0:04.250\" end=\"0:04.600\">lo</span> <span begin=\"0:04.600\" end=\"0:05.200\">world</span>")
        )

        // 3. Verify Arabic Tashkeel & Hamza orthography is 100% preserved in TTML output
        assertTrue(xml.contains("حَبِيبِي"))
        assertTrue(xml.contains("أَهْوَاكَ"))

        // 4. Verify round-trip parseTtml reconstructs syllable groups and background vocals
        val parsed = TtmlValidatorAndParser.parseTtml(xml)
        assertEquals(2, parsed.lines.size)
        assertEquals("EGABC2600001", parsed.metadata.isrc)
        assertEquals(2, parsed.lines[0].backgroundWords?.size)
        assertEquals(parsed.lines[1].words!![0].syllableGroupId, parsed.lines[1].words!![1].syllableGroupId)
        assertEquals("Duet", parsed.agents.orEmpty().first { it.id == "v2" }.name)
        assertEquals("مرحبا بالعالم", parsed.lines[1].translations?.get("ar")?.text)
        assertEquals("أهلاً", parsed.lines[1].translations?.get("ar")?.backgroundText)
        assertEquals("marhaban bil aalami", parsed.lines[1].transliteration?.text)
        assertEquals("ahlan", parsed.lines[1].transliteration?.backgroundText)
        val translationNodes = TtmlValidatorAndParser.parseXmlDocument(xml).getOrThrow()
            .getElementsByTagNameNS(TtmlConstants.APPLE_LYRIC_NS, "translation")
        assertEquals(1, translationNodes.length)
        assertTrue(translationNodes.item(0).textContent.contains("مرحبا بالعالم"))
        val reexported = TtmlSerializer.generateTTML(
            TTMLOptions(
                metadata = parsed.metadata,
                agents = parsed.agents.orEmpty(),
                lines = parsed.lines,
                groups = parsed.groups,
                duration = parsed.metadata.duration
            )
        )
        val reparsed = TtmlValidatorAndParser.parseTtml(reexported)
        assertEquals("مرحبا بالعالم", reparsed.lines[1].translations?.get("ar")?.text)
        assertEquals("marhaban bil aalami", reparsed.lines[1].transliteration?.text)
    }

    @Test
    fun testArabicNormalizationPreservesDisplayWhileNormalizingAcousticCtc() {
        val rawWord = "أُحِبُّكِ"
        val normalized = BilingualScriptAndNormalizer.normalizeForAcousticModel(rawWord)
        assertEquals("احبك", normalized)
        assertTrue(BilingualScriptAndNormalizer.hasArabicMaddOrMelisma("حَبِيبِي"))

        val egyptianColloquial = "مِشْ قَادِرْ أَنْسَىٰ كُلّ اللِّي فَاتْ"
        val normEg = egyptianColloquial.split(" ").joinToString(" ") {
            BilingualScriptAndNormalizer.normalizeForAcousticModel(it)
        }
        assertEquals("مش قادر انسي كل اللي فات", normEg)
    }

    @Test
    fun testBilingualScriptRoutingAndMixedArabicEnglishTokenization() {
        // Phase 2 & Phase 7 Test: Verify per-word script routing and orthography preservation on
        // "أنا feel alive لما you call me."
        val mixedLine = "أنا feel alive لما you call me."
        val engine = BilingualForcedAlignmentEngine()
        val tokens = engine.tokenizeLinePreservingOrthography(mixedLine)

        assertEquals(7, tokens.size)
        assertEquals("أنا", tokens[0].displaySurface)
        assertEquals(WordScript.ARABIC, tokens[0].script)
        assertTrue(tokens[0].trailingSpace)

        assertEquals("feel", tokens[1].displaySurface)
        assertEquals(WordScript.LATIN_ENGLISH, tokens[1].script)

        assertEquals("alive", tokens[2].displaySurface)
        assertEquals(WordScript.LATIN_ENGLISH, tokens[2].script)

        assertEquals("لما", tokens[3].displaySurface)
        assertEquals(WordScript.ARABIC, tokens[3].script)

        assertEquals("you", tokens[4].displaySurface)
        assertEquals(WordScript.LATIN_ENGLISH, tokens[4].script)

        assertEquals("call", tokens[5].displaySurface)
        assertEquals(WordScript.LATIN_ENGLISH, tokens[5].script)

        assertEquals("me.", tokens[6].displaySurface)
        assertEquals(WordScript.LATIN_ENGLISH, tokens[6].script)
        assertFalse(tokens[6].trailingSpace)

        // Verify both Arabic and English vocabularies resolve their own script tokens and reject cross-script tokens
        val arVocab = CtcVocab.fromJsonFile(null, isArabic = true)
        val enVocab = CtcVocab.fromJsonFile(null, isArabic = false)

        assertNotNull(arVocab.lookupCharIdOrNull('ا'))
        assertNotNull(arVocab.lookupCharIdOrNull('ن'))
        assertNull("Arabic vocab must not claim English letter 'f'", arVocab.lookupCharIdOrNull('f'))

        assertNotNull(enVocab.lookupCharIdOrNull('f'))
        assertNotNull(enVocab.lookupCharIdOrNull('e'))
        assertNull("English vocab must not claim Arabic letter 'ل'", enVocab.lookupCharIdOrNull('ل'))
    }

    @Test
    fun missingNeuralModelProducesExplicitReviewRequiredHeuristicTiming() = kotlinx.coroutines.runBlocking {
        val sampleRate = BilingualForcedAlignmentEngine.CTC_SAMPLE_RATE
        val audio = FloatArray(sampleRate * 2) { index ->
            val seconds = index.toDouble() / sampleRate
            if (seconds in 0.20..0.85) (0.2 * sin(2.0 * PI * 220.0 * seconds)).toFloat() else 0f
        }
        val inputLine = LyricLine(
            id = "heuristic_only",
            text = "نور",
            begin = 0.20,
            end = 0.85
        )
        val engine = BilingualForcedAlignmentEngine()

        val result = engine.alignLyricsToVocalStem(
            lines = listOf(inputLine),
            vocalChannels44k = arrayOf(FloatArray(0), FloatArray(0)),
            songDurationSeconds = 2.0,
            ctcModelFile = null,
            arabicCtcModelFile = null,
            englishCtcModelFile = null,
            precomputedVocalMono16k = audio,
            precomputedLeadVocalMono16k = audio,
            precomputedOnsetAnalysis = SpectralFluxAnalysis(
                novelty = FloatArray(90),
                rms = FloatArray(90) { 0.1f },
                onsetsSeconds = doubleArrayOf(0.20)
            ),
            config = ForcedAlignmentConfig(
                snapToSpectralOnsets = false,
                autoCorrectLrcGlobalOffset = false,
                enableCrossLineCoupledAlignment = false
            )
        )

        val word = result.single().words!!.single()
        assertTrue(word.needsReview)
        assertTrue((word.confidence ?: 1f) <= 0.45f)
        assertTrue(engine.lastAlignmentUsedHeuristicFallback)
        assertTrue(engine.lastAlignmentDiagnostics.any { it.contains("unavailable") || it.contains("Single-token") })
    }

    @Test
    fun testCtcVocabExplicitOovAndEgyptianSecondaryVariantLookup() {
        val vocab = CtcVocab(
            mapOf(
                "<pad>" to 0,
                "<s>" to 1,
                "</s>" to 2,
                "<unk>" to 3,
                "|" to 4,
                "ء" to 5,
                "ا" to 6,
                "ت" to 7,
                "س" to 8,
                "ز" to 9,
                "ق" to 10
            )
        )
        assertEquals(0, vocab.blankId)
        assertEquals(4, vocab.wordDelimiterId)
        assertEquals(6, vocab.lookupCharIdOrNull('ا'))
        assertEquals(5, vocab.lookupSecondaryCharIdOrNull('ق'))
        assertEquals(8, vocab.lookupSecondaryCharIdOrNull('ث'))
        assertEquals(9, vocab.lookupSecondaryCharIdOrNull('ذ'))
        assertEquals(7, vocab.lookupSecondaryCharIdOrNull('ة'))
        assertNull(vocab.lookupCharIdOrNull('ژ'))
        assertNull(vocab.lookupCharIdOrNull('9'))

        val qalouManners = BilingualScriptAndNormalizer.classifyPhonemeManner("قالوا", "قالوا")
        val qalouWeights = BilingualScriptAndNormalizer.computeAcousticUnitWeights("قالوا", qalouManners)
        assertEquals(0.15f, qalouWeights.last(), 1e-4f)
    }

    @Test
    fun testWav2Vec2ConvolutionalFrameToTimeCenterCalibration() {
        val t0 = 0
        val centerSample0 = 160 * t0 + 256 // 256
        val mExact0 = (centerSample0 - 200.0) / 320.0
        assertEquals(0.175, mExact0, 1e-6)

        val t100 = 100 // 1.000s frame index
        val centerSample100 = 160 * t100 + 256 // 16256
        val mExact100 = (centerSample100 - 200.0) / 320.0
        assertEquals(50.175, mExact100, 1e-6)
    }

    @Test
    fun testResolveOverlapsForwardPreservesWordStartsAndMidLinePauses() {
        val rawWords = listOf(
            WordTiming(text = "You ", begin = 1.000, end = 1.420, confidence = 0.90f),
            WordTiming(text = "said ", begin = 1.400, end = 1.850, confidence = 0.88f),
            WordTiming(text = "sky", begin = 2.200, end = 3.100, confidence = 0.92f)
        )
        val resolved = WordSpacesAndSyllables.resolveOverlapsForward(rawWords, duration = 4.000)

        assertEquals(1.000, resolved[0].begin, 1e-3)
        assertEquals(1.400, resolved[0].end, 1e-3)
        assertEquals(1.400, resolved[1].begin, 1e-3)
        assertEquals(1.850, resolved[1].end, 1e-3)
        assertEquals(2.200, resolved[2].begin, 1e-3)
        assertEquals(3.100, resolved[2].end, 1e-3)
        assertFalse(resolved[0].needsReview)
    }

    @Test
    fun testSustainedEndRefinementAcrossInternalShaddaDipAndEdgeBounds() {
        // Phase 3 & Phase 7 Test:
        // Simulate a word ("أُحِبُّكِ", initially [0.25s .. 0.70s]) that has:
        //   1. An internal 3-frame geminate Shadda stop dip around 0.42s..0.48s
        //   2. A sustained final vowel continuing from 0.50s all the way to 1.32s before silence at 1.33s..2.00s.
        // Verify that VocalOnsetSnapper.snapAndClampLines does NOT break early at the 0.45s internal dip
        // and instead extends the word end to the true acoustic release around 1.32s!
        val sampleRate = 44100
        val frameDur = StftProcessor.HOP_LENGTH.toDouble() / sampleRate.toDouble() // ~0.02322s
        val rms = FloatArray(120) { f ->
            val sec = f * frameDur
            when {
                sec < 0.24 -> 0.001f
                sec in 0.42..0.48 -> 0.010f // Internal Shadda stop closure dip (< 18% of 0.20f peak)
                sec <= 1.32 -> 0.200f       // Active sustained vowel hold up to 1.32s
                else -> 0.001f              // True post-word silence
            }
        }
        val analysis = SpectralFluxAnalysis(
            novelty = FloatArray(120) { 0.1f },
            rms = rms,
            onsetsSeconds = doubleArrayOf(0.250)
        )
        val line = LyricLine(
            id = "shadda_sustain_line",
            text = "أُحِبُّكِ",
            agentId = "v1",
            words = listOf(WordTiming("أُحِبُّكِ", begin = 0.250, end = 0.720, confidence = 0.90f))
        ).reconcile()

        val refined = VocalOnsetSnapper.snapAndClampLines(
            lines = listOf(line),
            analysis = analysis,
            sampleRate = sampleRate,
            hasArabicMaddPredicate = BilingualScriptAndNormalizer::hasArabicMaddOrMelisma
        )
        val refinedWord = refined[0].words!![0]
        assertEquals(0.250, refinedWord.begin, 0.03)
        assertTrue(
            "Expected sustained word end near 1.32s (not truncated at 0.42s Shadda dip or 0.72s initial estimate), got ${refinedWord.end}",
            refinedWord.end in 1.25..1.38
        )

        // Also verify edge-of-window ceiling clamping when wStart = 429 and maxLocalFrame = 435
        val maxLocalFrame = 435
        val wStart = 429
        val minCeil = min(wStart + 8, maxLocalFrame)
        val safeCeil = 432.coerceIn(minCeil, maxLocalFrame)
        assertEquals(435, safeCeil)
    }

    @Test
    fun testStage4SnapperAndRepeatedChorusPreserveMultiVocalistOverlaps() {
        val v1Line = LyricLine(
            id = "v1_chorus_1",
            text = "حبيبي يا نور العين",
            agentId = "v1",
            words = listOf(
                WordTiming("حبيبي ", 0.300, 0.820, confidence = 0.91f),
                WordTiming("يا ", 0.840, 1.120, confidence = 0.89f),
                WordTiming("نور ", 1.140, 1.520, confidence = 0.90f),
                WordTiming("العين", 1.540, 2.150, confidence = 0.92f)
            )
        ).reconcile()

        val v2Line = LyricLine(
            id = "v2_echo_1",
            text = "يا نور العين",
            agentId = "v2",
            words = listOf(
                WordTiming("يا ", 1.450, 1.780, confidence = 0.87f),
                WordTiming("نور ", 1.800, 2.250, confidence = 0.88f),
                WordTiming("العين", 2.270, 3.100, confidence = 0.90f)
            )
        ).reconcile()

        val v1Rep2 = v1Line.copy(
            id = "v1_chorus_2",
            words = listOf(
                WordTiming("حبيبي ", 5.300, 5.820, confidence = 0.91f),
                WordTiming("يا ", 5.840, 6.120, confidence = 0.89f),
                WordTiming("نور ", 6.140, 6.520, confidence = 0.90f),
                WordTiming("العين", 6.540, 7.250, confidence = 0.92f)
            )
        ).reconcile()

        val engine = BilingualForcedAlignmentEngine()
        val chorusIndices = engine.detectRepeatedChorusLineIndices(listOf(v1Line, v2Line, v1Rep2))
        assertTrue(chorusIndices.contains(0))
        assertTrue(chorusIndices.contains(2))

        val dummyRms = FloatArray(400) { 0.15f }
        val analysis = SpectralFluxAnalysis(
            novelty = FloatArray(400) { 0.1f },
            rms = dummyRms,
            onsetsSeconds = doubleArrayOf(0.300, 0.840, 1.140, 1.450, 1.540, 1.800, 2.270)
        )
        val snapped = VocalOnsetSnapper.snapAndClampLines(
            lines = listOf(v1Line, v2Line, v1Rep2),
            analysis = analysis,
            sampleRate = 44100,
            hasArabicMaddPredicate = BilingualScriptAndNormalizer::hasArabicMaddOrMelisma
        )
        val snappedV1End = snapped[0].mainBounds()!!.end
        val snappedV2Begin = snapped[1].mainBounds()!!.begin
        assertTrue("Stage 4 must preserve v1 chorus hold past v2's entry (v1End=$snappedV1End, v2Begin=$snappedV2Begin)", snappedV1End > 2.00)
        assertTrue(snappedV1End > snappedV2Begin)
    }

    @Test
    fun testStftAndIstftPerfectReconstruction() {
        val sampleRate = 44100
        val signal = FloatArray(sampleRate) { i ->
            (0.6 * sin(2.0 * PI * 440.0 * i / sampleRate)).toFloat()
        }
        val spec = StftProcessor.stft(signal, center = true, normalized = true)
        val reconstructed = StftProcessor.istft(spec, signal.size, normalized = true)

        var maxErr = 0f
        for (i in 2048 until signal.size - 2048) {
            val err = abs(signal[i] - reconstructed[i])
            if (err > maxErr) maxErr = err
        }
        assertTrue("STFT->iSTFT reconstruction error too high: $maxErr", maxErr < 1e-4f)
    }

    @Test
    fun testCrossLineSustainedVowelContinuationAndFirstWordTransitionDiagnostics() {
        // Part B (Requirements 5, 6, 7, 8, 9) & Part C (Requirement 10) Regression Test:
        // Reproduces Failure A & Failure B on an Egyptian Arabic line transition:
        //   Line 0: "أنا كل ما أقول التوبة" (nominal LRC [0.20 .. 2.15s], but singer holds "التوبة" until 2.92s!)
        //   Line 1: "ترميني المقادير يا عيني" (nominal LRC [2.15 .. 5.10s], singer attacks "ترميني" at 2.98s!)
        val sr = 16000
        val durationSec = 5.60
        val vocalMono16k = FloatArray((durationSec * sr).toInt())

        // Synthesize voiced harmonic formant signal for "التوبة" held from 1.72s to 2.92s,
        // breath pause [2.92s .. 2.97s], and sharp consonant+vowel attack for "ترميني" at 2.98s..3.58s
        for (i in vocalMono16k.indices) {
            val t = i.toDouble() / sr.toDouble()
            val env = when {
                t in 0.24..1.68 -> 0.22
                t in 1.72..2.92 -> 0.28 * (1.0 + 0.12 * sin(2.0 * PI * 5.5 * t)) // Sustained "التوبة" with vibrato past 2.15s!
                t in 2.92..2.97 -> 0.002 // Inter-phrase breath dip
                t in 2.98..3.58 -> 0.30 // True onset of "ترميني" at 2.98s
                t in 3.62..5.40 -> 0.24
                else -> 0.001
            }
            val f1 = sin(2.0 * PI * 480.0 * t)
            val f2 = 0.6 * sin(2.0 * PI * 1450.0 * t)
            val burst = if (t in 2.980..3.015) 0.35 * sin(2.0 * PI * 3200.0 * t) else 0.0
            vocalMono16k[i] = (env * (f1 + f2) + burst).toFloat()
        }

        val engine = BilingualForcedAlignmentEngine()
        val ceiling = engine.findVerifiedNextLineVocalCeiling(
            stemMono16k = vocalMono16k,
            currentLineBeginSec = 0.20,
            nominalNextLineBeginSec = 2.15,
            songDurationSeconds = durationSec,
            maxExtensionSec = 2.60
        )
        assertTrue(
            "findVerifiedNextLineVocalCeiling must not truncate at nominal LRC 2.15s while singer holds التوبة to 2.92s (got $ceiling)",
            ceiling >= 2.88
        )

        // Simulate initial lines where Line 0 was truncated at 2.18s and Line 1 started too early at 2.20s
        val initialLine0 = LyricLine(
            id = "eg_line_0",
            text = "أنا كل ما أقول التوبة",
            agentId = "v1",
            begin = 0.20,
            end = 2.18,
            words = listOf(
                WordTiming("أنا ", 0.24, 0.56, confidence = 0.90f),
                WordTiming("كل ", 0.59, 0.88, confidence = 0.90f),
                WordTiming("ما ", 0.90, 1.15, confidence = 0.90f),
                WordTiming("أقول ", 1.18, 1.68, confidence = 0.90f),
                WordTiming("التوبة", 1.72, 2.18, confidence = 0.85f)
            )
        ).reconcile()

        val initialLine1 = LyricLine(
            id = "eg_line_1",
            text = "ترميني المقادير يا عيني",
            agentId = "v1",
            begin = 2.15,
            end = 5.30,
            words = listOf(
                WordTiming("ترميني ", 2.20, 3.58, confidence = 0.82f),
                WordTiming("المقادير ", 3.62, 4.32, confidence = 0.90f),
                WordTiming("يا ", 4.35, 4.62, confidence = 0.90f),
                WordTiming("عيني", 4.65, 5.30, confidence = 0.91f)
            )
        ).reconcile()

        val rawLrcInputLines = listOf(
            initialLine0.copy(words = null, begin = 0.20, end = 2.15),
            initialLine1.copy(words = null, begin = 2.15, end = 5.10)
        )

        val (reconciled, diagnostics) = engine.reconcileCrossLineTransitionsAndBuildDiagnostics(
            initialAlignedLines = listOf(initialLine0, initialLine1),
            originalInputLines = rawLrcInputLines,
            vocalMono16k = vocalMono16k,
            originalMono16k = vocalMono16k,
            songDurationSeconds = durationSec,
            config = ForcedAlignmentConfig()
        )

        val refinedPrevLast = reconciled[0].words!!.last()
        val refinedNextFirst = reconciled[1].words!!.first()

        assertTrue(
            "Failure A Fix: التوبة end must extend past 2.15s LRC break to near 2.92s (got ${refinedPrevLast.end})",
            refinedPrevLast.end in 2.84..2.98
        )
        assertTrue(
            "Failure B Fix: ترميني begin must align to its true onset near 2.98s, not 2.15s (got ${refinedNextFirst.begin})",
            refinedNextFirst.begin in 2.93..3.04
        )
        assertTrue(
            "Single-singer transition must remain monotonic (prevEnd=${refinedPrevLast.end} <= nextBegin=${refinedNextFirst.begin})",
            refinedPrevLast.end <= refinedNextFirst.begin
        )
        assertEquals(1, diagnostics.size)
        assertTrue(diagnostics[0].carriedAcrossLineBreak)
        assertEquals("CROSS_LINE_VOWEL_CARRY_RECONCILED", diagnostics[0].appliedConstraint)
    }

    @Test
    fun testQuietFinalConsonantPreservationAndValidAudioBounds() {
        val sampleRate = 44100
        val frameDur = StftProcessor.HOP_LENGTH.toDouble() / sampleRate.toDouble() // ~23.2ms
        // Word "صوتك" [0.25s .. 0.85s]: vowel core [0.25 .. 0.72s] at 0.22f RMS, quiet final 'ك' release [0.72 .. 0.84s] at 0.025f RMS (~11.3% of peak)
        val rms = FloatArray(70) { f ->
            val sec = f * frameDur
            when {
                sec < 0.24 -> 0.001f
                sec in 0.24..0.72 -> 0.220f
                sec in 0.72..0.84 -> 0.025f // Quiet final consonant coda (> 9.5% floor, < old 15% floor)
                else -> 0.001f
            }
        }
        val analysis = SpectralFluxAnalysis(
            novelty = FloatArray(70) { 0.1f },
            rms = rms,
            onsetsSeconds = doubleArrayOf(0.250)
        )
        val line = LyricLine(
            id = "quiet_coda_line",
            text = "صوتك",
            agentId = "v1",
            words = listOf(WordTiming("صوتك", begin = 0.250, end = 0.840, confidence = 0.90f))
        ).reconcile()

        val snapped = VocalOnsetSnapper.snapAndClampLines(
            lines = listOf(line),
            analysis = analysis,
            sampleRate = sampleRate,
            hasArabicMaddPredicate = BilingualScriptAndNormalizer::hasArabicMaddOrMelisma
        )
        val w = snapped[0].words!![0]
        assertTrue(
            "Quiet final consonant coda must be preserved near 0.84s (got ${w.end})",
            w.end >= 0.80
        )
    }

    @Test
    fun testZeroCopyStereoToMonoResamplingAndSpectralOnsetParity() {
        val sampleRate = 44100
        val left = FloatArray(sampleRate) { i -> (0.5 * sin(2.0 * PI * 440.0 * i / sampleRate)).toFloat() }
        val right = FloatArray(sampleRate) { i -> (0.3 * sin(2.0 * PI * 880.0 * i / sampleRate)).toFloat() }
        val channels = arrayOf(left, right)

        val mono44k = SpectralOnsetDetector.mixToMono(channels)
        val ref16k = AudioCodec.resampleSinc(mono44k, 44100, 16000)
        val direct16k = AudioCodec.mixAndResampleToMono(channels, 44100, 16000)
        assertEquals(ref16k.size, direct16k.size)
        for (i in ref16k.indices) {
            assertEquals(ref16k[i], direct16k[i], 1e-5f)
        }

        val monoAnalysis = SpectralOnsetDetector.analyzeVocalStem(mono44k)
        val channelAnalysis = SpectralOnsetDetector.analyzeVocalChannels(channels)
        assertEquals(monoAnalysis.rms.size, channelAnalysis.rms.size)
        for (i in monoAnalysis.rms.indices) {
            assertEquals(monoAnalysis.rms[i], channelAnalysis.rms[i], 1e-5f)
            assertEquals(monoAnalysis.novelty[i], channelAnalysis.novelty[i], 1e-5f)
        }

        // Verify zero-copy fast path when stereo array shares a single mono FloatArray reference
        val shared = arrayOf(mono44k, mono44k)
        assertTrue(SpectralOnsetDetector.mixToMono(shared) === mono44k)
    }

    @Test
    fun testLamePrimingHeaderParser() {
        val bytes = ByteArray(512)
        bytes[0] = 0xFF.toByte()
        bytes[1] = 0xFB.toByte()
        bytes[2] = 0x90.toByte()
        bytes[3] = 0x00.toByte()

        val tagOffset = 0x24
        "Xing".toByteArray().copyInto(bytes, tagOffset)
        val lameOffset = tagOffset + 0x78
        val encoderDelay = 576
        bytes[lameOffset + 0x15] = (encoderDelay ushr 4).toByte()
        bytes[lameOffset + 0x16] = ((encoderDelay and 0x0F) shl 4).toByte()

        val priming = LamePrimingParser.parseLamePriming(bytes)
        assertEquals(576 + 528, priming.samples)
        assertEquals(44100, priming.sampleRate)
    }
}
