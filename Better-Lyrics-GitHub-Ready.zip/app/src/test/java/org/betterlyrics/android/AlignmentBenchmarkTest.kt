package org.betterlyrics.android

import org.betterlyrics.android.alignment.AlignmentBenchmark
import org.betterlyrics.android.alignment.AlignmentBenchmarkCase
import org.betterlyrics.android.alignment.AlignmentBenchmarkDataset
import org.betterlyrics.android.alignment.AlignmentBenchmarkWord
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AlignmentBenchmarkTest {

    @Test
    fun calculatesBoundaryErrorsPercentilesAndCoverageAgainstReference() {
        val dataset = AlignmentBenchmarkDataset(
            description = "Synthetic regression only; not a real-song accuracy claim.",
            cases = listOf(
                AlignmentBenchmarkCase(
                    caseId = "synthetic-continuous-phrase",
                    tags = setOf("egyptian", "sustained"),
                    reference = listOf(
                        AlignmentBenchmarkWord("w1", "يا", 1.0, 1.8, tags = setOf("arabic")),
                        AlignmentBenchmarkWord("w2", "hello", 1.8, 2.2, tags = setOf("english"))
                    ),
                    prediction = listOf(
                        AlignmentBenchmarkWord("w1", "يا", 1.1, 1.9, confidence = 0.8f, tags = setOf("arabic")),
                        AlignmentBenchmarkWord("w2", "hello", 1.75, 2.3, confidence = 0.7f, tags = setOf("english"))
                    )
                )
            )
        )

        val report = AlignmentBenchmark.evaluate(dataset)
        assertEquals(2, report.overall.referenceWords)
        assertEquals(2, report.overall.matchedWords)
        assertEquals(1.0, report.overall.wordCoverage!!, 0.0)
        assertEquals(0.0875, report.overall.meanAbsoluteTimingErrorSeconds!!, 1e-8)
        assertEquals(0.075, report.overall.meanStartBoundaryErrorSeconds!!, 1e-8)
        assertEquals(0.1, report.overall.meanEndBoundaryErrorSeconds!!, 1e-8)
        assertTrue(report.byTag.containsKey("arabic"))
        assertTrue(report.byTag.containsKey("english"))
        assertTrue(report.byTag.containsKey("egyptian"))
        assertNull("Calibration is withheld with fewer than 20 confident samples.", report.overall.confidenceExpectedCalibrationError)
    }

    @Test
    fun countsMissingDuplicateInvalidAndUnexpectedPredictions() {
        val dataset = AlignmentBenchmarkDataset(
            cases = listOf(
                AlignmentBenchmarkCase(
                    caseId = "synthetic-missing-and-duplicate",
                    reference = listOf(
                        AlignmentBenchmarkWord("a", "word", 0.0, 0.4),
                        AlignmentBenchmarkWord("b", "word", 0.4, 0.8)
                    ),
                    prediction = listOf(
                        AlignmentBenchmarkWord("a", "word", 0.2, 0.1), // invalid end-before-start
                        AlignmentBenchmarkWord("a", "word", 0.0, 0.3), // duplicate occurrence
                        AlignmentBenchmarkWord("unknown", "extra", 1.0, 1.2)
                    )
                )
            )
        )

        val metrics = AlignmentBenchmark.evaluate(dataset).overall
        assertEquals(2, metrics.referenceWords)
        assertEquals(0, metrics.matchedWords)
        assertEquals(2, metrics.missedWords)
        assertEquals(1, metrics.extraWords)
        assertEquals(1, metrics.duplicateWords)
        assertEquals(1, metrics.invalidTimings)
        assertEquals(0.0, metrics.wordCoverage!!, 0.0)
    }

    @Test
    fun ignoresIntentionalReferenceOverlapsAndCountsPredictedUnintendedOverlap() {
        val dataset = AlignmentBenchmarkDataset(
            cases = listOf(
                AlignmentBenchmarkCase(
                    caseId = "synthetic-overlap",
                    reference = listOf(
                        AlignmentBenchmarkWord("lead", "يا", 0.0, 1.0, singerId = "v1"),
                        AlignmentBenchmarkWord("backing", "آه", 0.6, 1.2, singerId = "v2"),
                        AlignmentBenchmarkWord("next", "ليل", 1.2, 1.6, singerId = "v1")
                    ),
                    prediction = listOf(
                        AlignmentBenchmarkWord("lead", "يا", 0.0, 1.3, singerId = "v1"),
                        AlignmentBenchmarkWord("backing", "آه", 0.6, 1.2, singerId = "v2"),
                        AlignmentBenchmarkWord("next", "ليل", 1.2, 1.6, singerId = "v1")
                    )
                )
            )
        )

        assertEquals(1, AlignmentBenchmark.evaluate(dataset).overall.overlapErrors)
    }

    @Test
    fun datasetJsonRoundTripsWithoutChangingManualReferenceTimes() {
        val dataset = AlignmentBenchmarkDataset(
            description = "manually verified reference placeholder",
            cases = listOf(
                AlignmentBenchmarkCase(
                    caseId = "future-real-recording-id",
                    tags = setOf("mixed", "rap", "repeated-chorus", "multiple-singers", "backing-vocals"),
                    reference = listOf(AlignmentBenchmarkWord("chorus-v2-1", "أيوه", 12.345, 12.789, "v2")),
                    prediction = emptyList()
                )
            )
        )

        val decoded = AlignmentBenchmark.parseDataset(AlignmentBenchmark.encodeDataset(dataset))
        assertEquals(dataset, decoded)
        assertFalse(decoded.cases.single().reference.isEmpty())
    }

    // ============================================================
    // REGRESSION TESTS FOR FIXED BUGS
    // ============================================================

    @Test
    fun crossCaseIdCollisionDoesNotCorruptMetrics() {
        // Two cases using identical word IDs must not corrupt metrics.
        // Case 1: "w1", "w2"  |  Case 2: "w1", "w2" (same IDs, different case)
        val dataset = AlignmentBenchmarkDataset(
            cases = listOf(
                AlignmentBenchmarkCase(
                    caseId = "case-1",
                    reference = listOf(
                        AlignmentBenchmarkWord("w1", "word", 0.0, 0.4),
                        AlignmentBenchmarkWord("w2", "word", 0.4, 0.8)
                    ),
                    prediction = listOf(
                        AlignmentBenchmarkWord("w1", "word", 0.05, 0.45),
                        AlignmentBenchmarkWord("w2", "word", 0.45, 0.85)
                    )
                ),
                AlignmentBenchmarkCase(
                    caseId = "case-2",
                    reference = listOf(
                        AlignmentBenchmarkWord("w1", "word", 1.0, 1.4),
                        AlignmentBenchmarkWord("w2", "word", 1.4, 1.8)
                    ),
                    prediction = listOf(
                        AlignmentBenchmarkWord("w1", "word", 1.05, 1.45),
                        AlignmentBenchmarkWord("w2", "word", 1.45, 1.85)
                    )
                )
            )
        )

        val report = AlignmentBenchmark.evaluate(dataset)
        // Each case has 2 reference words, both matched = 4 total
        assertEquals(4, report.overall.referenceWords)
        assertEquals(4, report.overall.matchedWords)
        assertEquals(0, report.overall.missedWords)
        assertEquals(0, report.overall.extraWords)
        assertEquals(0, report.overall.duplicateWords)
        assertEquals(1.0, report.overall.wordCoverage!!, 0.0)
        // Timing errors: 0.05 each for 4 words = 0.2 total / 8 boundaries = 0.025
        assertEquals(0.025, report.overall.meanAbsoluteTimingErrorSeconds!!, 1e-8)
    }

    @Test
    fun repeatedChorusWordsWithinCaseRequireDistinctIds() {
        // Repeated chorus words in same case must use distinct IDs.
        // If they reuse IDs, they should be counted as duplicates.
        val dataset = AlignmentBenchmarkDataset(
            cases = listOf(
                AlignmentBenchmarkCase(
                    caseId = "repeated-chorus",
                    reference = listOf(
                        AlignmentBenchmarkWord("chorus-1", "يا", 0.0, 0.5),
                        AlignmentBenchmarkWord("chorus-2", "يا", 2.0, 2.5)  // distinct ID for repeated word
                    ),
                    prediction = listOf(
                        AlignmentBenchmarkWord("chorus-1", "يا", 0.05, 0.55),
                        AlignmentBenchmarkWord("chorus-2", "يا", 2.05, 2.55)
                    )
                )
            )
        )

        val report = AlignmentBenchmark.evaluate(dataset)
        assertEquals(2, report.overall.referenceWords)
        assertEquals(2, report.overall.matchedWords)
        assertEquals(0, report.overall.missedWords)
        assertEquals(0, report.overall.duplicateWords)
        assertEquals(1.0, report.overall.wordCoverage!!, 0.0)
    }

    @Test
    fun duplicatePredictionsCountedCorrectly() {
        val dataset = AlignmentBenchmarkDataset(
            cases = listOf(
                AlignmentBenchmarkCase(
                    caseId = "duplicates",
                    reference = listOf(
                        AlignmentBenchmarkWord("a", "word", 0.0, 0.4),
                        AlignmentBenchmarkWord("b", "word", 0.4, 0.8)
                    ),
                    prediction = listOf(
                        AlignmentBenchmarkWord("a", "word", 0.0, 0.4),   // correct
                        AlignmentBenchmarkWord("a", "word", 0.1, 0.5),   // duplicate ID
                        AlignmentBenchmarkWord("b", "word", 0.4, 0.8)    // correct
                    )
                )
            )
        )

        val metrics = AlignmentBenchmark.evaluate(dataset).overall
        assertEquals(2, metrics.referenceWords)
        assertEquals(2, metrics.matchedWords)  // only unique IDs matched
        assertEquals(0, metrics.missedWords)
        assertEquals(0, metrics.extraWords)
        assertEquals(1, metrics.duplicateWords)  // one duplicate occurrence of "a"
        assertEquals(1.0, metrics.wordCoverage!!, 0.0)
    }

    @Test
    fun missingPredictionsCountedCorrectly() {
        val dataset = AlignmentBenchmarkDataset(
            cases = listOf(
                AlignmentBenchmarkCase(
                    caseId = "missing",
                    reference = listOf(
                        AlignmentBenchmarkWord("a", "word", 0.0, 0.4),
                        AlignmentBenchmarkWord("b", "word", 0.4, 0.8),
                        AlignmentBenchmarkWord("c", "word", 0.8, 1.2)
                    ),
                    prediction = listOf(
                        AlignmentBenchmarkWord("a", "word", 0.0, 0.4),
                        AlignmentBenchmarkWord("b", "word", 0.4, 0.8)
                        // "c" is missing
                    )
                )
            )
        )

        val metrics = AlignmentBenchmark.evaluate(dataset).overall
        assertEquals(3, metrics.referenceWords)
        assertEquals(2, metrics.matchedWords)
        assertEquals(1, metrics.missedWords)
        assertEquals(0, metrics.extraWords)
        assertEquals(0, metrics.duplicateWords)
        assertEquals(2.0 / 3.0, metrics.wordCoverage!!, 1e-8)
    }

    @Test
    fun incorrectPredictionsCountedAsExtraAndMissed() {
        val dataset = AlignmentBenchmarkDataset(
            cases = listOf(
                AlignmentBenchmarkCase(
                    caseId = "incorrect",
                    reference = listOf(
                        AlignmentBenchmarkWord("a", "word", 0.0, 0.4)
                    ),
                    prediction = listOf(
                        AlignmentBenchmarkWord("wrong", "word", 0.0, 0.4)  // wrong ID
                    )
                )
            )
        )

        val metrics = AlignmentBenchmark.evaluate(dataset).overall
        assertEquals(1, metrics.referenceWords)
        assertEquals(0, metrics.matchedWords)
        assertEquals(1, metrics.missedWords)   // "a" not predicted
        assertEquals(1, metrics.extraWords)    // "wrong" not in reference
        assertEquals(0, metrics.duplicateWords)
        assertEquals(0.0, metrics.wordCoverage!!, 0.0)
    }

    @Test
    fun perTagOverlapCalculationsAreFilteredCorrectly() {
        // Case with both arabic and english words, different singers.
        // Overlap error should only count for the tagged singer's words.
        val dataset = AlignmentBenchmarkDataset(
            cases = listOf(
                AlignmentBenchmarkCase(
                    caseId = "tagged-overlap",
                    tags = setOf("mixed"),
                    reference = listOf(
                        AlignmentBenchmarkWord("ar1", "يا", 0.0, 1.0, singerId = "v1", tags = setOf("arabic")),
                        AlignmentBenchmarkWord("ar2", "لي", 1.0, 1.5, singerId = "v1", tags = setOf("arabic")),
                        AlignmentBenchmarkWord("en1", "hello", 0.5, 1.2, singerId = "v2", tags = setOf("english")),  // overlaps with ar1 intentionally (different singer)
                        AlignmentBenchmarkWord("en2", "world", 1.2, 1.8, singerId = "v2", tags = setOf("english"))
                    ),
                    prediction = listOf(
                        AlignmentBenchmarkWord("ar1", "يا", 0.0, 1.3, singerId = "v1", tags = setOf("arabic")),  // extends past ar2 -> unintended overlap
                        AlignmentBenchmarkWord("ar2", "لي", 1.0, 1.5, singerId = "v1", tags = setOf("arabic")),
                        AlignmentBenchmarkWord("en1", "hello", 0.5, 1.2, singerId = "v2", tags = setOf("english")),
                        AlignmentBenchmarkWord("en2", "world", 1.2, 1.8, singerId = "v2", tags = setOf("english"))
                    )
                )
            )
        )

        val report = AlignmentBenchmark.evaluate(dataset)

        // Overall: v1 has unintended overlap (ar1 extends past ar2)
        assertEquals(1, report.overall.overlapErrors)

        // Arabic tag: only evaluates v1 words (ar1, ar2), same unintended overlap
        val arabicMetrics = report.byTag["arabic"]!!
        assertEquals(1, arabicMetrics.overlapErrors)

        // English tag: only evaluates v2 words (en1, en2), no unintended overlap
        val englishMetrics = report.byTag["english"]!!
        assertEquals(0, englishMetrics.overlapErrors)
    }

    @Test
    fun intentionalSimultaneousSingingDifferentSingersNotPenalized() {
        // Different singers overlapping in reference is intentional.
        // Prediction matching that should not count as error.
        val dataset = AlignmentBenchmarkDataset(
            cases = listOf(
                AlignmentBenchmarkCase(
                    caseId = "intentional-overlap",
                    reference = listOf(
                        AlignmentBenchmarkWord("lead", "يا", 0.0, 1.0, singerId = "v1"),
                        AlignmentBenchmarkWord("backing", "آه", 0.5, 1.2, singerId = "v2"),  // intentional overlap
                        AlignmentBenchmarkWord("next", "ليل", 1.2, 1.8, singerId = "v1")
                    ),
                    prediction = listOf(
                        AlignmentBenchmarkWord("lead", "يا", 0.0, 1.0, singerId = "v1"),
                        AlignmentBenchmarkWord("backing", "آه", 0.5, 1.2, singerId = "v2"),
                        AlignmentBenchmarkWord("next", "ليل", 1.2, 1.8, singerId = "v1")
                    )
                )
            )
        )

        assertEquals(0, AlignmentBenchmark.evaluate(dataset).overall.overlapErrors)
    }

    @Test
    fun unintendedOverlapSameSingerIsCounted() {
        // Same singer overlapping in prediction when reference has no overlap = error.
        val dataset = AlignmentBenchmarkDataset(
            cases = listOf(
                AlignmentBenchmarkCase(
                    caseId = "unintended-overlap",
                    reference = listOf(
                        AlignmentBenchmarkWord("w1", "word", 0.0, 0.5, singerId = "v1"),
                        AlignmentBenchmarkWord("w2", "word", 0.6, 1.0, singerId = "v1")  // gap, no overlap
                    ),
                    prediction = listOf(
                        AlignmentBenchmarkWord("w1", "word", 0.0, 0.7, singerId = "v1"),  // extends into w2
                        AlignmentBenchmarkWord("w2", "word", 0.6, 1.0, singerId = "v1")
                    )
                )
            )
        )

        assertEquals(1, AlignmentBenchmark.evaluate(dataset).overall.overlapErrors)
    }

    @Test
    fun perTagMetricsOnlyIncludeRelevantCases() {
        // Case 1: arabic only, Case 2: english only
        // Per-tag metrics should only include the relevant case
        val dataset = AlignmentBenchmarkDataset(
            cases = listOf(
                AlignmentBenchmarkCase(
                    caseId = "arabic-case",
                    tags = setOf("arabic"),
                    reference = listOf(
                        AlignmentBenchmarkWord("ar1", "يا", 0.0, 0.5, tags = setOf("arabic"))
                    ),
                    prediction = listOf(
                        AlignmentBenchmarkWord("ar1", "يا", 0.1, 0.6, tags = setOf("arabic"))
                    )
                ),
                AlignmentBenchmarkCase(
                    caseId = "english-case",
                    tags = setOf("english"),
                    reference = listOf(
                        AlignmentBenchmarkWord("en1", "hello", 0.0, 0.5, tags = setOf("english"))
                    ),
                    prediction = listOf(
                        AlignmentBenchmarkWord("en1", "hello", 0.2, 0.7, tags = setOf("english"))
                    )
                )
            )
        )

        val report = AlignmentBenchmark.evaluate(dataset)

        // Overall: both cases
        assertEquals(2, report.overall.referenceWords)
        assertEquals(2, report.overall.matchedWords)

        // Arabic tag: only arabic-case
        val arabicMetrics = report.byTag["arabic"]!!
        assertEquals(1, arabicMetrics.referenceWords)
        assertEquals(1, arabicMetrics.matchedWords)

        // English tag: only english-case
        val englishMetrics = report.byTag["english"]!!
        assertEquals(1, englishMetrics.referenceWords)
        assertEquals(1, englishMetrics.matchedWords)
    }

    @Test
    fun perTagOverlapRespectsOnlyTagFilter() {
        // Case with both arabic and english words, v1 sings both.
        // Arabic overlap should only consider arabic words.
        // English overlap should only consider english words.
        val dataset = AlignmentBenchmarkDataset(
            cases = listOf(
                AlignmentBenchmarkCase(
                    caseId = "mixed-overlap",
                    reference = listOf(
                        AlignmentBenchmarkWord("ar1", "يا", 0.0, 0.8, singerId = "v1", tags = setOf("arabic")),
                        AlignmentBenchmarkWord("ar2", "لي", 0.8, 1.5, singerId = "v1", tags = setOf("arabic")),
                        AlignmentBenchmarkWord("en1", "hello", 0.5, 1.2, singerId = "v1", tags = setOf("english")),  // overlaps ar1 in ref but different tag
                        AlignmentBenchmarkWord("en2", "world", 1.2, 1.8, singerId = "v1", tags = setOf("english"))
                    ),
                    prediction = listOf(
                        AlignmentBenchmarkWord("ar1", "يا", 0.0, 1.0, singerId = "v1", tags = setOf("arabic")),  // extends into ar2
                        AlignmentBenchmarkWord("ar2", "لي", 0.8, 1.5, singerId = "v1", tags = setOf("arabic")),
                        AlignmentBenchmarkWord("en1", "hello", 0.5, 1.2, singerId = "v1", tags = setOf("english")),
                        AlignmentBenchmarkWord("en2", "world", 1.2, 1.8, singerId = "v1", tags = setOf("english"))
                    )
                )
            )
        )

        val report = AlignmentBenchmark.evaluate(dataset)

        // Overall: v1 has unintended overlap (ar1 extends into ar2) = 1 error
        assertEquals(1, report.overall.overlapErrors)

        // Arabic tag: sees ar1, ar2 (overlap) + en1, en2 (no overlap) 
        // But wait - the per-tag filter should filter by word tags too!
        // Let's check: ar1 has tag "arabic", en1 has tag "english"
        // For "arabic" tag: filtered words are ar1, ar2 (en1, en2 filtered out)
        //   -> v1 words: ar1 [0, 1.0], ar2 [0.8, 1.5] -> overlap = 1
        // For "english" tag: filtered words are en1, en2 (ar1, ar2 filtered out)
        //   -> v1 words: en1 [0.5, 1.2], en2 [1.2, 1.8] -> no overlap = 0

        val arabicMetrics = report.byTag["arabic"]!!
        assertEquals(1, arabicMetrics.overlapErrors)

        val englishMetrics = report.byTag["english"]!!
        assertEquals(0, englishMetrics.overlapErrors)
    }
}
