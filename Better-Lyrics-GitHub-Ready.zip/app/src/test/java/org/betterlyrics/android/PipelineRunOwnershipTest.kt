package org.betterlyrics.android

import org.betterlyrics.android.service.PipelineRunOwnership
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PipelineRunOwnershipTest {

    @Test
    fun staleCancelledRunCannotReleaseReplacementRunsResources() {
        val ownership = PipelineRunOwnership()
        val released = mutableListOf<Long>()
        val oldRun = ownership.beginRun()
        val replacementRun = ownership.beginRun()

        if (ownership.finishRun(oldRun)) released += oldRun
        assertTrue(ownership.isCurrent(replacementRun))
        assertTrue(ownership.finishRun(replacementRun))
        if (ownership.finishRun(replacementRun)) released += replacementRun

        assertEquals(listOf(replacementRun), released)
        assertFalse(ownership.isCurrent(replacementRun))
    }

    @Test
    fun onlyCurrentRunCanFinalizeOrReportForegroundStartupFailure() {
        val ownership = PipelineRunOwnership()
        val sideEffects = mutableListOf<String>()
        val staleRun = ownership.beginRun()
        val currentRun = ownership.beginRun()

        assertFalse(ownership.failRun(staleRun) { sideEffects += "stale failure" })
        assertTrue(ownership.isCurrent(currentRun))
        assertTrue(ownership.failRun(currentRun) { sideEffects += "release resources and report failure" })

        assertEquals(listOf("release resources and report failure"), sideEffects)
        assertFalse(ownership.isCurrent(currentRun))
        assertFalse(ownership.finishRun(currentRun))
    }

    @Test
    fun currentRunCleanupIsExactlyOnce() {
        val ownership = PipelineRunOwnership()
        val runId = ownership.beginRun()
        var cleanupCount = 0

        if (ownership.finishRun(runId)) cleanupCount++
        if (ownership.finishRun(runId)) cleanupCount++

        assertEquals(1, cleanupCount)
    }
}
