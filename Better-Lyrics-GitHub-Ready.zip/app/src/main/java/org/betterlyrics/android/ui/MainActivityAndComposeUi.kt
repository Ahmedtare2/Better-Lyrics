package org.betterlyrics.android.ui

import android.annotation.SuppressLint
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.net.Uri
import android.os.Bundle
import android.os.IBinder
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircleOutline
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SettingsSuggest
import androidx.compose.material.icons.filled.Web
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameMillis
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.webkit.WebViewAssetLoader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.betterlyrics.android.alignment.ArabicAlignmentBackend
import org.betterlyrics.android.alignment.BilingualScriptAndNormalizer
import org.betterlyrics.android.data.lyrics.AudioTagExtractor
import org.betterlyrics.android.data.lyrics.DurationMatchBadge
import org.betterlyrics.android.data.lyrics.LrcAndTextParser
import org.betterlyrics.android.data.lyrics.LrclibClient
import org.betterlyrics.android.data.lyrics.LyricsSearchPayload
import org.betterlyrics.android.data.lyrics.LyricsSearchQuery
import org.betterlyrics.android.data.lyrics.LyricsSearchResult
import org.betterlyrics.android.domain.ttml.Agent
import org.betterlyrics.android.domain.ttml.LyricLine
import org.betterlyrics.android.domain.ttml.ProjectMetadata
import org.betterlyrics.android.domain.ttml.TtmlFormatting
import org.betterlyrics.android.domain.ttml.TtmlValidation
import org.betterlyrics.android.domain.ttml.WordTiming
import org.betterlyrics.android.service.AlignmentForegroundService
import org.betterlyrics.android.service.ModelId
import org.betterlyrics.android.service.OfflineModelManager
import org.betterlyrics.android.service.PipelineJobRequest
import org.betterlyrics.android.service.PipelineStage
import org.betterlyrics.android.service.PipelineState
import java.io.File

// ================================================================================================
// 1. MAIN ACTIVITY & SERVICE BINDING
// ================================================================================================

class MainActivity : ComponentActivity() {

    private var boundService by mutableStateOf<AlignmentForegroundService?>(null)
    private lateinit var modelManager: OfflineModelManager

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            val binder = service as? AlignmentForegroundService.LocalBinder
            boundService = binder?.getService()
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            boundService = null
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        modelManager = OfflineModelManager(applicationContext)

        Intent(this, AlignmentForegroundService::class.java).also { intent ->
            startService(intent)
            bindService(intent, connection, Context.BIND_AUTO_CREATE)
        }

        setContent {
            val studioDarkScheme = darkColorScheme(
                primary = Color(0xFF7C4DFF),          // Electric Violet
                onPrimary = Color(0xFFF8FAFC),
                secondary = Color(0xFF00E5FF),        // Restrained Cyan
                onSecondary = Color(0xFF06101E),
                tertiary = Color(0xFFFF6D4D),         // Subtle Warm Recording/Timing Accent
                background = Color(0xFF080B16),       // Midnight Navy
                onBackground = Color(0xFFF8FAFC),
                surface = Color(0xFF12182F),          // Deep Indigo Studio Surface
                onSurface = Color(0xFFF8FAFC),
                surfaceVariant = Color(0xFF1A223D),   // Elevated Studio Card
                onSurfaceVariant = Color(0xFF94A3B8)
            )
            MaterialTheme(colorScheme = studioDarkScheme) {
                BetterLyricsApp(
                    service = boundService,
                    modelManager = modelManager
                )
            }
        }
    }

    override fun onDestroy() {
        runCatching { unbindService(connection) }
        super.onDestroy()
    }
}

// ================================================================================================
// 2. ROOT COMPOSABLE & STATE COORDINATION
// ================================================================================================

@Composable
fun BetterLyricsApp(
    service: AlignmentForegroundService?,
    modelManager: OfflineModelManager
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var selectedTab by remember { mutableIntStateOf(0) } // 0=Home, 1=Pipeline, 2=Preview, 3=Composer, 4=ONNX & XML
    var showLaunchSplash by remember { mutableStateOf(true) }
    var recentProjects by remember { mutableStateOf(RecentProjectsStore.loadRecentProjects(context)) }
    var pendingAudioThenLyrics by remember { mutableStateOf(false) }
    var selectedAudioUri by remember { mutableStateOf<Uri?>(null) }
    var audioFileName by remember { mutableStateOf("No audio file selected") }
    var metadata by remember {
        mutableStateOf(
            ProjectMetadata(
                title = "",
                artists = emptyList(),
                album = "",
                duration = 0.0,
                language = "ar"
            )
        )
    }

    var importedLines by remember { mutableStateOf<List<LyricLine>>(emptyList()) }
    var lyricsSourceLabel by remember { mutableStateOf("No lyrics loaded") }

    // Pipeline Configuration Options
    var demucsVariant by remember { mutableStateOf(ModelId.HTDEMUCS_FP16) }
    var arabicBackend by remember { mutableStateOf(ArabicAlignmentBackend.AUTO_CALIBRATED) }
    LaunchedEffect(Unit) {
        kotlinx.coroutines.delay(420)
        showLaunchSplash = false
    }
    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) {
            modelManager.extractBundledAssetsIfPresent()
            modelManager.refreshStatuses()
        }
    }
    var useHardwareAccel by remember { mutableStateOf(false) }
    var enableSyllableSplit by remember { mutableStateOf(false) }
    var autoExtractBgVocals by remember { mutableStateOf(true) }
    var snapToVocalOnsets by remember { mutableStateOf(true) }

    // LRCLIB Search Dialog State
    var showLrclibModal by remember { mutableStateOf(false) }

    val pipelineState by (service?.pipelineState ?: remember {
        kotlinx.coroutines.flow.MutableStateFlow(PipelineState())
    }).collectAsState()

    var editedLinesOverride by remember { mutableStateOf<List<LyricLine>?>(null) }
    LaunchedEffect(pipelineState.resultLines) {
        val aligned = pipelineState.resultLines
        if (aligned != null) {
            editedLinesOverride = null
            val effMeta = pipelineState.resultMetadata ?: metadata
            RecentProjectsStore.recordProject(
                context = context,
                title = effMeta.title.ifBlank { audioFileName.substringBeforeLast('.') },
                artist = effMeta.artists.joinToString(", "),
                language = effMeta.language ?: BilingualScriptAndNormalizer.detectDominantLanguage(aligned),
                lineCount = aligned.size,
                wordCount = aligned.sumOf { it.words?.size ?: 0 }
            )
            recentProjects = RecentProjectsStore.loadRecentProjects(context)
        }
    }

    val activeLines = editedLinesOverride ?: pipelineState.resultLines ?: importedLines
    val activeXml = remember(activeLines, editedLinesOverride, pipelineState.generatedTtmlXml, metadata) {
        if (editedLinesOverride != null || (pipelineState.generatedTtmlXml == null && activeLines.any { it.isLineTimed })) {
            val effMeta = pipelineState.resultMetadata ?: metadata
            val refIds = activeLines.map { it.agentId }.toSet()
            val agents = Agent.AGENT_PRESETS.filter { refIds.contains(it.id) }.ifEmpty { listOf(Agent.AGENT_PRESETS.first()) }
            org.betterlyrics.android.domain.ttml.TtmlSerializer.generateTTML(
                org.betterlyrics.android.domain.ttml.TTMLOptions(
                    metadata = effMeta,
                    agents = agents,
                    lines = activeLines,
                    duration = effMeta.duration
                )
            )
        } else {
            pipelineState.generatedTtmlXml
        }
    }

    // Local Lyrics File (.lrc, .txt, .ttml, .qrc, .srt) Picker
    val lyricsPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch(Dispatchers.IO) {
                val name = uri.lastPathSegment ?: "lyrics.lrc"
                val content = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
                val parsed = LrcAndTextParser.parseAnyLyricsFile(
                    filename = name,
                    content = content,
                    fallbackDuration = metadata.duration.takeIf { it > 0.0 },
                    autoExtractBackgroundVocals = autoExtractBgVocals
                )
                val detectedLang = parsed.metadata.language
                    ?: BilingualScriptAndNormalizer.detectDominantLanguage(parsed.lines)
                withContext(Dispatchers.Main) {
                    importedLines = parsed.lines
                    editedLinesOverride = parsed.lines.takeIf { lines -> lines.any { !it.words.isNullOrEmpty() } }
                    lyricsSourceLabel = "$name (${parsed.lines.size} lines)"
                    val updatedMeta = metadata.copy(
                        title = metadata.title.ifEmpty { parsed.metadata.title.ifEmpty { name.substringBeforeLast('.') } },
                        artists = metadata.artists.ifEmpty { parsed.metadata.artists },
                        album = metadata.album.ifEmpty { parsed.metadata.album },
                        language = detectedLang
                    )
                    metadata = updatedMeta
                    RecentProjectsStore.recordProject(
                        context = context,
                        title = updatedMeta.title.ifBlank { name.substringBeforeLast('.') },
                        artist = updatedMeta.artists.joinToString(", "),
                        language = detectedLang,
                        lineCount = parsed.lines.size,
                        wordCount = parsed.lines.sumOf { it.words?.size ?: 0 }
                    )
                    recentProjects = RecentProjectsStore.loadRecentProjects(context)
                }
            }
        }
    }

    // Audio File Picker
    val audioPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            selectedAudioUri = uri
            audioFileName = uri.lastPathSegment ?: "audio_track"
            scope.launch(Dispatchers.IO) {
                val extracted = AudioTagExtractor.extractMetadataFromUri(context, uri)
                withContext(Dispatchers.Main) {
                    metadata = extracted.copy(
                        title = extracted.title.ifEmpty { audioFileName.substringBeforeLast('.') }
                    )
                    if (pendingAudioThenLyrics) {
                        pendingAudioThenLyrics = false
                        lyricsPicker.launch(arrayOf("text/*", "application/xml", "application/octet-stream", "*/*"))
                    }
                }
            }
        } else {
            pendingAudioThenLyrics = false
        }
    }

    // Dedicated Existing TTML Import Picker (Opens directly in Composer / Preview)
    val ttmlImportPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch(Dispatchers.IO) {
                val name = uri.lastPathSegment ?: "imported.ttml"
                val content = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
                val parsed = LrcAndTextParser.parseAnyLyricsFile(
                    filename = name,
                    content = content,
                    fallbackDuration = metadata.duration.takeIf { it > 0.0 },
                    autoExtractBackgroundVocals = autoExtractBgVocals
                )
                val detectedLang = parsed.metadata.language
                    ?: BilingualScriptAndNormalizer.detectDominantLanguage(parsed.lines)
                withContext(Dispatchers.Main) {
                    importedLines = parsed.lines
                    editedLinesOverride = parsed.lines
                    lyricsSourceLabel = "$name (${parsed.lines.size} synchronized lines)"
                    val updatedMeta = metadata.copy(
                        title = parsed.metadata.title.ifEmpty { metadata.title.ifEmpty { name.substringBeforeLast('.') } },
                        artists = parsed.metadata.artists.ifEmpty { metadata.artists },
                        album = parsed.metadata.album.ifEmpty { metadata.album },
                        duration = parsed.metadata.duration.takeIf { it > 0.0 } ?: metadata.duration,
                        language = detectedLang
                    )
                    metadata = updatedMeta
                    RecentProjectsStore.recordProject(
                        context = context,
                        title = updatedMeta.title.ifBlank { name.substringBeforeLast('.') },
                        artist = updatedMeta.artists.joinToString(", "),
                        language = detectedLang,
                        lineCount = parsed.lines.size,
                        wordCount = parsed.lines.sumOf { it.words?.size ?: 0 }
                    )
                    recentProjects = RecentProjectsStore.loadRecentProjects(context)
                    selectedTab = 3 // Open directly in Composer timeline editor
                }
            }
        }
    }

    // Export TTML Document Launcher
    val exportTtmlLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/ttml+xml")
    ) { uri: Uri? ->
        val xmlToWrite = activeXml ?: return@rememberLauncherForActivityResult
        if (uri != null) {
            scope.launch(Dispatchers.IO) {
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    out.write(xmlToWrite.toByteArray(Charsets.UTF_8))
                }
            }
        }
    }

    val triggerPipelineRun: () -> Unit = {
        val uri = selectedAudioUri
        if (uri != null && importedLines.isNotEmpty()) {
            service?.startPipeline(
                request = PipelineJobRequest(
                    audioUri = uri,
                    metadata = metadata,
                    agents = Agent.AGENT_PRESETS,
                    initialLines = importedLines,
                    demucsModelVariant = demucsVariant,
                    arabicBackend = arabicBackend,
                    useHardwareAcceleration = useHardwareAccel,
                    enableSyllableSplitting = enableSyllableSplit,
                    autoExtractBackgroundVocals = autoExtractBgVocals,
                    snapToSpectralOnsets = snapToVocalOnsets
                ),
                modelManager = modelManager
            )
        }
    }

    Box(modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            BetterLyricsBrandEmblem(modifier = Modifier.size(34.dp))
                            Column {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text(
                                        "Better Lyrics",
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 17.sp,
                                        color = Color(0xFFF8FAFC)
                                    )
                                    Text(
                                        "COMPOSER STUDIO",
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 10.sp,
                                        color = MaterialTheme.colorScheme.secondary,
                                        letterSpacing = 0.8.sp
                                    )
                                }
                                Text(
                                    "Arabic & English Word-Level TTML Synchronizer",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    actions = {
                        if (activeXml != null) {
                            Button(
                                onClick = {
                                    val safeTitle = (metadata.title.ifBlank { "synchronized" })
                                        .replace(Regex("[^\\p{L}\\p{N}_-]+"), "_")
                                    exportTtmlLauncher.launch("$safeTitle.ttml")
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.primary
                                ),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                modifier = Modifier.padding(end = 8.dp)
                            ) {
                                Icon(Icons.Default.Save, contentDescription = "Export TTML", modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Export .TTML", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                )
            },
            bottomBar = {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 8.dp
                ) {
                    NavigationBarItem(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        icon = { Icon(Icons.Default.Home, contentDescription = "Studio Home") },
                        label = { Text("Home", fontSize = 10.sp) }
                    )
                    NavigationBarItem(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        icon = { Icon(Icons.Default.GraphicEq, contentDescription = "Alignment Pipeline") },
                        label = { Text("Pipeline", fontSize = 10.sp) }
                    )
                    NavigationBarItem(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        icon = { Icon(Icons.Default.MusicNote, contentDescription = "RTL/LTR Live Preview") },
                        label = { Text("Preview", fontSize = 10.sp) }
                    )
                    NavigationBarItem(
                        selected = selectedTab == 3,
                        onClick = { selectedTab = 3 },
                        icon = { Icon(Icons.Default.EditNote, contentDescription = "Composer Timeline") },
                        label = { Text("Composer", fontSize = 10.sp) }
                    )
                    NavigationBarItem(
                        selected = selectedTab == 4,
                        onClick = { selectedTab = 4 },
                        icon = { Icon(Icons.Default.SettingsSuggest, contentDescription = "ONNX Models and XML") },
                        label = { Text("Models & XML", fontSize = 10.sp) }
                    )
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(MaterialTheme.colorScheme.background)
            ) {
                when (selectedTab) {
                    0 -> StudioHomeScreen(
                        audioFileName = audioFileName,
                        lyricsSourceLabel = lyricsSourceLabel,
                        metadata = metadata,
                        activeLinesCount = activeLines.size,
                        activeWordsCount = activeLines.sumOf { it.words?.size ?: 0 },
                        arabicBackend = arabicBackend,
                        demucsVariant = demucsVariant,
                        useHardwareAccel = useHardwareAccel,
                        pipelineState = pipelineState,
                        modelManager = modelManager,
                        recentProjects = recentProjects,
                        onStartNewProject = {
                            selectedTab = 1
                            audioPicker.launch(arrayOf("audio/*"))
                        },
                        onImportAudioAndLyrics = {
                            pendingAudioThenLyrics = true
                            selectedTab = 1
                            audioPicker.launch(arrayOf("audio/*"))
                        },
                        onImportExistingTtml = {
                            ttmlImportPicker.launch(arrayOf("application/ttml+xml", "application/xml", "text/xml", "text/*", "*/*"))
                        },
                        onOpenComposer = {
                            selectedTab = 3
                        },
                        onOpenPipeline = {
                            selectedTab = 1
                        },
                        onOpenPreview = {
                            selectedTab = 2
                        },
                        onOpenModels = {
                            selectedTab = 4
                        },
                        onRetryPipeline = triggerPipelineRun,
                        onCancelPipeline = { service?.cancelPipeline() }
                    )

                    1 -> PipelineSetupAndMonitorScreen(
                        audioFileName = audioFileName,
                        lyricsSourceLabel = lyricsSourceLabel,
                        metadata = metadata,
                        onMetadataChange = { metadata = it },
                        importedLinesCount = importedLines.size,
                        demucsVariant = demucsVariant,
                        onDemucsVariantChange = { demucsVariant = it },
                        arabicBackend = arabicBackend,
                        onArabicBackendChange = { arabicBackend = it },
                        useHardwareAccel = useHardwareAccel,
                        onHardwareAccelChange = { useHardwareAccel = it },
                        enableSyllableSplit = enableSyllableSplit,
                        onSyllableSplitChange = { enableSyllableSplit = it },
                        autoExtractBgVocals = autoExtractBgVocals,
                        onAutoExtractBgChange = { autoExtractBgVocals = it },
                        snapToVocalOnsets = snapToVocalOnsets,
                        onSnapToOnsetsChange = { snapToVocalOnsets = it },
                        pipelineState = pipelineState,
                        onPickAudio = {
                            audioPicker.launch(arrayOf("audio/*"))
                        },
                        onPickLyricsFile = {
                            lyricsPicker.launch(arrayOf("text/*", "application/xml", "application/octet-stream", "*/*"))
                        },
                        onOpenLrclibSearch = { showLrclibModal = true },
                        onStartPipeline = triggerPipelineRun,
                        onCancelPipeline = { service?.cancelPipeline() },
                        onJumpToPreview = { selectedTab = 2 }
                    )

                    2 -> AppleMusicLivePreviewScreen(
                        audioUri = selectedAudioUri,
                        vocalsWavFile = pipelineState.vocalsWavFile,
                        instrumentalWavFile = pipelineState.instrumentalWavFile,
                        lines = activeLines,
                        metadata = pipelineState.resultMetadata ?: metadata
                    )

                    3 -> ComposerStudioWebViewScreen(
                        audioUri = selectedAudioUri,
                        vocalsWavFile = pipelineState.vocalsWavFile,
                        lines = activeLines,
                        vocalOnsets = pipelineState.vocalOnsetSeconds,
                        onLinesUpdated = { updatedLines ->
                            editedLinesOverride = updatedLines
                        }
                    )

                    4 -> ModelManagerAndExportScreen(
                        modelManager = modelManager,
                        generatedTtml = activeXml,
                        validation = pipelineState.validationStatus,
                        onExportTtml = {
                            val safeTitle = (metadata.title.ifBlank { "synchronized" })
                                .replace(Regex("[^\\p{L}\\p{N}_-]+"), "_")
                            exportTtmlLauncher.launch("$safeTitle.ttml")
                        }
                    )
                }
            }
        }

        AnimatedVisibility(
            visible = showLaunchSplash,
            enter = fadeIn(tween(150)),
            exit = fadeOut(tween(280))
        ) {
            StudioLaunchSplashOverlay()
        }
    }

    if (showLrclibModal) {
        LrclibSearchDialog(
            initialQuery = LyricsSearchQuery(
                track = metadata.title,
                artist = metadata.artists.firstOrNull().orEmpty(),
                album = metadata.album,
                durationSec = metadata.duration.takeIf { it > 0.0 },
                isrc = metadata.isrc
            ),
            autoExtractBgVocals = autoExtractBgVocals,
            onDismiss = { showLrclibModal = false },
            onSelectLyrics = { lines, sourceDesc, detectedLang ->
                importedLines = lines
                lyricsSourceLabel = sourceDesc
                if (detectedLang != null) {
                    metadata = metadata.copy(language = detectedLang)
                }
                showLrclibModal = false
            }
        )
    }
}

// ================================================================================================
// 3. TAB 1: STUDIO PIPELINE SETUP & FOREGROUND EXECUTION MONITOR
// ================================================================================================

@Composable
fun PipelineSetupAndMonitorScreen(
    audioFileName: String,
    lyricsSourceLabel: String,
    metadata: ProjectMetadata,
    onMetadataChange: (ProjectMetadata) -> Unit,
    importedLinesCount: Int,
    demucsVariant: ModelId,
    onDemucsVariantChange: (ModelId) -> Unit,
    arabicBackend: ArabicAlignmentBackend = ArabicAlignmentBackend.AUTO_CALIBRATED,
    onArabicBackendChange: (ArabicAlignmentBackend) -> Unit = {},
    useHardwareAccel: Boolean,
    onHardwareAccelChange: (Boolean) -> Unit,
    enableSyllableSplit: Boolean,
    onSyllableSplitChange: (Boolean) -> Unit,
    autoExtractBgVocals: Boolean,
    onAutoExtractBgChange: (Boolean) -> Unit,
    snapToVocalOnsets: Boolean,
    onSnapToOnsetsChange: (Boolean) -> Unit,
    pipelineState: PipelineState,
    onPickAudio: () -> Unit,
    onPickLyricsFile: () -> Unit,
    onOpenLrclibSearch: () -> Unit,
    onStartPipeline: () -> Unit,
    onCancelPipeline: () -> Unit,
    onJumpToPreview: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Input Sources Card
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("1. Audio & Lyrics Input", fontWeight = FontWeight.Bold, fontSize = 16.sp)

                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = onPickAudio) {
                        Icon(Icons.Default.FolderOpen, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Select Audio (FLAC/MP3/WAV/M4A)")
                    }
                    Text(
                        text = audioFileName,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onPickLyricsFile, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Default.FolderOpen, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Import .LRC / .TXT / .TTML")
                    }
                    Button(onClick = onOpenLrclibSearch, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Search LRCLIB.net")
                    }
                }

                Text(
                    text = "Loaded Lyrics: $lyricsSourceLabel",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.secondary
                )
            }
        }

        // 2. Project Metadata & Language (Arabic / English) Card
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("2. TTML <head><metadata> & Script Specialist", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = metadata.title,
                        onValueChange = { onMetadataChange(metadata.copy(title = it)) },
                        label = { Text("Track Title (ttm:title)") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = metadata.artists.joinToString(", "),
                        onValueChange = { raw ->
                            onMetadataChange(
                                metadata.copy(
                                    artists = raw.split(",").map { it.trim() }.filter { it.isNotEmpty() }
                                )
                            )
                        },
                        label = { Text("Artists (composer:meta)") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = metadata.album,
                        onValueChange = { onMetadataChange(metadata.copy(album = it)) },
                        label = { Text("Album") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = metadata.isrc.orEmpty(),
                        onValueChange = { onMetadataChange(metadata.copy(isrc = it.ifBlank { null })) },
                        label = { Text("ISRC") },
                        singleLine = true,
                        modifier = Modifier.weight(0.8f)
                    )
                    OutlinedTextField(
                        value = metadata.language.orEmpty(),
                        onValueChange = { onMetadataChange(metadata.copy(language = it)) },
                        label = { Text("xml:lang (ar/en)") },
                        singleLine = true,
                        modifier = Modifier.weight(0.6f)
                    )
                }
            }
        }

        // 3. DSP & Forced Alignment Pipeline Settings
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("3. Multi-Stage Offline DSP & AI Alignment Configuration", fontWeight = FontWeight.Bold, fontSize = 16.sp)

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = demucsVariant == ModelId.HTDEMUCS_FP32,
                        onClick = { onDemucsVariantChange(ModelId.HTDEMUCS_FP32) },
                        label = { Text("HTDemucs FP32 (if installed)") }
                    )
                    FilterChip(
                        selected = demucsVariant == ModelId.HTDEMUCS_FP16,
                        onClick = { onDemucsVariantChange(ModelId.HTDEMUCS_FP16) },
                        label = { Text("HTDemucs FP16 (if installed)") }
                    )
                }

                Text("Arabic Neural CTC Backend (Egyptian ar-EG & MSA):", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ArabicAlignmentBackend.entries.forEach { backend ->
                        FilterChip(
                            selected = arabicBackend == backend,
                            onClick = { onArabicBackendChange(backend) },
                            label = { Text(backend.title, fontSize = 11.sp) }
                        )
                    }
                }

                SettingSwitchRow(
                    title = "Extract Background Vocals into <span ttm:role=\"x-bg\">",
                    subtitle = "Detects parenthesized (background vocals) & aligns them independently",
                    checked = autoExtractBgVocals,
                    onCheckedChange = onAutoExtractBgChange
                )
                SettingSwitchRow(
                    title = "Enable Syllable-Accurate Splitting (Arabic CV/CVV + English)",
                    subtitle = "Emits adjacent <span> syllables without spaces; trailing spaces between words",
                    checked = enableSyllableSplit,
                    onCheckedChange = onSyllableSplitChange
                )
                SettingSwitchRow(
                    title = "Stage 4 Spectral Flux Vocal Onset Snapping & Arabic Madd Hold",
                    subtitle = "Snaps word starts to micro-transients & holds sustained Arabic Madd vowels (ا، و، ي)",
                    checked = snapToVocalOnsets,
                    onCheckedChange = onSnapToOnsetsChange
                )
                SettingSwitchRow(
                    title = "NNAPI / Vulkan acceleration (unavailable)",
                    subtitle = "This build runs ONNX and DSP processing on CPU; no GPU delegate is connected.",
                    checked = useHardwareAccel,
                    onCheckedChange = onHardwareAccelChange,
                    enabled = false
                )
            }
        }

        // 4. Execution Control & Live Telemetry Card
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = pipelineState.stage.title,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "${pipelineState.elapsedMillis / 1000}s elapsed",
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                LinearProgressIndicator(
                    progress = { pipelineState.overallProgress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp))
                )

                Text(
                    text = pipelineState.detailMessage,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                val isRunning = pipelineState.stage.stepNumber in 1..4
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = onStartPipeline,
                        enabled = !isRunning && importedLinesCount > 0,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Run 4-Stage Studio Alignment")
                    }
                    if (isRunning) {
                        OutlinedButton(onClick = onCancelPipeline) {
                            Text("Cancel")
                        }
                    }
                    if (pipelineState.stage == PipelineStage.COMPLETED) {
                        Button(
                            onClick = onJumpToPreview,
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                        ) {
                            Text("Open Live Preview", color = Color.Black)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingSwitchRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    enabled: Boolean = true
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            Text(subtitle, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange, enabled = enabled)
    }
}

// ================================================================================================
// 4. TAB 2: BILINGUAL RTL/LTR APPLE MUSIC LIVE SYNCHRONIZED LYRICS PREVIEW
// ================================================================================================

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AppleMusicLivePreviewScreen(
    audioUri: Uri?,
    vocalsWavFile: File?,
    instrumentalWavFile: File?,
    lines: List<LyricLine>,
    metadata: ProjectMetadata
) {
    val context = LocalContext.current
    var stemMode by remember { mutableIntStateOf(0) } // 0 = Original, 1 = Isolated Vocals, 2 = Instrumental
    var currentSec by remember { mutableDoubleStateOf(0.0) }
    var isPlaying by remember { mutableStateOf(false) }
    var durationSec by remember { mutableDoubleStateOf(metadata.duration.coerceAtLeast(1.0)) }

    val exoPlayer = remember {
        ExoPlayer.Builder(context).build()
    }

    // Load selected audio source into ExoPlayer
    LaunchedEffect(audioUri, vocalsWavFile, instrumentalWavFile, stemMode) {
        val targetUri = when (stemMode) {
            1 -> vocalsWavFile?.let { Uri.fromFile(it) } ?: audioUri
            2 -> instrumentalWavFile?.let { Uri.fromFile(it) } ?: audioUri
            else -> audioUri
        }
        if (targetUri != null) {
            val prevPos = exoPlayer.currentPosition
            val wasPlaying = exoPlayer.isPlaying
            exoPlayer.setMediaItem(MediaItem.fromUri(targetUri))
            exoPlayer.prepare()
            exoPlayer.seekTo(prevPos)
            exoPlayer.playWhenReady = wasPlaying
        }
    }

    // 60fps high-precision frame clock for smooth word/syllable gradient sweep
    LaunchedEffect(exoPlayer) {
        while (isActive) {
            withFrameMillis {
                isPlaying = exoPlayer.isPlaying
                currentSec = exoPlayer.currentPosition / 1000.0
                if (exoPlayer.duration > 0) {
                    durationSec = exoPlayer.duration / 1000.0
                }
            }
        }
    }

    DisposableEffect(Unit) {
        onDispose { exoPlayer.release() }
    }

    val listState = rememberLazyListState()
    // Prioritize any line whose word is actively being sung at `currentSec`, so a sustained word
    // carried across a line break keeps its line highlighted until the singer genuinely finishes!
    val activeLineIndex = remember(currentSec, lines) {
        val wordActiveIdx = lines.indexOfFirst { line ->
            line.words?.any { w -> currentSec >= w.begin - 0.03 && currentSec <= w.end + 0.04 } == true
        }
        if (wordActiveIdx >= 0) {
            wordActiveIdx
        } else {
            lines.indexOfFirst { line ->
                val b = line.effectiveBounds()
                b != null && currentSec >= b.begin - 0.06 && currentSec <= b.end + 0.15
            }
        }
    }

    LaunchedEffect(activeLineIndex) {
        if (activeLineIndex >= 0) {
            listState.animateScrollToItem((activeLineIndex - 1).coerceAtLeast(0))
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF0F172A), Color(0xFF060911))
                )
            )
    ) {
        // Stem Monitor & Transport Bar
        Surface(color = MaterialTheme.colorScheme.surface, tonalElevation = 4.dp) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = {
                                if (exoPlayer.isPlaying) exoPlayer.pause() else exoPlayer.play()
                            },
                            modifier = Modifier
                                .size(42.dp)
                                .background(MaterialTheme.colorScheme.primary, CircleShape)
                        ) {
                            Icon(
                                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = "Play/Pause",
                                tint = Color.Black
                            )
                        }
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(
                                text = metadata.title.ifBlank { "Live Synchronized Preview" },
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                            Text(
                                text = "${TtmlFormatting.formatTime(currentSec, 2)} / ${TtmlFormatting.formatTime(durationSec, 2)}",
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace,
                                color = MaterialTheme.colorScheme.secondary
                            )
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(
                            selected = stemMode == 0,
                            onClick = { stemMode = 0 },
                            label = { Text("Full Mix", fontSize = 11.sp) }
                        )
                        FilterChip(
                            selected = stemMode == 1,
                            onClick = { stemMode = 1 },
                            enabled = vocalsWavFile?.exists() == true,
                            label = { Text("Vocals Only", fontSize = 11.sp) }
                        )
                        FilterChip(
                            selected = stemMode == 2,
                            onClick = { stemMode = 2 },
                            enabled = instrumentalWavFile?.exists() == true,
                            label = { Text("Instrumental", fontSize = 11.sp) }
                        )
                    }
                }

                Slider(
                    value = currentSec.toFloat(),
                    onValueChange = { exoPlayer.seekTo((it * 1000).toLong()) },
                    valueRange = 0f..durationSec.toFloat().coerceAtLeast(1f),
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    "Instrumental separation/export is unavailable; only the original mix and vocal stem are provided.",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Synchronized Bilingual RTL/LTR Lyric Stream
        LazyColumn(
            state = listState,
            contentPadding = PaddingValues(horizontal = 24.dp, vertical = 48.dp),
            verticalArrangement = Arrangement.spacedBy(26.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            itemsIndexed(lines, key = { _, line -> line.id }) { index, line ->
                val bounds = line.effectiveBounds()
                val hasActiveWordNow = line.words?.any { w -> currentSec >= w.begin - 0.02 && currentSec <= w.end + 0.03 } == true ||
                    line.backgroundWords?.any { w -> currentSec >= w.begin - 0.02 && currentSec <= w.end + 0.03 } == true
                val isLineActive = index == activeLineIndex || hasActiveWordNow ||
                    (bounds != null && currentSec >= bounds.begin && currentSec <= bounds.end)
                val isLinePast = bounds != null && currentSec > bounds.end && !hasActiveWordNow
                val isArabicLine = BilingualScriptAndNormalizer.isArabicWord(line.text)
                val isDuetRight = line.agentId == "v2"

                // Bidirectional layout: RTL for Arabic lines, LTR for English lines
                val lineDirection = if (isArabicLine) LayoutDirection.Rtl else LayoutDirection.Ltr

                CompositionLocalProvider(LocalLayoutDirection provides lineDirection) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .clickable {
                                if (bounds != null) {
                                    exoPlayer.seekTo((bounds.begin * 1000.0).toLong())
                                    exoPlayer.play()
                                }
                            }
                            .padding(vertical = 6.dp, horizontal = 8.dp),
                        horizontalAlignment = if (isDuetRight) Alignment.End else Alignment.Start
                    ) {
                        // Main Vocal Word/Syllable FlowRow
                        if (!line.words.isNullOrEmpty()) {
                            FlowRow(
                                horizontalArrangement = if (isDuetRight) Arrangement.End else Arrangement.Start,
                                verticalArrangement = Arrangement.Center
                            ) {
                                for (word in line.words) {
                                    AnimatedKarokeWordSpan(
                                        word = word,
                                        currentSec = currentSec,
                                        isLineActive = isLineActive,
                                        isLinePast = isLinePast,
                                        isRtl = isArabicLine,
                                        fontSizeSp = 26f
                                    )
                                }
                            }
                        } else {
                            Text(
                                text = line.text,
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isLineActive) Color.White else Color.White.copy(alpha = 0.35f)
                            )
                        }

                        // Background Vocals (`ttm:role="x-bg"`)
                        if (!line.backgroundWords.isNullOrEmpty()) {
                            Spacer(Modifier.height(6.dp))
                            FlowRow(
                                horizontalArrangement = if (isDuetRight) Arrangement.End else Arrangement.Start,
                                modifier = Modifier
                                    .background(Color.White.copy(alpha = 0.06f), RoundedCornerShape(8.dp))
                                    .padding(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                for (bgWord in line.backgroundWords) {
                                    AnimatedKarokeWordSpan(
                                        word = bgWord,
                                        currentSec = currentSec,
                                        isLineActive = isLineActive,
                                        isLinePast = isLinePast,
                                        isRtl = BilingualScriptAndNormalizer.isArabicWord(bgWord.text),
                                        fontSizeSp = 17f
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Apple Music-style word/syllable span with continuous RTL-aware or LTR-aware gradient sweep fill
 * and vertical vocal lift animation.
 */
@Composable
private fun AnimatedKarokeWordSpan(
    word: WordTiming,
    currentSec: Double,
    isLineActive: Boolean,
    isLinePast: Boolean,
    isRtl: Boolean,
    fontSizeSp: Float
) {
    val duration = (word.end - word.begin).coerceAtLeast(0.02)
    val rawFill = ((currentSec - word.begin) / duration).toFloat().coerceIn(0f, 1f)
    val isWordActive = currentSec >= word.begin && currentSec <= word.end

    val liftOffsetPx by animateFloatAsState(
        targetValue = if (isWordActive) -4f else 0f,
        animationSpec = tween(durationMillis = 120),
        label = "wordLift"
    )

    val displayText = if (word.text.endsWith(" ")) "${word.text.trimEnd()} " else word.text

    Text(
        text = displayText,
        fontSize = fontSizeSp.sp,
        fontWeight = FontWeight.ExtraBold,
        color = Color.White,
        modifier = Modifier
            .graphicsLayer {
                translationY = liftOffsetPx
                compositingStrategy = CompositingStrategy.Offscreen
            }
            .drawWithContent {
                drawContent()
                val activeAlpha = when {
                    rawFill >= 1f || isLinePast -> 1f
                    rawFill <= 0f -> if (isLineActive) 0.35f else 0.22f
                    else -> -1f // Partial gradient sweep
                }
                if (activeAlpha >= 0f) {
                    drawRect(
                        color = Color.White.copy(alpha = activeAlpha),
                        blendMode = BlendMode.SrcIn
                    )
                } else {
                    // Smooth RTL or LTR wipe across the word/syllable
                    val sweepBrush = if (isRtl) {
                        val edge = (1f - rawFill).coerceIn(0.01f, 0.99f)
                        Brush.horizontalGradient(
                            0.0f to Color.White.copy(alpha = 0.35f),
                            (edge - 0.04f).coerceAtLeast(0f) to Color.White.copy(alpha = 0.35f),
                            (edge + 0.04f).coerceAtMost(1f) to Color.White,
                            1.0f to Color.White
                        )
                    } else {
                        val edge = rawFill.coerceIn(0.01f, 0.99f)
                        Brush.horizontalGradient(
                            0.0f to Color.White,
                            (edge - 0.04f).coerceAtLeast(0f) to Color.White,
                            (edge + 0.04f).coerceAtMost(1f) to Color.White.copy(alpha = 0.35f),
                            1.0f to Color.White.copy(alpha = 0.35f)
                        )
                    }
                    drawRect(brush = sweepBrush, blendMode = BlendMode.SrcIn)
                }
            }
    )
}

// ================================================================================================
// 5. TAB 3: PHONE-NATIVE INTERACTIVE COMPOSER TIMELINE & WORD-SPAN EDITOR
// ================================================================================================

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ComposerStudioWebViewScreen(
    audioUri: Uri?,
    vocalsWavFile: File?,
    lines: List<LyricLine>,
    vocalOnsets: DoubleArray?,
    onLinesUpdated: (List<LyricLine>) -> Unit
) {
    val context = LocalContext.current
    var stemMode by remember { mutableIntStateOf(0) } // 0 = Full Mix, 1 = Vocals Only
    var currentSec by remember { mutableDoubleStateOf(0.0) }
    var isPlaying by remember { mutableStateOf(false) }
    var durationSec by remember { mutableDoubleStateOf(240.0) }

    var selectedLineIdx by remember { mutableIntStateOf(0) }
    var selectedWordIdx by remember { mutableIntStateOf(0) }

    val exoPlayer = remember {
        ExoPlayer.Builder(context).build()
    }

    LaunchedEffect(audioUri, vocalsWavFile, stemMode) {
        val targetUri = if (stemMode == 1 && vocalsWavFile?.exists() == true) {
            Uri.fromFile(vocalsWavFile)
        } else {
            audioUri
        }
        if (targetUri != null) {
            val prevPos = exoPlayer.currentPosition
            val wasPlaying = exoPlayer.isPlaying
            exoPlayer.setMediaItem(MediaItem.fromUri(targetUri))
            exoPlayer.prepare()
            exoPlayer.seekTo(prevPos)
            exoPlayer.playWhenReady = wasPlaying
        }
    }

    LaunchedEffect(exoPlayer) {
        while (isActive) {
            withFrameMillis {
                isPlaying = exoPlayer.isPlaying
                currentSec = exoPlayer.currentPosition / 1000.0
                if (exoPlayer.duration > 0) {
                    durationSec = exoPlayer.duration / 1000.0
                }
            }
        }
    }

    DisposableEffect(Unit) {
        onDispose { exoPlayer.release() }
    }

    fun updateWordTiming(lineIdx: Int, wordIdx: Int, transform: (WordTiming) -> WordTiming) {
        val line = lines.getOrNull(lineIdx) ?: return
        val words = line.words?.toMutableList() ?: return
        if (wordIdx !in words.indices) return
        val updatedWord = transform(words[wordIdx]).let { w ->
            val b = w.begin.coerceAtLeast(0.0)
            val e = w.end.coerceAtLeast(b + 0.05)
            w.copy(begin = b, end = e)
        }
        words[wordIdx] = updatedWord
        val newLines = lines.toMutableList()
        newLines[lineIdx] = line.copy(words = words).reconcile()
        onLinesUpdated(newLines)
    }

    fun shiftEntireLine(lineIdx: Int, deltaSec: Double) {
        val line = lines.getOrNull(lineIdx) ?: return
        val shiftedWords = line.words?.map { w ->
            val b = (w.begin + deltaSec).coerceAtLeast(0.0)
            val e = (w.end + deltaSec).coerceAtLeast(b + 0.05)
            w.copy(begin = b, end = e)
        }
        val shiftedBg = line.backgroundWords?.map { w ->
            val b = (w.begin + deltaSec).coerceAtLeast(0.0)
            val e = (w.end + deltaSec).coerceAtLeast(b + 0.05)
            w.copy(begin = b, end = e)
        }
        val bLine = line.begin?.let { (it + deltaSec).coerceAtLeast(0.0) }
        val eLine = line.end?.let { (it + deltaSec).coerceAtLeast((bLine ?: 0.0) + 0.10) }
        val newLines = lines.toMutableList()
        newLines[lineIdx] = line.copy(
            begin = bLine,
            end = eLine,
            words = shiftedWords,
            backgroundWords = shiftedBg
        ).reconcile()
        onLinesUpdated(newLines)
    }

    fun updateLineAgent(lineIdx: Int, newAgentId: String) {
        val line = lines.getOrNull(lineIdx) ?: return
        val newLines = lines.toMutableList()
        newLines[lineIdx] = line.copy(agentId = newAgentId)
        onLinesUpdated(newLines)
    }

    val safeLineIdx = selectedLineIdx.coerceIn(0, (lines.size - 1).coerceAtLeast(0))
    val activeSelectedLine = lines.getOrNull(safeLineIdx)
    val activeSelectedWords = activeSelectedLine?.words.orEmpty()
    val safeWordIdx = selectedWordIdx.coerceIn(0, (activeSelectedWords.size - 1).coerceAtLeast(0))
    val activeSelectedWord = activeSelectedWords.getOrNull(safeWordIdx)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Text(
            "Native Compose timing editor. The bundled HTML/WebView composer is not connected in this build.",
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        // 1. Top Audio Transport & Stem Switch Bar
        Surface(color = MaterialTheme.colorScheme.surface, tonalElevation = 4.dp) {
            Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = { if (exoPlayer.isPlaying) exoPlayer.pause() else exoPlayer.play() },
                            modifier = Modifier
                                .size(38.dp)
                                .background(MaterialTheme.colorScheme.primary, CircleShape)
                        ) {
                            Icon(
                                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = "Play/Pause",
                                tint = Color.Black
                            )
                        }
                        Spacer(Modifier.width(8.dp))
                        TextButton(onClick = { exoPlayer.seekTo((exoPlayer.currentPosition - 500L).coerceAtLeast(0L)) }) {
                            Text("-0.5s", fontSize = 11.sp)
                        }
                        Text(
                            text = TtmlFormatting.formatTime(currentSec, 3),
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = MaterialTheme.colorScheme.secondary
                        )
                        TextButton(onClick = { exoPlayer.seekTo(exoPlayer.currentPosition + 500L) }) {
                            Text("+0.5s", fontSize = 11.sp)
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(
                            selected = stemMode == 0,
                            onClick = { stemMode = 0 },
                            label = { Text("Full Mix", fontSize = 11.sp) }
                        )
                        FilterChip(
                            selected = stemMode == 1,
                            onClick = { stemMode = 1 },
                            enabled = vocalsWavFile?.exists() == true,
                            label = { Text("Vocals Only", fontSize = 11.sp) }
                        )
                    }
                }

                Slider(
                    value = currentSec.toFloat(),
                    onValueChange = { exoPlayer.seekTo((it * 1000).toLong()) },
                    valueRange = 0f..durationSec.toFloat().coerceAtLeast(1f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(26.dp)
                )
            }
        }

        if (lines.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                Text(
                    text = "Load an audio track and lyrics (.LRC / .TXT / LRCLIB) on the Pipeline tab first to edit word timings here.",
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 14.sp
                )
            }
            return@Column
        }

        // 2. Sticky Precision Word & Line Inspector Dock (For Selected Word)
        if (activeSelectedLine != null) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val wordLabel = activeSelectedWord?.text?.trim() ?: activeSelectedLine.text.take(24)
                        val durMs = if (activeSelectedWord != null) {
                            ((activeSelectedWord.end - activeSelectedWord.begin) * 1000.0).toInt()
                        } else 0
                        val confBadge = activeSelectedWord?.confidence?.let { c ->
                            val pct = (c * 100f).toInt()
                            if (activeSelectedWord.needsReview) " • ⚠ ${pct}% (Check)" else " • ${pct}%"
                        }.orEmpty()
                        Text(
                            text = "L${safeLineIdx + 1} • \"$wordLabel\" (${durMs}ms$confBadge)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = if (activeSelectedWord?.needsReview == true) Color(0xFFFBBF24) else MaterialTheme.colorScheme.primary,
                            modifier = Modifier.weight(1f)
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            listOf("v1" to "v1", "v2" to "v2", "v1000" to "Duet").forEach { (id, label) ->
                                FilterChip(
                                    selected = activeSelectedLine.agentId == id,
                                    onClick = { updateLineAgent(safeLineIdx, id) },
                                    label = { Text(label, fontSize = 10.sp) }
                                )
                            }
                        }
                    }

                    if (activeSelectedWord != null) {
                        // Word START (`begin`) Controls
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Start: ${TtmlFormatting.formatTime(activeSelectedWord.begin, 3)}",
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                color = Color(0xFF4FD6C0),
                                modifier = Modifier.width(96.dp)
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                OutlinedButton(
                                    onClick = { updateWordTiming(safeLineIdx, safeWordIdx) { it.copy(begin = it.begin - 0.100) } },
                                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                                    modifier = Modifier.height(28.dp)
                                ) { Text("-100ms", fontSize = 10.sp) }
                                OutlinedButton(
                                    onClick = { updateWordTiming(safeLineIdx, safeWordIdx) { it.copy(begin = it.begin - 0.025) } },
                                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                                    modifier = Modifier.height(28.dp)
                                ) { Text("-25ms", fontSize = 10.sp) }
                                OutlinedButton(
                                    onClick = { updateWordTiming(safeLineIdx, safeWordIdx) { it.copy(begin = it.begin + 0.025) } },
                                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                                    modifier = Modifier.height(28.dp)
                                ) { Text("+25ms", fontSize = 10.sp) }
                                OutlinedButton(
                                    onClick = { updateWordTiming(safeLineIdx, safeWordIdx) { it.copy(begin = it.begin + 0.100) } },
                                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                                    modifier = Modifier.height(28.dp)
                                ) { Text("+100ms", fontSize = 10.sp) }
                                Button(
                                    onClick = {
                                        updateWordTiming(safeLineIdx, safeWordIdx) {
                                            it.copy(begin = currentSec, end = maxOf(it.end, currentSec + 0.12))
                                        }
                                    },
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                    modifier = Modifier.height(28.dp)
                                ) { Text("Set @ Now", fontSize = 10.sp) }
                            }
                        }

                        // Word END (`end`) Controls
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "End  : ${TtmlFormatting.formatTime(activeSelectedWord.end, 3)}",
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                color = Color(0xFFF472B6),
                                modifier = Modifier.width(96.dp)
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                OutlinedButton(
                                    onClick = { updateWordTiming(safeLineIdx, safeWordIdx) { it.copy(end = it.end - 0.100) } },
                                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                                    modifier = Modifier.height(28.dp)
                                ) { Text("-100ms", fontSize = 10.sp) }
                                OutlinedButton(
                                    onClick = { updateWordTiming(safeLineIdx, safeWordIdx) { it.copy(end = it.end - 0.025) } },
                                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                                    modifier = Modifier.height(28.dp)
                                ) { Text("-25ms", fontSize = 10.sp) }
                                OutlinedButton(
                                    onClick = { updateWordTiming(safeLineIdx, safeWordIdx) { it.copy(end = it.end + 0.025) } },
                                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                                    modifier = Modifier.height(28.dp)
                                ) { Text("+25ms", fontSize = 10.sp) }
                                OutlinedButton(
                                    onClick = { updateWordTiming(safeLineIdx, safeWordIdx) { it.copy(end = it.end + 0.100) } },
                                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                                    modifier = Modifier.height(28.dp)
                                ) { Text("+100ms", fontSize = 10.sp) }
                                Button(
                                    onClick = {
                                        updateWordTiming(safeLineIdx, safeWordIdx) {
                                            it.copy(end = maxOf(it.begin + 0.06, currentSec))
                                        }
                                    },
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                    modifier = Modifier.height(28.dp)
                                ) { Text("Set @ Now", fontSize = 10.sp) }
                            }
                        }
                    }

                    // Whole-Line Shift & Quick Navigation Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Whole Line:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            OutlinedButton(
                                onClick = { shiftEntireLine(safeLineIdx, -0.100) },
                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                                modifier = Modifier.height(26.dp)
                            ) { Text("Line -100ms", fontSize = 10.sp) }
                            OutlinedButton(
                                onClick = { shiftEntireLine(safeLineIdx, +0.100) },
                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                                modifier = Modifier.height(26.dp)
                            ) { Text("Line +100ms", fontSize = 10.sp) }
                            if (activeSelectedWord != null && safeWordIdx < activeSelectedWords.lastIndex) {
                                OutlinedButton(
                                    onClick = {
                                        val nextStart = activeSelectedWords[safeWordIdx + 1].begin
                                        updateWordTiming(safeLineIdx, safeWordIdx) { it.copy(end = nextStart) }
                                    },
                                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                                    modifier = Modifier.height(26.dp)
                                ) { Text("Join Next", fontSize = 10.sp) }
                            }
                        }
                    }
                }
            }
        }

        // 3. Scrollable Interactive Line & Word Timeline List
        LazyColumn(
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.weight(1f)
        ) {
            itemsIndexed(lines, key = { idx, line -> "${line.id}_$idx" }) { lineIdx, line ->
                val bounds = line.effectiveBounds()
                val isLinePlaying = bounds != null && currentSec >= bounds.begin && currentSec <= bounds.end
                val isLineSelected = lineIdx == safeLineIdx
                val isArabicLine = BilingualScriptAndNormalizer.isArabicWord(line.text)
                val lineDirection = if (isArabicLine) LayoutDirection.Rtl else LayoutDirection.Ltr

                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = when {
                            isLineSelected -> Color(0xFF1E293B)
                            isLinePlaying -> Color(0xFF172554)
                            else -> MaterialTheme.colorScheme.surface
                        }
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(
                            width = if (isLineSelected) 1.5.dp else 1.dp,
                            color = if (isLineSelected) MaterialTheme.colorScheme.primary else Color.White.copy(alpha = 0.08f),
                            shape = RoundedCornerShape(10.dp)
                        )
                        .clickable {
                            selectedLineIdx = lineIdx
                            selectedWordIdx = 0
                            bounds?.let { exoPlayer.seekTo((it.begin * 1000.0).toLong()) }
                        }
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "L${lineIdx + 1} [${line.agentId}]",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.secondary,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = if (bounds != null) {
                                    "${TtmlFormatting.formatTime(bounds.begin, 2)} → ${TtmlFormatting.formatTime(bounds.end, 2)}"
                                } else "Untimed",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        CompositionLocalProvider(LocalLayoutDirection provides lineDirection) {
                            val wordList = line.words.orEmpty()
                            if (wordList.isNotEmpty()) {
                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    wordList.forEachIndexed { wIdx, w ->
                                        val isWordSelected = isLineSelected && wIdx == safeWordIdx
                                        val isWordPlaying = currentSec >= w.begin && currentSec <= w.end
                                        val chipBg = when {
                                            isWordPlaying -> Color(0xFF2563EB)
                                            isWordSelected -> Color(0xFF0F766E)
                                            else -> Color(0xFF0F172A)
                                        }
                                        val chipBorder = when {
                                            isWordSelected -> Color(0xFF4FD6C0)
                                            isWordPlaying -> Color(0xFF60A5FA)
                                            w.needsReview -> Color(0xFFF59E0B)
                                            else -> Color(0xFF334155)
                                        }
                                        Column(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(chipBg)
                                                .border(1.dp, chipBorder, RoundedCornerShape(8.dp))
                                                .clickable {
                                                    selectedLineIdx = lineIdx
                                                    selectedWordIdx = wIdx
                                                    exoPlayer.seekTo((w.begin * 1000.0).toLong())
                                                }
                                                .padding(horizontal = 8.dp, vertical = 5.dp),
                                            horizontalAlignment = Alignment.CenterHorizontally
                                        ) {
                                            Text(
                                                text = w.text.trim().ifEmpty { w.text },
                                                fontSize = 14.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color.White
                                            )
                                            Text(
                                                text = "${TtmlFormatting.formatTime(w.begin, 2)}-${TtmlFormatting.formatTime(w.end, 2)}",
                                                fontSize = 9.sp,
                                                fontFamily = FontFamily.Monospace,
                                                color = Color(0xFF93C5FD)
                                            )
                                        }
                                    }
                                }
                            } else {
                                Text(
                                    text = line.text,
                                    fontSize = 14.sp,
                                    color = Color.White
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// ================================================================================================
// 6. TAB 4: OFFLINE MODEL MANAGER & TTML VALIDATOR / EXPORTER
// ================================================================================================

@Composable
fun ModelManagerAndExportScreen(
    modelManager: OfflineModelManager,
    generatedTtml: String?,
    validation: TtmlValidation?,
    onExportTtml: () -> Unit
) {
    val statuses by modelManager.statuses.collectAsState()
    val scope = rememberCoroutineScope()
    var pendingSideloadModel by remember { mutableStateOf<ModelId?>(null) }

    var folderImportStatus by remember {
        val arMb = modelManager.getArabicCtcFile().length() / (1024 * 1024)
        val enMb = modelManager.getEnglishCtcFile().length() / (1024 * 1024)
        mutableStateOf("Active CTC Models: AR (${arMb} MB) • EN (${enMb} MB)")
    }

    val folderTreeLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { treeUri: Uri? ->
        if (treeUri != null) {
            scope.launch {
                folderImportStatus = "Importing aligner-ar / aligner-en from selected folder…"
                val res = modelManager.importAlignerFolderFromTreeUri(treeUri) { msg ->
                    folderImportStatus = msg
                }
                folderImportStatus = res.getOrElse { "Import error: ${it.message}" }
            }
        }
    }

    val sideloadLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        val modelId = pendingSideloadModel
        if (uri != null && modelId != null) {
            scope.launch {
                modelManager.sideloadModelFromUri(modelId, uri)
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            "Offline ONNX Models (Import Local TTML-models Folder or Download)",
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp
        )

        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    "Have TTML-models (aligner-ar & aligner-en) in Downloads?",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.secondary
                )
                Text(
                    "Tap below and select your Download/TTML-models folder (or aligner-ar / aligner-en) to load model.int8.onnx, vocab.json, and meta.json directly.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Button(
                    onClick = { folderTreeLauncher.launch(null) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.FolderOpen, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Select TTML-models Folder (aligner-ar / aligner-en)")
                }
                Text(
                    text = folderImportStatus,
                    fontSize = 12.sp,
                    color = Color(0xFF4ADE80),
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        for (modelId in ModelId.entries) {
            val status = statuses[modelId]
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(modelId.title, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.weight(1f))
                        if (status?.isInstalled == true) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = Color(0xFF4ADE80),
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(Modifier.width(4.dp))
                                Text(
                                    "Installed (${status.sizeBytes / (1024 * 1024)} MB • ${status.sha256Prefix})",
                                    fontSize = 11.sp,
                                    color = Color(0xFF4ADE80)
                                )
                            }
                        } else {
                            Text("Not Installed (~${modelId.approxMb} MB)", fontSize = 11.sp, color = Color(0xFFFACC15))
                        }
                    }

                    Text(modelId.description, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

                    if (status?.isDownloading == true) {
                        LinearProgressIndicator(
                            progress = { status.downloadProgress },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    status?.errorMessage?.let { err ->
                        Text("Note: $err (You can sideload ${modelId.filename} from local storage)", fontSize = 11.sp, color = Color(0xFFF87171))
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { scope.launch { modelManager.downloadModel(modelId) } },
                            enabled = status?.isDownloading != true
                        ) {
                            Icon(Icons.Default.CloudDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(if (status?.isInstalled == true) "Re-Download" else "Download ONNX")
                        }
                        OutlinedButton(
                            onClick = {
                                pendingSideloadModel = modelId
                                sideloadLauncher.launch(arrayOf("*/*"))
                            }
                        ) {
                            Icon(Icons.Default.FolderOpen, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Sideload .onnx File")
                        }
                    }
                }
            }
        }

        HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

        // TTML Schema Validation & Raw XML Inspector
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Generated TTML & XML Well-Formedness Check", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    when (validation) {
                        is TtmlValidation.Ok -> Text("Well-formed XML with <tt> root (not schema-validated)", color = Color(0xFF4ADE80), fontSize = 12.sp)
                        is TtmlValidation.Error -> Text("XML parse/root check failed: ${validation.message}", color = Color(0xFFF87171), fontSize = 12.sp)
                        is TtmlValidation.Warnings -> Text(
                            "${validation.issues.size} TTML semantic/timing issue(s); review before export (not schema validation)",
                            color = Color(0xFFFBBF24),
                            fontSize = 12.sp
                        )
                        null -> Text("No TTML generated yet", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }

                if (!generatedTtml.isNullOrBlank()) {
                    Button(onClick = onExportTtml, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.Save, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Save .ttml via Android Storage Access Framework")
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(260.dp)
                            .background(Color(0xFF070A10), RoundedCornerShape(8.dp))
                            .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(8.dp))
                            .padding(10.dp)
                            .verticalScroll(rememberScrollState())
                    ) {
                        Text(
                            text = generatedTtml,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = Color(0xFFE2E8F0)
                        )
                    }
                }
            }
        }
    }
}

// ================================================================================================
// 7. LRCLIB.NET SEARCH MODAL DIALOG (With Duration Badges & Synced/Plain Selector)
// ================================================================================================

@Composable
fun LrclibSearchDialog(
    initialQuery: LyricsSearchQuery,
    autoExtractBgVocals: Boolean,
    onDismiss: () -> Unit,
    onSelectLyrics: (List<LyricLine>, String, String?) -> Unit
) {
    val scope = rememberCoroutineScope()
    val client = remember { LrclibClient() }

    var track by remember { mutableStateOf(initialQuery.track) }
    var artist by remember { mutableStateOf(initialQuery.artist) }
    var album by remember { mutableStateOf(initialQuery.album) }
    var isSearching by remember { mutableStateOf(false) }
    var results by remember { mutableStateOf<List<LyricsSearchResult>>(emptyList()) }

    LaunchedEffect(Unit) {
        if (track.isNotBlank()) {
            isSearching = true
            results = client.search(
                LyricsSearchQuery(track, artist, album, initialQuery.durationSec, initialQuery.isrc)
            )
            isSearching = false
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Search LRCLIB.net Lyrics") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = track,
                    onValueChange = { track = it },
                    label = { Text("Track Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = artist,
                        onValueChange = { artist = it },
                        label = { Text("Artist") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    Button(
                        onClick = {
                            scope.launch {
                                isSearching = true
                                results = client.search(
                                    LyricsSearchQuery(track, artist, album, initialQuery.durationSec, initialQuery.isrc)
                                )
                                isSearching = false
                            }
                        },
                        modifier = Modifier.align(Alignment.CenterVertically)
                    ) {
                        Text("Search")
                    }
                }

                if (isSearching) {
                    Box(modifier = Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxWidth().height(280.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        itemsIndexed(results) { _, item ->
                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text("${item.track} — ${item.artist}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Text(
                                        "${item.syncType.label} • ${item.durationBadge.label} (${item.durationSec ?: 0}s)",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.secondary
                                    )
                                    val payload = item.payload as? LyricsSearchPayload.Lrc
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        if (!payload?.synced.isNullOrBlank()) {
                                            Button(
                                                onClick = {
                                                    val parsed = LrcAndTextParser.parseLrc(
                                                        payload!!.synced!!,
                                                        initialQuery.durationSec,
                                                        autoExtractBgVocals
                                                    )
                                                    val lang = BilingualScriptAndNormalizer.detectDominantLanguage(parsed.lines)
                                                    onSelectLyrics(parsed.lines, "LRCLIB Synced (${item.id})", lang)
                                                },
                                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                            ) {
                                                Text("Use Synced .LRC", fontSize = 11.sp)
                                            }
                                        }
                                        if (!payload?.plain.isNullOrBlank()) {
                                            OutlinedButton(
                                                onClick = {
                                                    val parsed = LrcAndTextParser.parsePlainText(
                                                        payload!!.plain!!,
                                                        initialQuery.durationSec,
                                                        autoExtractBgVocals
                                                    )
                                                    val lang = BilingualScriptAndNormalizer.detectDominantLanguage(parsed.lines)
                                                    onSelectLyrics(parsed.lines, "LRCLIB Plain (${item.id})", lang)
                                                },
                                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                            ) {
                                                Text("Use Plain .TXT", fontSize = 11.sp)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Close") }
        }
    )
}


// ================================================================================================
// 8. PART A: BRAND IDENTITY EMBLEM, LAUNCH SPLASH, STUDIO HOME PAGE & RECENT PROJECTS STORE
// ================================================================================================

data class RecentProjectEntry(
    val title: String,
    val artist: String,
    val language: String,
    val lineCount: Int,
    val wordCount: Int,
    val lastEditedEpochMillis: Long
)

object RecentProjectsStore {
    private const val PREFS_NAME = "better_lyrics_recent_projects_v1"
    private const val KEY_ENTRIES = "entries_pipe_v1"

    fun loadRecentProjects(context: Context): List<RecentProjectEntry> = runCatching {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val raw = prefs.getString(KEY_ENTRIES, null).orEmpty()
        if (raw.isBlank()) return emptyList()
        raw.lines().mapNotNull { row ->
            val parts = row.split("\t")
            if (parts.size < 6) null
            else RecentProjectEntry(
                title = parts[0],
                artist = parts[1],
                language = parts[2],
                lineCount = parts[3].toIntOrNull() ?: 0,
                wordCount = parts[4].toIntOrNull() ?: 0,
                lastEditedEpochMillis = parts[5].toLongOrNull() ?: 0L
            )
        }.filter { it.title.isNotBlank() && it.lastEditedEpochMillis > 0L }
    }.getOrDefault(emptyList())

    fun recordProject(
        context: Context,
        title: String,
        artist: String,
        language: String,
        lineCount: Int,
        wordCount: Int
    ) {
        val cleanTitle = title.replace("\t", " ").replace("\n", " ").trim()
        if (cleanTitle.isBlank()) return
        val cleanArtist = artist.replace("\t", " ").replace("\n", " ").trim()
        val cleanLang = language.replace("\t", " ").trim().ifEmpty { "ar" }
        val now = System.currentTimeMillis()

        val existing = loadRecentProjects(context)
            .filterNot { it.title.equals(cleanTitle, ignoreCase = true) && it.artist.equals(cleanArtist, ignoreCase = true) }
        val updated = (listOf(
            RecentProjectEntry(
                title = cleanTitle,
                artist = cleanArtist,
                language = cleanLang,
                lineCount = lineCount,
                wordCount = wordCount,
                lastEditedEpochMillis = now
            )
        ) + existing).take(8)

        val serialized = updated.joinToString("\n") { e ->
            listOf(e.title, e.artist, e.language, e.lineCount, e.wordCount, e.lastEditedEpochMillis).joinToString("\t")
        }
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_ENTRIES, serialized)
            .apply()
    }

    fun formatTimestamp(epochMillis: Long): String = runCatching {
        val fmt = SimpleDateFormat("MMM d, HH:mm", Locale.getDefault())
        fmt.format(Date(epochMillis))
    }.getOrDefault("")
}

/**
 * Original vector emblem combining synchronized horizontal lyric bars, sculpted acoustic waveform
 * peaks in electric violet (`#7C4DFF`) and restrained cyan (`#00E5FF`), and a precision timing
 * marker in warm coral (`#FF6D4D`).
 */
@Composable
fun BetterLyricsBrandEmblem(modifier: Modifier = Modifier) {
    Canvas(
        modifier = modifier.semantics {
            contentDescription = "Better Lyrics Composer Studio Logo"
        }
    ) {
        val w = size.width
        val h = size.height
        val corner = CornerRadius(w * 0.24f, h * 0.24f)

        // 1. Midnight Navy to Deep Indigo rounded studio badge
        drawRoundRect(
            brush = Brush.linearGradient(
                colors = listOf(Color(0xFF161E3C), Color(0xFF080B16)),
                start = Offset(0f, 0f),
                end = Offset(w, h)
            ),
            cornerRadius = corner
        )
        drawRoundRect(
            brush = Brush.linearGradient(
                colors = listOf(Color(0xFF7C4DFF).copy(alpha = 0.65f), Color(0xFF00E5FF).copy(alpha = 0.45f)),
                start = Offset(0f, 0f),
                end = Offset(w, h)
            ),
            cornerRadius = corner,
            style = Stroke(width = w * 0.04f)
        )

        // 2. Three synchronized lyric bars on the left/center
        val barHeight = h * 0.075f
        val barRadius = CornerRadius(barHeight * 0.5f, barHeight * 0.5f)
        drawRoundRect(
            color = Color(0xFF00E5FF),
            topLeft = Offset(w * 0.16f, h * 0.28f),
            size = Size(w * 0.36f, barHeight),
            cornerRadius = barRadius
        )
        drawRoundRect(
            color = Color(0xFFF8FAFC),
            topLeft = Offset(w * 0.16f, h * 0.46f),
            size = Size(w * 0.48f, barHeight),
            cornerRadius = barRadius
        )
        drawRoundRect(
            color = Color(0xFF7C4DFF),
            topLeft = Offset(w * 0.16f, h * 0.64f),
            size = Size(w * 0.30f, barHeight),
            cornerRadius = barRadius
        )

        // 3. Acoustic waveform pillars on the right
        val pillW = w * 0.065f
        val pillR = CornerRadius(pillW * 0.5f, pillW * 0.5f)
        drawRoundRect(
            color = Color(0xFF7C4DFF),
            topLeft = Offset(w * 0.68f, h * 0.30f),
            size = Size(pillW, h * 0.40f),
            cornerRadius = pillR
        )
        drawRoundRect(
            color = Color(0xFF00E5FF),
            topLeft = Offset(w * 0.79f, h * 0.20f),
            size = Size(pillW, h * 0.60f),
            cornerRadius = pillR
        )

        // 4. Warm Coral precision timing playhead marker
        val cursorX = w * 0.58f
        drawLine(
            color = Color(0xFFFF6D4D),
            start = Offset(cursorX, h * 0.16f),
            end = Offset(cursorX, h * 0.84f),
            strokeWidth = w * 0.045f,
            cap = StrokeCap.Round
        )
        drawCircle(
            color = Color(0xFFFF6D4D),
            radius = w * 0.065f,
            center = Offset(cursorX, h * 0.16f)
        )
    }
}

@Composable
fun StudioLaunchSplashOverlay() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF080B16), Color(0xFF12182F), Color(0xFF080B16))
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.padding(32.dp)
        ) {
            BetterLyricsBrandEmblem(modifier = Modifier.size(88.dp))
            Spacer(Modifier.height(4.dp))
            Text(
                text = "Better Lyrics",
                fontSize = 28.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color(0xFFF8FAFC),
                letterSpacing = 0.4.sp
            )
            Text(
                text = "BETTER LYRICS COMPOSER STUDIO",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF00E5FF),
                letterSpacing = 1.8.sp
            )
            Text(
                text = "Your lyrics. Perfectly in sync.",
                fontSize = 14.sp,
                color = Color(0xFF94A3B8)
            )
        }
    }
}

@Composable
fun StudioWaveformAndLyricTimingVisual(isPipelineRunning: Boolean) {
    val infinite = rememberInfiniteTransition(label = "studioWave")
    val phase by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (isPipelineRunning) 1600 else 3600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "playheadSweep"
    )

    Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .height(54.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0xFF0B1022))
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        val barCount = 36
        val spacing = size.width / barCount.toFloat()
        val playheadX = size.width * (0.18f + 0.64f * phase)

        for (i in 0 until barCount) {
            val x = i * spacing + spacing * 0.5f
            val norm = i.toFloat() / barCount.toFloat()
            val env = (0.28f + 0.65f * kotlin.math.abs(kotlin.math.sin((norm * 3.8f + 0.3f) * Math.PI)).toFloat())
                .coerceIn(0.18f, 0.95f)
            val barH = size.height * env
            val top = (size.height - barH) * 0.5f
            val isSyncedLeft = x <= playheadX
            val barColor = when {
                kotlin.math.abs(x - playheadX) < spacing * 0.9f -> Color(0xFFFF6D4D)
                isSyncedLeft -> Color(0xFF00E5FF)
                else -> Color(0xFF7C4DFF).copy(alpha = 0.45f)
            }
            drawLine(
                color = barColor,
                start = Offset(x, top),
                end = Offset(x, top + barH),
                strokeWidth = (spacing * 0.48f).coerceAtLeast(3f),
                cap = StrokeCap.Round
            )
        }

        // Precision timing playhead line
        drawLine(
            color = Color(0xFFFF6D4D),
            start = Offset(playheadX, 0f),
            end = Offset(playheadX, size.height),
            strokeWidth = 2.5f,
            cap = StrokeCap.Round
        )
    }
}

@Composable
fun StudioHomeScreen(
    audioFileName: String,
    lyricsSourceLabel: String,
    metadata: ProjectMetadata,
    activeLinesCount: Int,
    activeWordsCount: Int,
    arabicBackend: ArabicAlignmentBackend,
    demucsVariant: ModelId,
    useHardwareAccel: Boolean,
    pipelineState: PipelineState,
    modelManager: OfflineModelManager,
    recentProjects: List<RecentProjectEntry>,
    onStartNewProject: () -> Unit,
    onImportAudioAndLyrics: () -> Unit,
    onImportExistingTtml: () -> Unit,
    onOpenComposer: () -> Unit,
    onOpenPipeline: () -> Unit,
    onOpenPreview: () -> Unit,
    onOpenModels: () -> Unit,
    onRetryPipeline: () -> Unit,
    onCancelPipeline: () -> Unit
) {
    val modelStatuses by modelManager.statuses.collectAsState()
    val isPipelineRunning = pipelineState.stage.stepNumber in 1..4
    val hasLoadedSession = activeLinesCount > 0 || selectedAudioLoaded(audioFileName)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Top Brand Hero Card
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(
                    width = 1.dp,
                    brush = Brush.horizontalGradient(
                        listOf(Color(0xFF7C4DFF).copy(alpha = 0.65f), Color(0xFF00E5FF).copy(alpha = 0.45f))
                    ),
                    shape = RoundedCornerShape(18.dp)
                )
        ) {
            Column(
                modifier = Modifier.padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    BetterLyricsBrandEmblem(modifier = Modifier.size(56.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "BETTER LYRICS COMPOSER STUDIO",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.secondary,
                            letterSpacing = 1.4.sp
                        )
                        Text(
                            text = "Your lyrics. Perfectly in sync.",
                            fontSize = 21.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFFF8FAFC)
                        )
                        Text(
                            text = "Word-level TTML synchronization for Egyptian Arabic, English, sustained vocals, and multi-singer harmonies.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                StudioWaveformAndLyricTimingVisual(isPipelineRunning = isPipelineRunning)
            }
        }

        // 2. Primary Studio Actions (Principal CTA + Quick Launchers)
        Text(
            text = "Studio Actions",
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            color = Color(0xFFF8FAFC)
        )

        // Principal Action: New Alignment Project
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1D1848)),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.5.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(16.dp))
                .clickable { onStartNewProject() }
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .background(MaterialTheme.colorScheme.primary, RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.AutoAwesome,
                            contentDescription = "New Alignment Project",
                            tint = Color.White
                        )
                    }
                    Column {
                        Text(
                            text = "New Alignment Project",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 16.sp,
                            color = Color.White
                        )
                        Text(
                            text = "Neural CTC where available; acoustic fallback timings are flagged for review",
                            fontSize = 12.sp,
                            color = Color(0xFFCBD5E1)
                        )
                    }
                }
            }
        }

        // Secondary Action Cards Grid
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            StudioActionTile(
                title = "Import Audio + Lyrics",
                subtitle = "Load track & .LRC / .TXT",
                icon = Icons.Default.LibraryMusic,
                accentColor = Color(0xFF00E5FF),
                onClick = onImportAudioAndLyrics,
                modifier = Modifier.weight(1f)
            )
            StudioActionTile(
                title = "Import Existing TTML",
                subtitle = "Inspect or refine .TTML",
                icon = Icons.Default.Code,
                accentColor = Color(0xFF7C4DFF),
                onClick = onImportExistingTtml,
                modifier = Modifier.weight(1f)
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            StudioActionTile(
                title = if (hasLoadedSession) "Continue Editing (${activeLinesCount} lines)" else "Open Composer",
                subtitle = if (activeWordsCount > 0) "$activeWordsCount timed word spans ready" else "Word & syllable timeline editor",
                icon = Icons.Default.EditNote,
                accentColor = Color(0xFFFF6D4D),
                onClick = onOpenComposer,
                modifier = Modifier.weight(1f)
            )
            StudioActionTile(
                title = "RTL/LTR Live Preview",
                subtitle = "Apple Music word sweep",
                icon = Icons.Default.MusicNote,
                accentColor = Color(0xFF38BDF8),
                onClick = onOpenPreview,
                modifier = Modifier.weight(1f)
            )
        }

        // 3. Live Alignment Status & Honest Hardware/Model Telemetry Card
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            Icons.Default.Memory,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = "Alignment Engine & Runtime Status",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = Color(0xFFF8FAFC)
                        )
                    }
                    Text(
                        text = pipelineState.stage.title,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = when (pipelineState.stage) {
                            PipelineStage.FAILED -> Color(0xFFF87171)
                            PipelineStage.COMPLETED -> Color(0xFF4ADE80)
                            else -> MaterialTheme.colorScheme.secondary
                        }
                    )
                }

                if (isPipelineRunning || pipelineState.stage == PipelineStage.COMPLETED) {
                    LinearProgressIndicator(
                        progress = { pipelineState.overallProgress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(7.dp)
                            .clip(RoundedCornerShape(4.dp))
                    )
                }

                Text(
                    text = pipelineState.detailMessage,
                    fontSize = 12.sp,
                    color = if (pipelineState.stage == PipelineStage.FAILED) Color(0xFFFCA5A5) else MaterialTheme.colorScheme.onSurfaceVariant
                )

                val bilingualCtcReady = modelManager.hasValidBilingualCtcAssets()
                val parsehInstalled = modelStatuses[ModelId.PARSEH_ALIGNER_AR_INT8]?.isInstalled == true
                val computeLabel = if (useHardwareAccel) {
                    "CPU only — acceleration requested but no NNAPI/Vulkan delegate is connected"
                } else {
                    "CPU only (NNAPI/Vulkan acceleration unavailable)"
                }

                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = "• Active Arabic/English Backend: ${arabicBackend.title}",
                        fontSize = 11.sp,
                        color = Color(0xFFCBD5E1)
                    )
                    val ctcReadyLabel = if (bilingualCtcReady) "Yes" else "Incomplete"
                    val parsehSuffix = if (parsehInstalled) " + Parseh XLSR-53" else ""
                    Text(
                        text = "• Selected separator (if available): ${demucsVariant.title} • Bilingual CTC Ready: $ctcReadyLabel$parsehSuffix",
                        fontSize = 11.sp,
                        color = Color(0xFFCBD5E1)
                    )
                    Text(
                        text = "• Compute Runtime: $computeLabel",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.secondary
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (pipelineState.stage == PipelineStage.FAILED) {
                        Button(
                            onClick = onRetryPipeline,
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiary)
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Retry Alignment", fontSize = 12.sp)
                        }
                    }
                    if (isPipelineRunning) {
                        OutlinedButton(onClick = onCancelPipeline) {
                            Text("Cancel Job", fontSize = 12.sp)
                        }
                    }
                    OutlinedButton(onClick = onOpenPipeline) {
                        Text("Configure Pipeline", fontSize = 12.sp)
                    }
                    TextButton(onClick = onOpenModels) {
                        Text("ONNX Models", fontSize = 12.sp)
                    }
                }
            }
        }

        // 4. Genuine Persisted Recent Projects Section
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    Icons.Default.History,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = "Recent Projects",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = Color(0xFFF8FAFC)
                )
            }
            if (recentProjects.isNotEmpty()) {
                Text(
                    text = "${recentProjects.size} saved",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        if (recentProjects.isEmpty()) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "No recent projects yet",
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 14.sp,
                        color = Color(0xFFF8FAFC)
                    )
                    Text(
                        text = "Import an audio track + lyrics (.LRC / .TXT / LRCLIB) or open an existing .TTML file above. Your real project sessions will appear here automatically.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                recentProjects.forEach { entry ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onOpenComposer() }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = if (entry.artist.isNotBlank()) "${entry.title} — ${entry.artist}" else entry.title,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = Color(0xFFF8FAFC)
                                )
                                Text(
                                    text = "${entry.lineCount} lines • ${entry.wordCount} timed words • Last edited ${RecentProjectsStore.formatTimestamp(entry.lastEditedEpochMillis)}",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Surface(
                                color = Color(0xFF1E293B),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = entry.language.uppercase(Locale.ROOT),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.secondary,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun selectedAudioLoaded(audioFileName: String): Boolean =
    audioFileName.isNotBlank() && audioFileName != "No audio file selected"

@Composable
private fun StudioActionTile(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accentColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(14.dp),
        modifier = modifier
            .border(1.dp, accentColor.copy(alpha = 0.35f), RoundedCornerShape(14.dp))
            .clickable { onClick() }
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .background(accentColor.copy(alpha = 0.16f), RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = title, tint = accentColor, modifier = Modifier.size(18.dp))
            }
            Text(
                text = title,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = Color(0xFFF8FAFC)
            )
            Text(
                text = subtitle,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
